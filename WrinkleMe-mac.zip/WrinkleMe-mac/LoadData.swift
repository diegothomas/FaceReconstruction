//
//  LoadData.swift
//  WrinkleMe-mac
//
//  Created by Diego Thomas on 2018/02/09.
//  Copyright © 2018 3DLab. All rights reserved.
//

import Foundation
import Cocoa

class LoadData: NSViewController {
    
    @IBOutlet var PathSetButton: NSButton!
    
    var viewController: ViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override var representedObject: Any? {
        didSet {
            // Update the view, if already loaded.
        }
    }
    
    
    @IBAction func ShowPathOpenPanel(_ sender: Any) {
        let panel = NSOpenPanel()
        panel.allowsMultipleSelection = false
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        panel.resolvesAliases = true
        
        let panelTitle = NSLocalizedString("Choose a directory", comment: "Title for the open panel")
        panel.title = panelTitle
        
        let promptString = NSLocalizedString("Choose", comment: "Prompt for the open panel prompt")
        panel.prompt = promptString
        
        if (panel.runModal() == NSApplication.ModalResponse.OK) {
            let result = panel.url // pathname
            
            if (result != nil) {
                viewController.path = result!.path
                viewController.blendshapeMeshes = Blendshapes(path: result!.path)
                print("path: ", viewController.path!)
            } else {
                // User click on "Cancel"
                return
            }
        }
    }
}
