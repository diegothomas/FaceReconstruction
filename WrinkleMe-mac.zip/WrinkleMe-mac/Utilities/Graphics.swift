//
//  Graphics.swift
//  WrinkleMe-mac
//
//  Created by Diego Thomas on 2018/03/01.
//  Copyright © 2018 3DLab. All rights reserved.
//

import Cocoa
import CoreMedia
import CoreVideo
import Vision

func drawPoints(PixelBuffer: CVPixelBuffer, points: [CGPoint]?, rect: CGRect, size: Int) {
    if let count = points?.count {
        CVPixelBufferLockBaseAddress(PixelBuffer, CVPixelBufferLockFlags(rawValue: 0));
        let floatBuffer = unsafeBitCast(CVPixelBufferGetBaseAddress(PixelBuffer), to: UnsafeMutablePointer<UInt8>.self)
        let floatPerRow = CVPixelBufferGetBytesPerRow(PixelBuffer)/4
        let floatPerCol = (CVPixelBufferGetDataSize(PixelBuffer)/4)/floatPerRow
        
        var pixelInfo : Int
        var bounds = [0, 0, 0, 0]
        for k in 0...count-1 {
            let p = CGPoint(x: CGFloat(rect.origin.x + points![k].x * rect.width), y: CGFloat(rect.origin.y + points![k].y * rect.height))
            bounds[0] = min(floatPerCol-1, max(Int(p.y)-size, 0))
            bounds[1] = max(0, min(Int(p.y)+size, floatPerCol-1))
            bounds[2] = min(floatPerRow-1, max(Int(p.x)-size, 0))
            bounds[3] = max(0, min(Int(p.x)+size, floatPerRow-1))
            for i in bounds[0]...bounds[1] {
                for j in bounds[2]...bounds[3] {
                    pixelInfo = ((floatPerRow * (floatPerCol-i)) + j) * 4
                    floatBuffer[pixelInfo] = 0
                    floatBuffer[pixelInfo+1] = 255
                    floatBuffer[pixelInfo+2] = 0
                    
                }
            }
        }
        
        CVPixelBufferUnlockBaseAddress(PixelBuffer, CVPixelBufferLockFlags(rawValue: 0))
    }
}

func drawRect(PixelBuffer: CVPixelBuffer, rect: CGRect, lineWidth: Int) {
    CVPixelBufferLockBaseAddress(PixelBuffer, CVPixelBufferLockFlags(rawValue: 0));
    let floatBuffer = unsafeBitCast(CVPixelBufferGetBaseAddress(PixelBuffer), to: UnsafeMutablePointer<UInt8>.self)
    let floatPerRow = CVPixelBufferGetBytesPerRow(PixelBuffer)/4
    let floatPerCol = (CVPixelBufferGetDataSize(PixelBuffer)/4)/floatPerRow
    
    if Int(rect.origin.y + rect.height) + lineWidth > floatPerCol-1 ||
        Int(rect.origin.x + rect.width) + lineWidth > floatPerRow-1 {
        return
    }
    
    var pixelInfo : Int
    // Draw top and bottom lines
    for i in Int(rect.origin.y)...Int(rect.origin.y + rect.height) {
        for j in 1...lineWidth {
            pixelInfo = ((floatPerRow * (floatPerCol-i)) + Int(rect.origin.x)+j) * 4
            floatBuffer[pixelInfo] = 0
            floatBuffer[pixelInfo+1] = 0
            floatBuffer[pixelInfo+2] = 255
            
            pixelInfo = ((floatPerRow * (floatPerCol-i)) + Int(rect.origin.x + rect.width)-j) * 4
            floatBuffer[pixelInfo] = 0
            floatBuffer[pixelInfo+1] = 0
            floatBuffer[pixelInfo+2] = 255
        }
    }
    // Draw left and right lines
    for j in Int(rect.origin.x)...Int(rect.origin.x + rect.width) {
        for i in 1...lineWidth {
            pixelInfo = ((floatPerRow * (floatPerCol-(Int(rect.origin.y)+i))) + j) * 4
            floatBuffer[pixelInfo] = 0
            floatBuffer[pixelInfo+1] = 0
            floatBuffer[pixelInfo+2] = 255
            
            pixelInfo = ((floatPerRow * (floatPerCol-(Int(rect.origin.y + rect.height)-i))) + j) * 4
            floatBuffer[pixelInfo] = 0
            floatBuffer[pixelInfo+1] = 0
            floatBuffer[pixelInfo+2] = 255
        }
    }
    CVPixelBufferUnlockBaseAddress(PixelBuffer, CVPixelBufferLockFlags(rawValue: 0))
}
