//
//  misc.swift
//  WrinkleMe-mac
//
//  Created by Diego Thomas on 2018/03/01.
//  Copyright © 2018 3DLab. All rights reserved.
//

import Foundation
import Accelerate

extension float3 {
    func norm_two() -> Float {
        return sqrtf(self.x * self.x + self.y*self.y + self.z*self.z)
    }
    
    func dot(_ v: float3) -> Float{
        return x*v.x + y*v.y + z*v.z
    }
    
    func cross(_ v: float3) -> float3 {
        return float3(y*v.z-z*v.y,-x*v.z + z*v.x, x*v.y - y*v.x)
    }
}

extension float4 {
    func norm_two() -> Float {
        return sqrtf(self.x * self.x + self.y*self.y + self.z*self.z + self.w*self.w)
    }
}


extension float3x3 {
    func normF() -> Float {
        return sqrt(columns.0.x*columns.0.x + columns.0.y*columns.0.y + columns.0.z*columns.0.z +
            columns.1.x*columns.1.x + columns.1.y*columns.1.y + columns.1.z*columns.1.z +
            columns.2.x*columns.2.x + columns.2.y*columns.2.y + columns.2.z*columns.2.z)
    }
}

func invert(matrix : [Double]) -> [Double] {
    var inMatrix:[Double]       = matrix
    // Get the dimensions of the matrix. An NxN matrix has N^2
    // elements, so sqrt( N^2 ) will return N, the dimension
    var N:__CLPK_integer        = __CLPK_integer( sqrt( Double( matrix.count ) ) )
    // Initialize some arrays for the dgetrf_(), and dgetri_() functions
    var pivots:[__CLPK_integer] = [__CLPK_integer](repeating: 0, count: Int(N))
    var workspace:[Double]      = [Double](repeating: 0.0, count: Int(N))
    var error: __CLPK_integer   = 0
    // Perform LU factorization
    var tmp1 = N
    var tmp2 = N
    dgetrf_(&tmp1, &tmp2, &inMatrix, &N, &pivots, &error)
    // Calculate inverse from LU factorization
    dgetri_(&tmp1, &inMatrix, &tmp2, &pivots, &workspace, &N, &error)
    return inMatrix
}

func quaternion2matrix(_ q: [Float]) -> float4x4 {
    var res = float4x4.init(diagonal: float4(1.0))
    let q00 = q[0] * q[0]
    let q11 = q[1] * q[1]
    let q22 = q[2] * q[2]
    let q33 = q[3] * q[3]
    let q03 = q[0] * q[3]
    let q13 = q[1] * q[3]
    let q23 = q[2] * q[3]
    let q02 = q[0] * q[2]
    let q12 = q[1] * q[2]
    let q01 = q[0] * q[1]
    res[0].x = q00 + q11 - q22 - q33
    res[1].y = q00 - q11 + q22 - q33
    res[2].z = q00 - q11 - q22 + q33
    res[1].x = 2.0*(q12 - q03)
    res[0].y = 2.0*(q12 + q03)
    res[2].x = 2.0*(q13 + q02)
    res[0].z = 2.0*(q13 - q02)
    res[2].y = 2.0*(q23 - q01)
    res[1].z = 2.0*(q23 + q01)
    return res
}

func Exponential(qsi: [Float]) -> float4x4 { //[Float] UnsafeMutablePointer<Float>
    let theta = sqrt(qsi[3]*qsi[3] + qsi[4]*qsi[4] + qsi[5]*qsi[5])
    var res = float4x4.init(diagonal: float4(1.0))

    if theta != 0.0 {
        res.columns.0.x = 1.0 + sin(theta)/theta*0.0 + (1.0 - cos(theta)) / (theta*theta) * (-qsi[5]*qsi[5] - qsi[4]*qsi[4])
        res.columns.0.y = 0.0 + sin(theta)/theta*qsi[5] + (1.0 - cos(theta))/(theta*theta) * (qsi[3]*qsi[4])
        res.columns.0.z = 0.0 - sin(theta)/theta*qsi[4] + (1.0 - cos(theta))/(theta*theta) * (qsi[3]*qsi[5])

        res.columns.1.x = 0.0 - sin(theta)/theta*qsi[5] + (1.0 - cos(theta))/(theta*theta) * (qsi[3]*qsi[4])
        res.columns.1.y = 1.0 + sin(theta) / theta*0.0 + (1.0 - cos(theta))/(theta*theta) * (-qsi[5]*qsi[5] - qsi[3]*qsi[3])
        res.columns.1.z = 0.0 + sin(theta)/theta*qsi[3] + (1.0 - cos(theta))/(theta*theta) * (qsi[4]*qsi[5])

        res.columns.2.x = 0.0 + sin(theta) / theta*qsi[4] + (1.0 - cos(theta))/(theta*theta) * (qsi[3]*qsi[5])
        res.columns.2.y = 0.0 - sin(theta)/theta*qsi[3] + (1.0 - cos(theta))/(theta*theta) * (qsi[4]*qsi[5])
        res.columns.2.z = 1.0 + sin(theta)/theta*0.0 + (1.0 - cos(theta))/(theta*theta) * (-qsi[4]*qsi[4] - qsi[3]*qsi[3])

        var skew = float3x3.init(diagonal: float3(0.0))
        skew.columns.1.x = -qsi[5]
        skew.columns.2.x = qsi[4]
        skew.columns.0.y = qsi[5]
        skew.columns.2.y = -qsi[3]
        skew.columns.0.z = -qsi[4]
        skew.columns.1.z = qsi[3]

        let V = float3x3.init(diagonal: float3(1.0)) + ((1.0-cos(theta))/(theta*theta))*skew + ((theta - sin(theta))/(theta*theta))*(skew*skew)

        res.columns.3.x = V.columns.0.x*qsi[0] + V.columns.1.x*qsi[1] + V.columns.2.x*qsi[2]
        res.columns.3.y = V.columns.0.y*qsi[0] + V.columns.1.y*qsi[1] + V.columns.2.y*qsi[2]
        res.columns.3.z = V.columns.0.z*qsi[0] + V.columns.1.z*qsi[1] + V.columns.2.z*qsi[2]
    } else {
        res.columns.3.x = qsi[0]
        res.columns.3.y = qsi[1]
        res.columns.3.z = qsi[2]
    }

    return res
}

/*def Logarithm(Mat):
trace = Mat[0,0]+Mat[1,1]+Mat[2,2]
theta = acos((trace-1.0)/2.0)

qsi = np.array([0.,0.,0.,0.,0.,0.])
if (theta == 0.):
qsi[3] = qsi[4] = qsi[5] = 0.0
qsi[0] = Mat[0,3]
qsi[1] = Mat[1,3]
qsi[2] = Mat[2,3]
return qsi

R = Mat[0:3,0:3]
lnR = (theta/(2.0*sin(theta))) * (R-np.transpose(R))

qsi[3] = (lnR[2,1] - lnR[1,2])/2.0
qsi[4] = (lnR[0,2] - lnR[2,0])/2.0
qsi[5] = (lnR[1,0] - lnR[0,1])/2.0

theta = LA.norm(qsi[3:6])

skew = np.zeros((3,3), np.float32)
skew[0,1] = -qsi[5]
skew[0,2] = qsi[4]
skew[1,0] = qsi[5]
skew[1,2] = -qsi[3]
skew[2,0] = -qsi[4]
skew[2,1] = qsi[3]

V = np.identity(3) + ((1.0 - cos(theta))/(theta*theta))*skew + ((theta-sin(theta))/(theta*theta))*np.dot(skew,skew)
V_inv = LA.inv(V)

qsi[0] = V_inv[0,0]*Mat[0,3] + V_inv[0,1]*Mat[1,3] + V_inv[0,2]*Mat[2,3]
qsi[1] = V_inv[1,0]*Mat[0,3] + V_inv[1,1]*Mat[1,3] + V_inv[1,2]*Mat[2,3]
qsi[2] = V_inv[2,0]*Mat[0,3] + V_inv[2,1]*Mat[1,3] + V_inv[2,2]*Mat[2,3]

return qsi*/


func getDocumentsDirectory() -> URL {
    let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
    return paths[0]
}

func SaveToPly(VMapBuffer: CVPixelBuffer) {
    
    CVPixelBufferLockBaseAddress(VMapBuffer, CVPixelBufferLockFlags(rawValue: 0));
    let floatBuffer = unsafeBitCast(CVPixelBufferGetBaseAddress(VMapBuffer), to: UnsafeMutablePointer<Float>.self)
    let floatPerRow = CVPixelBufferGetBytesPerRow(VMapBuffer)/16
    let floatPerCol = (CVPixelBufferGetDataSize(VMapBuffer)/16)/floatPerRow
    print(floatPerRow)
    print(floatPerCol)
    
    let filename1 = getDocumentsDirectory().appendingPathComponent("Mesh.ply")
    
    var str1 = ""
    
    var size = 0
    var pixelInfo = 0
    for i in 0...floatPerCol-1 {
        for j in 0...floatPerRow-1 {
            pixelInfo = ((floatPerRow * i) + j) * 4
            if floatBuffer[pixelInfo] == 0.0 && floatBuffer[pixelInfo+1] == 0.0 && floatBuffer[pixelInfo+2] == 0.0 {
                continue
            }
            str1 = str1 + "\(floatBuffer[pixelInfo]) \(floatBuffer[pixelInfo+1]) \(floatBuffer[pixelInfo+2])\n"
            size += 1
        }
    }
    str1 = "ply\nformat ascii 1.0\ncomment ply file created by Diego Thomas\nelement vertex \(size)\nproperty float x\nproperty float y\nproperty float z\nelement face 0 \nend_header\n" + str1
    
    do {
        try str1.write(to: filename1, atomically: true, encoding: String.Encoding.utf8)
    } catch {
        // failed to write file – bad permissions, bad filename, missing permissions, or more likely it can't be converted to the encoding
    }
    
    CVPixelBufferUnlockBaseAddress(VMapBuffer, CVPixelBufferLockFlags(rawValue: 0))
    
    print("file written")
}

func SaveToPly(VMapBuffer: CVPixelBuffer, NMapBuffer: CVPixelBuffer) {
    
    CVPixelBufferLockBaseAddress(VMapBuffer, CVPixelBufferLockFlags(rawValue: 0));
    let floatBuffer = unsafeBitCast(CVPixelBufferGetBaseAddress(VMapBuffer), to: UnsafeMutablePointer<Float>.self)
    CVPixelBufferLockBaseAddress(NMapBuffer, CVPixelBufferLockFlags(rawValue: 0));
    let floatBuffer2 = unsafeBitCast(CVPixelBufferGetBaseAddress(NMapBuffer), to: UnsafeMutablePointer<Float>.self)
    
    let floatPerRow = CVPixelBufferGetBytesPerRow(VMapBuffer)/16
    let floatPerCol = (CVPixelBufferGetDataSize(VMapBuffer)/16)/floatPerRow
    
    let filename1 = getDocumentsDirectory().appendingPathComponent("Mesh.ply")
    
    var str1 = ""
    
    var size = 0
    var pixelInfo = 0
    for i in 0...floatPerCol-1 {
        for j in 0...floatPerRow-1 {
            pixelInfo = ((floatPerRow * i) + j) * 4
            if floatBuffer[pixelInfo] == 0.0 && floatBuffer[pixelInfo+1] == 0.0 && floatBuffer[pixelInfo+2] == 0.0 {
                continue
            }
            str1 = str1 + "\(floatBuffer[pixelInfo]) \(floatBuffer[pixelInfo+1]) \(floatBuffer[pixelInfo+2]) \(floatBuffer2[pixelInfo]) \(floatBuffer2[pixelInfo+1]) \(floatBuffer2[pixelInfo+2])\n"
            size += 1
        }
    }
    str1 = "ply\nformat ascii 1.0\ncomment ply file created by Diego Thomas\nelement vertex \(size)\nproperty float x\nproperty float y\nproperty float z\nproperty float nx\nproperty float ny\nproperty float nz\nelement face 0 \nend_header\n" + str1
    
    do {
        try str1.write(to: filename1, atomically: true, encoding: String.Encoding.utf8)
    } catch {
        // failed to write file – bad permissions, bad filename, missing permissions, or more likely it can't be converted to the encoding
    }
    
    CVPixelBufferUnlockBaseAddress(NMapBuffer, CVPixelBufferLockFlags(rawValue: 0))
    CVPixelBufferUnlockBaseAddress(VMapBuffer, CVPixelBufferLockFlags(rawValue: 0))
    
    print("file written")
}

func SaveToPly(VMapBuffer: CVPixelBuffer, NMapBuffer: CVPixelBuffer, Bump: CVPixelBuffer) {
    
    CVPixelBufferLockBaseAddress(VMapBuffer, CVPixelBufferLockFlags(rawValue: 0));
    let floatBuffer = unsafeBitCast(CVPixelBufferGetBaseAddress(VMapBuffer), to: UnsafeMutablePointer<Float>.self)
    CVPixelBufferLockBaseAddress(NMapBuffer, CVPixelBufferLockFlags(rawValue: 0));
    let floatBuffer2 = unsafeBitCast(CVPixelBufferGetBaseAddress(NMapBuffer), to: UnsafeMutablePointer<Float>.self)
    CVPixelBufferLockBaseAddress(Bump, CVPixelBufferLockFlags(rawValue: 0));
    let floatBuffer3 = unsafeBitCast(CVPixelBufferGetBaseAddress(Bump), to: UnsafeMutablePointer<Float>.self)
    
    let floatPerRow = CVPixelBufferGetBytesPerRow(VMapBuffer)/16
    let floatPerCol = (CVPixelBufferGetDataSize(VMapBuffer)/16)/floatPerRow
    
    let filename1 = getDocumentsDirectory().appendingPathComponent("Mesh.ply")
    
    var str1 = ""
    
    var size = 0
    var pixelInfo = 0
    for i in 0...floatPerCol-1 {
        for j in 0...floatPerRow-1 {
            pixelInfo = ((floatPerRow * i) + j) * 4
            if floatBuffer[pixelInfo] == 0.0 && floatBuffer[pixelInfo+1] == 0.0 && floatBuffer[pixelInfo+2] == 0.0 {
                continue
            }
            if floatBuffer3[pixelInfo+2] == -1.0 {
            str1 = str1 + "\(floatBuffer[pixelInfo]) \(floatBuffer[pixelInfo+1]) \(floatBuffer[pixelInfo+2]) \(floatBuffer2[pixelInfo]) \(floatBuffer2[pixelInfo+1]) \(floatBuffer2[pixelInfo+2]) 255 0 0\n"
            } else {
                str1 = str1 + "\(floatBuffer[pixelInfo]) \(floatBuffer[pixelInfo+1]) \(floatBuffer[pixelInfo+2]) \(floatBuffer2[pixelInfo]) \(floatBuffer2[pixelInfo+1]) \(floatBuffer2[pixelInfo+2]) 150 150 150\n"
            }
            size += 1
        }
    }
    str1 = "ply\nformat ascii 1.0\ncomment ply file created by Diego Thomas\nelement vertex \(size)\nproperty float x\nproperty float y\nproperty float z\nproperty float nx\nproperty float ny\nproperty float nz\nproperty uchar red\nproperty uchar green\nproperty uchar blue\nelement face 0 \nend_header\n" + str1
    
    do {
        try str1.write(to: filename1, atomically: true, encoding: String.Encoding.utf8)
    } catch {
        // failed to write file – bad permissions, bad filename, missing permissions, or more likely it can't be converted to the encoding
    }
    
    CVPixelBufferUnlockBaseAddress(NMapBuffer, CVPixelBufferLockFlags(rawValue: 0))
    CVPixelBufferUnlockBaseAddress(VMapBuffer, CVPixelBufferLockFlags(rawValue: 0))
    CVPixelBufferUnlockBaseAddress(Bump, CVPixelBufferLockFlags(rawValue: 0))
    
    print("file written")
}

func MyMedian(_ a: Double,_ b: Double,_ c: Double) -> Double {
    if ((a >= b && a <= c) || (a <= b && a >= c)) {
        return a
    }
    if ((b >= a && b <= c) || (b <= a && b >= c)) {
        return b
    }
    if ((c >= a && c <= b) || (c <= a && c >= b)) {
        return c
    }
    print("no median error!: ", a, ", ", b, ", ", c)
    return a
}

func ParallelRelaxation(_ A_inv: Array<Double>,_ x0: Array<Double>,_ A: Array<Double>,_ lb :Array<Double>,_ ub: Array<Double>) -> Array<Double> {
    let n = x0.count
    let w = 0.2
    let max_iter = 10000
    var u = Array<Double>.init(repeating: 0.0, count: n)
    var c = Array<Double>.init(repeating: 0.0, count: n)
    var Delta = Array<Double>.init(repeating: 0.0, count: n)
    var Gamma = Array<Double>.init(repeating: 0.0, count: n)
    var alpha = Array<Double>.init(repeating: 0.0, count: n)
    var S = Array<Double>.init(repeating: 0.0, count: n)
    var a = 0.0
    var xres = x0
    
    var row_curr = Array<Double>.init(repeating: 0.0, count: n)
    for i in 0...n-1 {
        for j in 0...n-1 {
            row_curr[j] = A[i*n + j]
        }
        
        var val_a = 0.0
        for j in 0...n-1 {
            var val = 0.0
            for k in 0...n-1 {
                val += A_inv[j*n + k]*row_curr[k]
            }
            val_a += row_curr[j]*val
        }
        
        alpha[i] = val_a
    }
    //print("alpha: ", alpha)
    
    var converged = false
    var iter = 0
    while !converged {
        
        for i in 0...n-1 {
            S[i] = 0.0
        }
        for i in 0...n-1 {
            a = 0.0
            for j in 0...n-1 {
                row_curr[j] = A[i*n + j]
                a += row_curr[j]*xres[j]
            }
            //a = val
            Delta[i] = (lb[i] - a) / alpha[i]
            Gamma[i] = (ub[i] - a) / alpha[i]
            c[i] = MyMedian(u[i], w*Delta[i], w*Gamma[i])
            
            for j in 0...n-1 {
                S[j] = S[j] + c[i] * row_curr[j]
            }
        }
        for i in 0...n-1 {
            u[i] = u[i] - c[i];
        }
        
        var norm = 0.0
        for i in 0...n-1 {
            var val = 0.0
            for j in 0...n-1 {
                val += A_inv[i*n+j]*S[j]
            }
            xres[i] = xres[i] + val
            norm += S[i]*S[i]
        }
        
        iter += 1
        converged = (iter > max_iter || sqrt(norm) < 1.0e-10)
        
        //print("norm: ", norm, ", iter: ", iter)
        
        //if (iter % 1000 == 0)
        //cout << "inner_iter: " << iter << " " << xres.transpose() << endl;
        //cout << "S: " << S << endl;
        //cout << "c: " << c << endl;
        //cout << "Delta: " << Delta << endl;
        //cout << "Gamma: " << Gamma << endl;
    }
    
    return xres
}

func ParallelRelaxation(_ A_inv: Array<Double>,_ x0: Array<Double>,_ lb :Array<Double>,_ ub: Array<Double>) -> Array<Double> {
    let n = x0.count
    let w = 0.2
    let max_iter = 10000
    var u = Array<Double>.init(repeating: 0.0, count: n)
    var Delta = Array<Double>.init(repeating: 0.0, count: n)
    var Gamma = Array<Double>.init(repeating: 0.0, count: n)
    var S = Array<Double>.init(repeating: 0.0, count: n)
    var xres = x0
    
    var converged = false
    var iter = 0
    while !converged {
        
        for i in 0...n-1 {
            Delta[i] = (lb[i] - xres[i]) / A_inv[i*n+i]
            Gamma[i] = (ub[i] - xres[i]) / A_inv[i*n+i]
            S[i] = MyMedian(u[i], w*Delta[i], w*Gamma[i])
        }
        for i in 0...n-1 {
            u[i] = u[i] - S[i];
        }
        
        var norm = 0.0
        for i in 0...n-1 {
            var val = 0.0
            for j in 0...n-1 {
                val += A_inv[i*n+j]*S[j]
            }
            xres[i] = xres[i] + val
            norm += S[i]*S[i]
        }
        
        iter += 1
        converged = (iter > max_iter || sqrt(norm) < 1.0e-10)
    }
    
    return xres
}

func LoadLandmarks(_ filename: String) -> [CGPoint] {
    //let fileURLProject = Bundle.main.path(forResource: filename, ofType: "txt")!
    
    // Read from the file
    var readStringProject = ""
    do {
        readStringProject = try String(contentsOfFile: filename, encoding: String.Encoding.utf8)
    } catch let error as NSError {
        print("Failed reading from URL: \(filename), Error: " + error.localizedDescription)
        var res: [CGPoint] = []
        for _ in 0...50 {
            res.append(CGPoint.init(x: CGFloat(-1.0), y: CGFloat(-1.0)))
        }
        
        return res
    }
    
    let buffer = readStringProject.components(separatedBy: [" ", "/", "\n"])
    var res: [CGPoint] = []
    for i in 0...50 {
        let x = (buffer[2*i] as NSString).floatValue
        let y = (buffer[2*i+1] as NSString).floatValue
        
        if x > 0.0 && y > 0.0 {
            res.append(CGPoint.init(x: CGFloat(x), y: CGFloat(Float(DEPTH_HEIGHT)-y)))
        } else {
            res.append(CGPoint.init(x: CGFloat(-1.0), y: CGFloat(-1.0)))
        }
    }
    
    return res
    
}
