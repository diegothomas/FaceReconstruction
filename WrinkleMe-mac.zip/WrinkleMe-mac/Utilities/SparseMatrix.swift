//
//  SparseMatrix.swift
//  WrinkleMe-mac
//
//  Created by Diego Thomas on 2018/03/01.
//  Copyright © 2018 3DLab. All rights reserved.
//

import Foundation
import Accelerate

struct SparseParam {
    var values: [Float] = []
    var rowIndices: [Int32] = []
    var columnStarts: [Int] = [0]
}

func Multiply_Sparse(_ A: SparseMatrix_Float,_ B: SparseMatrix_Float, _  structureRes: inout SparseParam) {
    
    if A.structure.columnCount != B.structure.rowCount {
        print("Cannot multiply: Invalid dimensions")
        return
    }
    
    // Transpose A
    var SparseParamTA = SparseParam()
    Transpose_Sparse(A, &SparseParamTA)
    let structureTA = SparseMatrixStructure(rowCount: A.structure.columnCount,
                                            columnCount: A.structure.rowCount,
                                            columnStarts: &SparseParamTA.columnStarts,
                                            rowIndices: &SparseParamTA.rowIndices,
                                            attributes: SparseAttributes_t(),
                                            blockSize: 1)
    let c = SparseMatrix_Float(structure: structureTA, data: &SparseParamTA.values)
    
    // Iterate over all elements of B
    for bpos in 0...B.structure.columnCount-1 {
        let lenb = B.structure.columnStarts[Int(bpos+1)]  // number of non zero elements in the column
        
        for apos in 0...c.structure.columnCount-1 {
            let lena = c.structure.columnStarts[Int(apos+1)] // number of non zero elements in the column
            
            var tempa = c.structure.columnStarts[Int(apos)]
            var tempb = B.structure.columnStarts[Int(bpos)]
            
            var sum: Float = 0.0
            
            // Iterate over all elements with same row and col value
            while tempa < lena && tempb < lenb {
                if c.structure.rowIndices[tempa] < B.structure.rowIndices[tempb] {
                    // skip a
                    tempa+=1
                } else if c.structure.rowIndices[tempa] > B.structure.rowIndices[tempb] {
                    // skip b
                    tempb+=1
                } else {
                    // same row, so multiply and increment
                    sum += c.data[tempa] * B.data[tempb]
                    tempa += 1
                    tempb += 1
                }
            }
            
            if sum != 0.0 {
                structureRes.rowIndices.append(apos)
                structureRes.values.append(sum)
            }
        }
        structureRes.columnStarts.append(structureRes.rowIndices.count)
    }
}

func Multiply_SparseByScalar(_ A: SparseMatrix_Float,_  scal: Float, _  structureRes: inout SparseParam) {
    // Iterate over all elements of A
    for apos in 0...A.structure.columnCount-1 {
        let lena = A.structure.columnStarts[Int(apos+1)]  // number of non zero elements in the column
        var tempa = A.structure.columnStarts[Int(apos)]
        // Iterate over all elements with same row and col value
        while tempa < lena {
            structureRes.values.append(A.data[tempa]*scal)
            structureRes.rowIndices.append(A.structure.rowIndices[tempa])
            tempa += 1
        }
        structureRes.columnStarts.append(structureRes.rowIndices.count)
    }
}

func Add_Sparse(_ A: SparseMatrix_Float,_ B: SparseMatrix_Float, _  structureRes: inout SparseParam) {
    
    if A.structure.columnCount != B.structure.columnCount ||
        A.structure.rowCount != B.structure.rowCount {
        print("Cannot add: Invalid dimensions")
        print(A.structure.columnCount, A.structure.columnCount)
        print(B.structure.columnCount, B.structure.columnCount)
        return
    }
    // Iterate over all elements of B
    for bpos in 0...B.structure.columnCount-1 {
        let apos = bpos
        let lenb = B.structure.columnStarts[Int(bpos+1)]  // number of non zero elements in the column
        let lena = A.structure.columnStarts[Int(apos+1)] // number of non zero elements in the column
        
        var tempa = A.structure.columnStarts[Int(apos)]
        var tempb = B.structure.columnStarts[Int(bpos)]
        
        // Iterate over all elements with same row and col value
        while tempa < lena || tempb < lenb {
            if tempa == lena { // finished processing all elements in a
                structureRes.rowIndices.append(Int32(B.structure.rowIndices[tempb]))
                structureRes.values.append(B.data[tempb])
                tempb+=1
                continue
            }
            
            if tempb == lenb { // finished processing all elements in b
                structureRes.rowIndices.append(Int32(A.structure.rowIndices[tempa]))
                structureRes.values.append(A.data[tempa])
                tempa += 1
                continue
            }
            
            if A.structure.rowIndices[tempa] < B.structure.rowIndices[tempb] {
                structureRes.rowIndices.append(Int32(A.structure.rowIndices[tempa]))
                structureRes.values.append(A.data[tempa])
                tempa += 1
            } else if A.structure.rowIndices[tempa] > B.structure.rowIndices[tempb] {
                structureRes.rowIndices.append(Int32(B.structure.rowIndices[tempb]))
                structureRes.values.append(B.data[tempb])
                tempb+=1
            } else {
                // same row, so add and increment
                structureRes.rowIndices.append(Int32(B.structure.rowIndices[tempb]))
                structureRes.values.append(A.data[tempa] + B.data[tempb])
                tempa += 1
                tempb += 1
            }
        }
        structureRes.columnStarts.append(structureRes.rowIndices.count)
    }
}

func Transpose_Sparse(_ A: SparseMatrix_Float, _  structureRes: inout SparseParam) {
    
    // Iterate over all elements of A
    for rpos in 0...A.structure.rowCount-1 {
        for apos in 0...A.structure.columnCount-1 {
            let lena = A.structure.columnStarts[Int(apos+1)]  // number of non zero elements in the column
            var tempa = A.structure.columnStarts[Int(apos)]
            // Iterate over all elements with same row and col value
            while tempa < lena {
                if A.structure.rowIndices[tempa] == rpos {
                    structureRes.rowIndices.append(apos)
                    structureRes.values.append(A.data[tempa])
                    break
                }
                tempa += 1
            }
        }
        structureRes.columnStarts.append(structureRes.rowIndices.count)
    }
}
