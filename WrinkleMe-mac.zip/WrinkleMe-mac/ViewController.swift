//
//  ViewController.swift
//  WrinkleMe-mac
//
//  Created by Diego Thomas on 2018/02/09.
//  Copyright © 2018 3DLab. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {
    
    var path: String? = nil
    var blendshapeMeshes: Blendshapes?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }

    override func prepare(for segue: NSStoryboardSegue, sender: Any?) {
        switch segue.identifier?.rawValue {
        case "LoadData"?:
            let loadData = segue.destinationController as! LoadData
            loadData.viewController = self
        case "StartCapture"?:
            if (path != nil && blendshapeMeshes != nil) {
                if (blendshapeMeshes?.size())! > 0 {
                    let captureController = segue.destinationController as! CaptureInterfaceController
                    captureController.path = path!
                    captureController.blendshapeMeshes = blendshapeMeshes!
                }
            }
        default:
            preconditionFailure("Unexpected segue identifier")
        }
    }
    
}

