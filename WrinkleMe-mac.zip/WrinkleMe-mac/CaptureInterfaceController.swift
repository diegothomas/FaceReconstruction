//
//  CaptureInterfaceController.swift
//  WrinkleMe-mac
//
//  Created by Diego Thomas on 2018/02/19.
//  Copyright © 2018 3DLab. All rights reserved.
//

import Cocoa

class CaptureInterfaceController: NSSplitViewController {
    
    var path: String? = nil
    
    var blendshapeMeshes: Blendshapes!
    
    var captureView: CaptureController?
    
    var menuView: CaptureMenuController?
    
    override func viewDidLoad() {
        captureView = self.childViewControllers.first as? CaptureController
        captureView?.path = path
        captureView?.blendshapeController = blendshapeMeshes
        
        menuView = self.childViewControllers.last as? CaptureMenuController
        
        super.viewDidLoad()
        
        captureView?.captureDelegate = menuView
        menuView?.menuDelegate = captureView
    }
}
