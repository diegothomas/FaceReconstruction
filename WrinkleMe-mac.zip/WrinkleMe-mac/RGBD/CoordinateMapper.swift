//
//  CoordinateMapper.swift
//  WrinkleMe-mac
//
//  Created by Diego Thomas on 2018/02/14.
//  Copyright © 2018 3DLab. All rights reserved.
//

import CoreMedia
import CoreVideo
import Metal

class CoordinateMapper {
    
    var description: String = "Coordinate mapper"
    
    var isPrepared = false
    
    private(set) var inputFormatDescription: CMFormatDescription?
    
    private(set) var outputFormatDescription: CMFormatDescription?
    
    private var inputTextureFormat: MTLPixelFormat = .invalid
    
    private var outputPixelBufferPool: CVPixelBufferPool!
    
    private let metalDevice = MTLCreateSystemDefaultDevice()!
    
    private var computePipelineStateRGBToDepth: MTLComputePipelineState?
    
    private var computePipelineStateDepthToRGB: MTLComputePipelineState?
    
    private var initPipelineState: MTLComputePipelineState?
    
    private lazy var commandQueue: MTLCommandQueue? = {
        return self.metalDevice.makeCommandQueue()
    }()
    
    private var textureCache: CVMetalTextureCache!
    
    let sizeOfCalib = MemoryLayout<Float>.size * Matrix4.numberOfElements() * 2
    
    var calibBuffer: MTLBuffer
    
    private var threadsPerThreadgroup: MTLSize?
    private var threadgroupsPerGrid: MTLSize?
    
    required init() {
        let defaultLibrary = metalDevice.makeDefaultLibrary()!
        let kernelFunction = defaultLibrary.makeFunction(name: "DepthToRGB")
        do {
            computePipelineStateDepthToRGB = try metalDevice.makeComputePipelineState(function: kernelFunction!)
        } catch {
            fatalError("Unable to create depth to vmap pipeline state. (\(error))")
        }
        
        let kernelFunction1 = defaultLibrary.makeFunction(name: "RGBToDepth")
        do {
            computePipelineStateRGBToDepth = try metalDevice.makeComputePipelineState(function: kernelFunction1!)
        } catch {
            fatalError("Unable to create RGBToDepth pipeline state. (\(error))")
        }
        
        let kernelFunction2 = defaultLibrary.makeFunction(name: "InitUint16")
        do {
            initPipelineState = try metalDevice.makeComputePipelineState(function: kernelFunction2!)
        } catch {
            fatalError("Unable to create InitUint32 pipeline state. (\(error))")
        }
        
        calibBuffer = metalDevice.makeBuffer(length: sizeOfCalib, options: [])!
    }
    
    static private func allocateOutputBufferPool(with formatDescription: CMFormatDescription, outputRetainedBufferCountHint: Int) -> CVPixelBufferPool? {
        let inputDimensions = CMVideoFormatDescriptionGetDimensions(formatDescription)
        let outputPixelBufferAttributes: [String: Any] = [
            kCVPixelBufferPixelFormatTypeKey as String:  kCVPixelFormatType_64ARGB,
            kCVPixelBufferWidthKey as String: Int(inputDimensions.width),
            kCVPixelBufferHeightKey as String: Int(inputDimensions.height),
            kCVPixelBufferIOSurfacePropertiesKey as String: [:]
        ]
        
        let poolAttributes = [kCVPixelBufferPoolMinimumBufferCountKey as String: outputRetainedBufferCountHint]
        var cvPixelBufferPool: CVPixelBufferPool?
        // Create a pixel buffer pool with the same pixel attributes as the input format description
        CVPixelBufferPoolCreate(kCFAllocatorDefault, poolAttributes as NSDictionary?, outputPixelBufferAttributes as NSDictionary?, &cvPixelBufferPool)
        guard let pixelBufferPool = cvPixelBufferPool else {
            assertionFailure("Allocation failure: Could not create pixel buffer pool")
            return nil
        }
        return pixelBufferPool
    }
    
    func setParameters(pose: Array<Double>, intrinsic: Array<Double>, ref: NSSize) {
        
        var poseFloat: [Float] = []
        var intrinsicFloat: [Float] = []
        for i in 0...3 {
            for j in 0...3 {
                poseFloat.append(Float(pose[j*4 + i]))
                intrinsicFloat.append(Float(0.0))
            }
        }
        intrinsicFloat[0] = Float(DEPTH_WIDTH*intrinsic[0]/Double(ref.width))
        intrinsicFloat[5] = Float(DEPTH_HEIGHT*intrinsic[4]/Double(ref.height))
        intrinsicFloat[8] = Float(DEPTH_WIDTH*intrinsic[2]/Double(ref.width))
        intrinsicFloat[9] = Float(DEPTH_HEIGHT*intrinsic[5]/Double(ref.height))
        intrinsicFloat[10] = Float(1.0)
        intrinsicFloat[15] = Float(1.0)

        memcpy(calibBuffer.contents(), UnsafeMutableRawPointer(&poseFloat), MemoryLayout<Float>.size * 16)
        memcpy(calibBuffer.contents() + MemoryLayout<Float>.size * 16, UnsafeMutableRawPointer(&intrinsicFloat), MemoryLayout<Float>.size * 16)
    }
    
    func prepare(with formatDescription: CMFormatDescription, outputRetainedBufferCountHint: Int, width: Int, height: Int) {
        reset()
        
        outputPixelBufferPool = CoordinateMapper.allocateOutputBufferPool(with: formatDescription,
                                                                     outputRetainedBufferCountHint: outputRetainedBufferCountHint)
        if outputPixelBufferPool == nil {
            return
        }
        
        var pixelBuffer: CVPixelBuffer?
        var pixelBufferFormatDescription: CMFormatDescription?
        _ = CVPixelBufferPoolCreatePixelBuffer(kCFAllocatorDefault, outputPixelBufferPool!, &pixelBuffer)
        if let pixelBuffer = pixelBuffer {
            CMVideoFormatDescriptionCreateForImageBuffer(kCFAllocatorDefault, pixelBuffer, &pixelBufferFormatDescription)
        }
        pixelBuffer = nil
        
        inputFormatDescription = formatDescription
        outputFormatDescription = pixelBufferFormatDescription
        
        let inputMediaSubType = CMFormatDescriptionGetMediaSubType(formatDescription)
        if inputMediaSubType == kCVPixelFormatType_128RGBAFloat {
            inputTextureFormat = .rgba32Float
        } else {
            assertionFailure("Input format not supported")
        }
        
        var metalTextureCache: CVMetalTextureCache?
        if CVMetalTextureCacheCreate(kCFAllocatorDefault, nil, metalDevice, nil, &metalTextureCache) != kCVReturnSuccess {
            assertionFailure("Unable to allocate depth to vmap texture cache")
        } else {
            textureCache = metalTextureCache
        }
        
        // Set up thread groups as described in https://developer.apple.com/reference/metal/mtlcomputecommandencoder
        let w = initPipelineState!.threadExecutionWidth
        let h = initPipelineState!.maxTotalThreadsPerThreadgroup / w
        threadsPerThreadgroup = MTLSizeMake(w, h, 1)
        threadgroupsPerGrid = MTLSize(width: (width + w - 1) / w,
                                      height: (height + h - 1) / h,
                                      depth: 1)
        
        isPrepared = true
    }
    
    func reset() {
        outputPixelBufferPool = nil
        outputFormatDescription = nil
        inputFormatDescription = nil
        textureCache = nil
        isPrepared = false
    }
    
    // MARK: - Map depth coordinates to rgb coordinates
    func DepthToRGB(pixelBuffer: CVPixelBuffer) -> CVPixelBuffer? {
        if !isPrepared {
            assertionFailure("Invalid state: Not prepared")
            return nil
        }
        
        var newPixelBuffer: CVPixelBuffer?
        CVPixelBufferPoolCreatePixelBuffer(kCFAllocatorDefault, outputPixelBufferPool!, &newPixelBuffer)
        guard let outputPixelBuffer = newPixelBuffer else {
            print("Allocation failure: Could not get pixel buffer from pool (\(self.description))")
            return nil
        }
        
        guard let outputTexture = makeTextureFromCVPixelBuffer(pixelBuffer: outputPixelBuffer, textureFormat: .rgba16Uint),
            let inputTexture = makeTextureFromCVPixelBuffer(pixelBuffer: pixelBuffer, textureFormat: inputTextureFormat) else {
                return nil
        }
        
        //==============================
        // Initialize with zeros
        //==============================
        // Set up command queue, buffer, and encoder
        guard let commandQueue = commandQueue,
            let commandBufferInit = commandQueue.makeCommandBuffer(),
            let commandEncoderInit = commandBufferInit.makeComputeCommandEncoder() else {
                print("Failed to create Metal command queue")
                CVMetalTextureCacheFlush(textureCache!, 0)
                return nil
        }
        
        commandEncoderInit.label = "Init texture"
        commandEncoderInit.setComputePipelineState(initPipelineState!)
        commandEncoderInit.setTexture(outputTexture, index: 0)
        
        commandEncoderInit.dispatchThreadgroups(threadgroupsPerGrid!, threadsPerThreadgroup: threadsPerThreadgroup!)
        
        commandEncoderInit.endEncoding()
        
        commandBufferInit.commit()
        
        // Set up command queue, buffer, and encoder
        guard let commandBuffer = commandQueue.makeCommandBuffer(),
            let commandEncoder = commandBuffer.makeComputeCommandEncoder() else {
                print("Failed to create Metal command queue")
                CVMetalTextureCacheFlush(textureCache!, 0)
                return nil
        }
        
        commandEncoder.label = "Depth To RGB"
        commandEncoder.setComputePipelineState(computePipelineStateDepthToRGB!)
        commandEncoder.setTexture(inputTexture, index: 0)
        commandEncoder.setTexture(outputTexture, index: 1)
        commandEncoder.setBytes( calibBuffer.contents(), length: sizeOfCalib, index: 0)
        
        commandEncoder.dispatchThreadgroups(threadgroupsPerGrid!, threadsPerThreadgroup: threadsPerThreadgroup!)
        
        commandEncoder.endEncoding()
        
        commandBuffer.commit()
        
        return outputPixelBuffer
    }
    
    // MARK: - Map rgb coordinates to depth coordinates
    func RGBToDepth(pixelBuffer: CVPixelBuffer) -> CVPixelBuffer? {
        if !isPrepared {
            assertionFailure("Invalid state: Not prepared")
            return nil
        }
        
        var newPixelBuffer: CVPixelBuffer?
        CVPixelBufferPoolCreatePixelBuffer(kCFAllocatorDefault, outputPixelBufferPool!, &newPixelBuffer)
        guard let outputPixelBuffer = newPixelBuffer else {
            print("Allocation failure: Could not get pixel buffer from pool (\(self.description))")
            return nil
        }
        
        guard let outputTexture = makeTextureFromCVPixelBuffer(pixelBuffer: outputPixelBuffer, textureFormat: .rgba16Uint),
            let inputTexture = makeTextureFromCVPixelBuffer(pixelBuffer: pixelBuffer, textureFormat: inputTextureFormat) else {
                return nil
        }
        
        //==============================
        // Initialize with zeros
        //==============================
        // Set up command queue, buffer, and encoder
        guard let commandQueue = commandQueue,
            let commandBufferInit = commandQueue.makeCommandBuffer(),
            let commandEncoderInit = commandBufferInit.makeComputeCommandEncoder() else {
                print("Failed to create Metal command queue")
                CVMetalTextureCacheFlush(textureCache!, 0)
                return nil
        }
        
        commandEncoderInit.label = "Init texture"
        commandEncoderInit.setComputePipelineState(initPipelineState!)
        commandEncoderInit.setTexture(outputTexture, index: 0)
        
        // Set up thread groups as described in https://developer.apple.com/reference/metal/mtlcomputecommandencoder
        let w = initPipelineState!.threadExecutionWidth
        let h = initPipelineState!.maxTotalThreadsPerThreadgroup / w
        let threadsPerThreadgroup = MTLSizeMake(w, h, 1)
        let threadgroupsPerGrid = MTLSize(width: (inputTexture.width + w - 1) / w,
                                          height: (inputTexture.height + h - 1) / h,
                                          depth: 1)
        commandEncoderInit.dispatchThreadgroups(threadgroupsPerGrid, threadsPerThreadgroup: threadsPerThreadgroup)
        
        commandEncoderInit.endEncoding()
        
        commandBufferInit.commit()
        
        // Set up command queue, buffer, and encoder
        guard let commandBuffer = commandQueue.makeCommandBuffer(),
            let commandEncoder = commandBuffer.makeComputeCommandEncoder() else {
                print("Failed to create Metal command queue")
                CVMetalTextureCacheFlush(textureCache!, 0)
                return nil
        }
        
        commandEncoder.label = "RGB To Depth"
        commandEncoder.setComputePipelineState(computePipelineStateRGBToDepth!)
        commandEncoder.setTexture(inputTexture, index: 0)
        commandEncoder.setTexture(outputTexture, index: 1)
        commandEncoder.setBytes( calibBuffer.contents(), length: sizeOfCalib, index: 0)
        
        commandEncoder.dispatchThreadgroups(threadgroupsPerGrid, threadsPerThreadgroup: threadsPerThreadgroup)
        
        commandEncoder.endEncoding()
        
        commandBuffer.commit()
        
        return outputPixelBuffer
    }
    
    func makeTextureFromCVPixelBuffer(pixelBuffer: CVPixelBuffer, textureFormat: MTLPixelFormat) -> MTLTexture? {
        let width = CVPixelBufferGetWidth(pixelBuffer)
        let height = CVPixelBufferGetHeight(pixelBuffer)
        
        
        var cvTextureOut: CVMetalTexture?
        CVMetalTextureCacheCreateTextureFromImage(kCFAllocatorDefault, textureCache, pixelBuffer, nil, textureFormat, width, height, 0, &cvTextureOut)
        
        guard let cvTexture = cvTextureOut, let texture = CVMetalTextureGetTexture(cvTexture) else {
            print("Depth converter failed to create preview texture")
            
            CVMetalTextureCacheFlush(textureCache, 0)
            
            return nil
        }
        
        return texture
    }
    
}


