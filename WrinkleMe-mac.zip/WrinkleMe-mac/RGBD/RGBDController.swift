//
//  RGBDController.swift
//  WrinkleMe-mac
//
//  Created by Diego Thomas on 2018/02/13.
//  Copyright © 2018 3DLab. All rights reserved.
//

import Cocoa
import CoreMedia
import CoreVideo
import Vision

class RGBDController {
    var path: String
    var indx: Int = 10
    let SIZE_POINT = 1
    
    var scale = 1.0
    var sizeDepth = NSSize(width: 0.0, height: 0.0)
    var sizeRGB = NSSize(width: 0.0, height: 0.0)
    var intrinsicDepth = Array(repeating: 0.0, count: 9)
    var intrinsicRGB = Array(repeating: 0.0, count: 9)
    var RGBprojectionMatrix = Matrix4()
    var depthToRGB = Array(repeating: 0.0, count: 16)
    var depthToRGBMatrix = Matrix4()
    
    var depthImage: NSImage?
    var RGBImage: NSImage?
    
    var rgbBuffer: CVPixelBuffer?
    
    var depthBuffer: CVPixelBuffer?
    
    var vmapBuffer: CVPixelBuffer?
    
    var nmapBuffer: CVPixelBuffer?
    
    var DepthToRGBBuffer: CVPixelBuffer?
    
    var RGBToDepthBuffer: CVPixelBuffer?
    
    var finalVideoPixelBuffer: CVPixelBuffer?
    
    var landmarks: VNFaceLandmarks2D?
    
    var landmarksDlib: [CGPoint]?
    
    var FaceObservation: VNFaceObservation?
    
    var faceBoundingBox: CGRect
    
    var trackedFaceBoundingBox: CGRect
    
    private let filterDepthToVMap = DepthToVMap()
    
    private let filterCoordinateMapper = CoordinateMapper()
    
    private let filterVMapToNMap = VMapToNMap()
    
    private let filterNMapToRGB = NMapToRGBConverter()
    
    private let videoMixer = VideoMixer()
    
    private let videoDepthConverter = DepthToGrayscaleConverter()
    
    private let faceDetection = VNDetectFaceRectanglesRequest ()
    
    private let faceDetectionRequest = VNSequenceRequestHandler()
    
    private let faceLandmarks = VNDetectFaceLandmarksRequest()
    
    private let faceLandmarksDetectionRequest = VNSequenceRequestHandler()
    
    enum RenderMode {
        case normal
        case depth
    }
    
    var showLandmarks = true
    
    var renderStatus: RenderMode = .normal
    
    init(pathIn: String) {
        path = pathIn
        
        // Load Calibration data
        // Open calib.txt file
        var readStringProject = " "
        do {
            readStringProject = try String(contentsOfFile: path+"/Calib.txt", encoding: String.Encoding.utf8)
        } catch let error as NSError {
            print("Failed reading from URL: \(path), Error: " + error.localizedDescription)
        }
        print("content: ", readStringProject) // prints the content of data.json
        
        let buffer = readStringProject.components(separatedBy: ["\n"])
        print("buffer of size: ", buffer.count, ": ", buffer)
        for i in 0...8 {
            intrinsicRGB[i] = (buffer[2+i] as NSString).doubleValue
        }
        for i in 0...8 {
            intrinsicDepth[i] = (buffer[12+i] as NSString).doubleValue
        }
        
        var depthToRGBFloat = Array<Float>(repeating: Float(0.0), count: 16)
        for i in 0...15 {
            depthToRGB[i] = (buffer[21+i] as NSString).doubleValue
        }
        for i in 0...3 {
            for j in 0...3 {
                depthToRGBFloat[i+4*j] = Float(depthToRGB[j+4*i])
            }
        }
        memcpy(depthToRGBMatrix.raw(), UnsafeMutableRawPointer(&depthToRGBFloat), MemoryLayout<Float>.size * 16)
        
        sizeDepth.height = CGFloat((buffer[0] as NSString).floatValue)
        sizeDepth.width = CGFloat((buffer[1] as NSString).floatValue)
        intrinsicDepth[5] = Double(sizeDepth.height)-intrinsicDepth[5] // Because of diff between OpenGL and Image conventions
        
        sizeRGB.height = CGFloat((buffer[37] as NSString).floatValue)
        sizeRGB.width = CGFloat((buffer[38] as NSString).floatValue)
        intrinsicRGB[5] = Double(sizeRGB.height)-intrinsicRGB[5] // Because of diff between OpenGL and Image conventions
        // Create the corresponding 4x4 Matrix
        var intrinsicFloat: [Float] = []
        for _ in 0...16 {
            intrinsicFloat.append(Float(0.0))
        }
        
        intrinsicFloat[0] = Float(intrinsicRGB[0])
        intrinsicFloat[5] = Float(intrinsicRGB[4])
        intrinsicFloat[8] = Float(intrinsicRGB[2])
        intrinsicFloat[9] = Float(intrinsicRGB[5])
        intrinsicFloat[10] = Float(1.0)
        intrinsicFloat[15] = Float(1.0)
        
        memcpy(RGBprojectionMatrix.raw(), UnsafeMutableRawPointer(&intrinsicFloat), MemoryLayout<Float>.size * 16)
        
        faceBoundingBox = CGRect(x: 0, y: 0, width: sizeRGB.width, height: sizeRGB.height)
        trackedFaceBoundingBox = CGRect(x: 0.0, y: 0.0, width: 1.0, height: 1.0)
        
        scale = (buffer[11] as NSString).doubleValue
        
        print("intrinsic depth", intrinsicDepth)
        print("intrinsic color", intrinsicRGB)
        print("depth to color", depthToRGB)
        
        let attrsDepth: [String: Any] = [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_16Gray,
            kCVPixelBufferWidthKey as String: Int(sizeDepth.width),
            kCVPixelBufferHeightKey as String: Int(sizeDepth.height),
            kCVPixelBufferIOSurfacePropertiesKey as String: [:]
        ]
        
        let status = CVPixelBufferCreate(kCFAllocatorDefault,
                                         Int(sizeDepth.width),
                                         Int(sizeDepth.height),
                                         kCVPixelFormatType_16Gray,
                                         attrsDepth as CFDictionary,
                                         &depthBuffer)
        
        if status != kCVReturnSuccess {
            print("Could not allocate depth buffer")
        }
        
        let attrsRGB: [String: Any] = [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
            kCVPixelBufferWidthKey as String: Int(sizeRGB.width),
            kCVPixelBufferHeightKey as String: Int(sizeRGB.height),
            kCVPixelBufferIOSurfacePropertiesKey as String: [:]
        ]
        
        let statusRGB = CVPixelBufferCreate(kCFAllocatorDefault,
                                         Int(sizeRGB.width),
                                         Int(sizeRGB.height),
                                         kCVPixelFormatType_32BGRA,
                                         attrsRGB as CFDictionary,
                                         &rgbBuffer)
        
        if statusRGB != kCVReturnSuccess {
            print("Could not allocate RGB buffer")
        }
    }
    
    func LoadImage() -> Bool {
        depthImage = NSImage(contentsOfFile: path + "/Depth_\(indx).tiff")
        if depthImage == nil {
            print ("Can not load: ", path + "/Depth_\(indx).tiff")
            return false
        }
        
        if (depthImage!.size != sizeDepth) {
            print ("Error in size depth")
            return false
        }
        
        //DispatchQueue.main.async {
            self.RGBImage = NSImage(contentsOfFile: self.path + "/RGB_\(self.indx).tiff")
            if self.RGBImage == nil {
                print ("Can not load: ", self.path + "/RGB_\(self.indx).tiff")
                return false
            }
            
            //if (RGBImage!.size != sizeRGB) {
            //    print ("Error in size RGB")
            //    return false
            //}
            self.RGBPixelBuffer()
        //}
        
        //------------------------------------//
        // Detect Facial landmarks
        //------------------------------------//
        landmarksDlib = LoadLandmarks(path + "/Landmark_\(indx).text")
        
        /*var imageRect:CGRect = CGRect.init(x: 0, y: 0, width: sizeRGB.width, height: sizeRGB.height)
        if FaceObservation == nil {
            try? self.faceDetectionRequest.perform([self.faceDetection], on: (RGBImage?.cgImage(forProposedRect: &imageRect, context: nil, hints: nil))!)
            if self.faceDetection.results?.count == 0 {
                print ("no Faces detected")
            } else {
                FaceObservation = self.faceDetection.results?.first as? VNFaceObservation
                trackedFaceBoundingBox = (FaceObservation?.boundingBox)!
                //let scaleTransform = CGAffineTransform(scaleX: sizeRGB.width, y: sizeRGB.height)
                //faceBoundingBox = faceBoundingBox.applying(scaleTransform)
            }
        }
        
        if FaceObservation != nil{
            if trackedFaceBoundingBox.height == 0.0 {
                trackedFaceBoundingBox = (FaceObservation?.boundingBox)!
            }
            
            let obs = VNFaceObservation.init(boundingBox: trackedFaceBoundingBox)
            faceLandmarks.inputFaceObservations = [obs]
            try? self.faceLandmarksDetectionRequest.perform([faceLandmarks], on: (RGBImage?.cgImage(forProposedRect: &imageRect, context: nil, hints: nil))!)
            
            FaceObservation = faceLandmarks.results?.first! as? VNFaceObservation
            faceBoundingBox = (FaceObservation?.boundingBox)!
            // transform
            let scaleTransform = CGAffineTransform(scaleX: sizeRGB.width, y: sizeRGB.height)
            faceBoundingBox = faceBoundingBox.applying(scaleTransform)
            
            /*let transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
            transform.translatedBy(x: 0, y: sizeRGB.height)
            transform.scaledBy(x: 1.0, y: -1.0)
            faceBoundingBox = faceBoundingBox.applying(transform)*/
        }*/
        
        //------------------------------------//
        // Compute VMap
        // OpenGL convention for coordinate axis
        //------------------------------------//
        DepthPixelBuffer()
        if !filterDepthToVMap.isPrepared {
            var depthFormatDescription: CMFormatDescription?
            CMVideoFormatDescriptionCreateForImageBuffer(kCFAllocatorDefault, depthBuffer!, &depthFormatDescription)
            filterDepthToVMap.setParameters(intrinsic: intrinsicDepth, ref: sizeDepth, scale: Float(scale))
            filterDepthToVMap.prepare(with: depthFormatDescription!, outputRetainedBufferCountHint: 2, width: Int(sizeDepth.width), height: Int(sizeDepth.height))
        }
        vmapBuffer = filterDepthToVMap.render(pixelBuffer: depthBuffer!)
        
        //------------------------------------//
        // Compute RGB to Depth space mapping
        // Standard image convientions; i from left to right, j from top to down
        // this means need to inverse the y coordinate axis after projection
        //------------------------------------//
        if !filterCoordinateMapper.isPrepared {
            var mapFormatDescription: CMFormatDescription?
            CMVideoFormatDescriptionCreateForImageBuffer(kCFAllocatorDefault, vmapBuffer!, &mapFormatDescription)
            filterCoordinateMapper.setParameters(pose: depthToRGB, intrinsic: intrinsicRGB, ref: sizeDepth)
            filterCoordinateMapper.prepare(with: mapFormatDescription!, outputRetainedBufferCountHint: 2, width: Int(sizeDepth.width), height: Int(sizeDepth.height))
        }
        DepthToRGBBuffer = filterCoordinateMapper.DepthToRGB(pixelBuffer: vmapBuffer!)
        RGBToDepthBuffer = filterCoordinateMapper.RGBToDepth(pixelBuffer: vmapBuffer!)
        // Map RGB image to Depth image
       
        
        //------------------------------------//
        // Compute NMap
        //------------------------------------//
        if !filterVMapToNMap.isPrepared {
            var mapFormatDescription: CMFormatDescription?
            CMVideoFormatDescriptionCreateForImageBuffer(kCFAllocatorDefault, vmapBuffer!, &mapFormatDescription)
            filterVMapToNMap.prepare(with: mapFormatDescription!, outputRetainedBufferCountHint: 2, width: Int(sizeDepth.width), height: Int(sizeDepth.height))
        }
        nmapBuffer = filterVMapToNMap.render(pixelBuffer: vmapBuffer!)
        
        indx+=1
        return true
    }
    
    func setFaceBoundingBox(_ box: CGRect) {
        trackedFaceBoundingBox = box
    }
    
    func DepthPixelBuffer() {
        var imRect:NSRect = NSRect.init(x: 0, y: 0, width: sizeDepth.width, height: sizeDepth.height)
        let cgim = depthImage?.cgImage(forProposedRect: &imRect, context: nil, hints: nil)
        let pixelData = cgim?.dataProvider?.data
        let data: UnsafePointer<UInt8> = CFDataGetBytePtr(pixelData)
        let uint16pointer = UnsafeRawPointer(data).bindMemory(to: UInt16.self, capacity: 1)
        
        CVPixelBufferLockBaseAddress(depthBuffer!, CVPixelBufferLockFlags(rawValue: 0));
        let int16Buffer = unsafeBitCast(CVPixelBufferGetBaseAddress(depthBuffer!), to: UnsafeMutablePointer<UInt16>.self)
        
        int16Buffer.initialize(from: uint16pointer, count: Int(sizeDepth.width*sizeDepth.height))
        
        CVPixelBufferUnlockBaseAddress(depthBuffer!, CVPixelBufferLockFlags(rawValue: 0))

        /*CVPixelBufferLockBaseAddress(depthBuffer!, CVPixelBufferLockFlags(rawValue: 0))
        let pixelData = CVPixelBufferGetBaseAddress(depthBuffer!)
        
        let grayColorSpace = CGColorSpaceCreateDeviceGray()
        guard let context = CGContext(data: pixelData,
                                      width: Int(sizeDepth.width),
                                      height: Int(sizeDepth.height),
                                      bitsPerComponent: 16,
                                      bytesPerRow: CVPixelBufferGetBytesPerRow(depthBuffer!),
                                      space: grayColorSpace,
                                      bitmapInfo: CGImageAlphaInfo.none.rawValue) else {
                                        print("Could not create context")
                                        return
        }
        
        context.translateBy(x: 0, y: sizeDepth.height)
        context.scaleBy(x: 1.0, y: -1.0)
        
        let graphicsContext = NSGraphicsContext(cgContext: context, flipped: false)
        NSGraphicsContext.saveGraphicsState()
        NSGraphicsContext.current = graphicsContext
        depthImage!.draw(in: CGRect(x: 0, y: 0, width: sizeDepth.width, height: sizeDepth.height))
        NSGraphicsContext.restoreGraphicsState()
        
        CVPixelBufferUnlockBaseAddress(depthBuffer!, CVPixelBufferLockFlags(rawValue: 0))*/
    }
    
    func RGBPixelBuffer() {
        /*var imRect:NSRect = NSRect.init(x: 0, y: 0, width: sizeRGB.width, height: sizeRGB.height)
        let cgim = RGBImage?.cgImage(forProposedRect: &imRect, context: nil, hints: nil)
        let pixelData = cgim?.dataProvider?.data
        let data: UnsafePointer<UInt8> = CFDataGetBytePtr(pixelData)
        let uint16pointer = UnsafeRawPointer(data).bindMemory(to: UInt16.self, capacity: 1)
        
        CVPixelBufferLockBaseAddress(rgbBuffer!, CVPixelBufferLockFlags(rawValue: 0));
        let int16Buffer = unsafeBitCast(CVPixelBufferGetBaseAddress(rgbBuffer!), to: UnsafeMutablePointer<UInt16>.self)
        
        int16Buffer.initialize(from: uint16pointer, count: Int(sizeRGB.width*sizeRGB.height))
        
        CVPixelBufferUnlockBaseAddress(rgbBuffer!, CVPixelBufferLockFlags(rawValue: 0))*/
        
        CVPixelBufferLockBaseAddress(rgbBuffer!, CVPixelBufferLockFlags(rawValue: 0))
        let pixelData = CVPixelBufferGetBaseAddress(rgbBuffer!)
        
        let rgbColorSpace = CGColorSpaceCreateDeviceRGB()
        guard let context = CGContext(data: pixelData,
                                      width: Int(sizeRGB.width),
                                      height: Int(sizeRGB.height),
                                      bitsPerComponent: 8,
                                      bytesPerRow: CVPixelBufferGetBytesPerRow(rgbBuffer!),
                                      space: rgbColorSpace,
                                      bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue) else {
                                        print("Could not create context")
                                        return
        }
        
        let graphicsContext = NSGraphicsContext(cgContext: context, flipped: false)
        NSGraphicsContext.saveGraphicsState()
        NSGraphicsContext.current = graphicsContext
        RGBImage!.draw(in: CGRect(x: 0, y: 0, width: sizeRGB.width, height: sizeRGB.height))
        NSGraphicsContext.restoreGraphicsState()
        
        CVPixelBufferUnlockBaseAddress(rgbBuffer!, CVPixelBufferLockFlags(rawValue: 0))
    }
    
    func DrawDlibLandmarks() {
        
        let rectId = CGRect.init(x: 0.0, y: 0.0, width: 1.0, height: 1.0)
        
        drawPoints(PixelBuffer: finalVideoPixelBuffer!, points: landmarksDlib, rect: rectId, size: SIZE_POINT)
    }
    
    func DrawFacialLAndmarks() {
        //==============================
        // Draw landmarks
        //==============================
        drawRect(PixelBuffer: finalVideoPixelBuffer!, rect: faceBoundingBox, lineWidth: 3)
        
        let landmarksResults = (FaceObservation?.landmarks)!
        let landmarksForAlign: [CGPoint] =
            [ (landmarksResults.leftEyebrow?.normalizedPoints[0])!, (landmarksResults.leftEyebrow?.normalizedPoints[1])!, (landmarksResults.leftEyebrow?.normalizedPoints[2])!, (landmarksResults.leftEyebrow?.normalizedPoints[3])!, // left eyebrow
                (landmarksResults.rightEyebrow?.normalizedPoints[0])!, (landmarksResults.rightEyebrow?.normalizedPoints[1])!, (landmarksResults.rightEyebrow?.normalizedPoints[2])!, (landmarksResults.rightEyebrow?.normalizedPoints[3])!, // right eyebrow
                (landmarksResults.noseCrest?.normalizedPoints[0])!, (landmarksResults.noseCrest?.normalizedPoints[1])!, (landmarksResults.noseCrest?.normalizedPoints[2])!, // noseCrest
                (landmarksResults.nose?.normalizedPoints[2])!,
                (landmarksResults.nose?.normalizedPoints[3])!,
                (landmarksResults.nose?.normalizedPoints[4])!,
                (landmarksResults.nose?.normalizedPoints[5])!,
                 (landmarksResults.nose?.normalizedPoints[6])!, // nose
                (landmarksResults.leftEye?.normalizedPoints[0])!,
                 (landmarksResults.leftEye?.normalizedPoints[1])!,
                 (landmarksResults.leftEye?.normalizedPoints[3])!,
                 (landmarksResults.leftEye?.normalizedPoints[4])!,
                 (landmarksResults.leftEye?.normalizedPoints[5])!,
                 (landmarksResults.leftEye?.normalizedPoints[7])!, // left eye
                (landmarksResults.rightEye?.normalizedPoints[0])!, (landmarksResults.rightEye?.normalizedPoints[1])!, (landmarksResults.rightEye?.normalizedPoints[3])!, (landmarksResults.rightEye?.normalizedPoints[4])!, (landmarksResults.rightEye?.normalizedPoints[5])!, (landmarksResults.rightEye?.normalizedPoints[7])!, // right eye
                (landmarksResults.outerLips?.normalizedPoints[0])!, (landmarksResults.outerLips?.normalizedPoints[1])!, (landmarksResults.outerLips?.normalizedPoints[2])!, (landmarksResults.outerLips?.normalizedPoints[3])!, (landmarksResults.outerLips?.normalizedPoints[4])!, (landmarksResults.outerLips?.normalizedPoints[5])!,
                (landmarksResults.outerLips?.normalizedPoints[6])!, (landmarksResults.outerLips?.normalizedPoints[7])!, (landmarksResults.outerLips?.normalizedPoints[8])!,
                (landmarksResults.outerLips?.normalizedPoints[9])!, // outerLips
                (landmarksResults.innerLips?.normalizedPoints[0])!, (landmarksResults.innerLips?.normalizedPoints[1])!, (landmarksResults.innerLips?.normalizedPoints[2])!, (landmarksResults.innerLips?.normalizedPoints[3])!, (landmarksResults.innerLips?.normalizedPoints[4])!, (landmarksResults.innerLips?.normalizedPoints[5])! // innerlips
        ] // up of nose
        drawPoints(PixelBuffer: finalVideoPixelBuffer!, points: landmarksForAlign, rect: faceBoundingBox, size: SIZE_POINT)
        
        //different types of landmarks
        /*let faceContour = FaceObservation?.landmarks?.faceContour
        let faceContourPoint = faceContour?.normalizedPoints
        drawPoints(PixelBuffer: finalVideoPixelBuffer!, points: faceContourPoint, rect: faceBoundingBox, size: SIZE_POINT)
        
        let leftEye = FaceObservation?.landmarks?.leftEye
        let leftEyePoint = leftEye?.normalizedPoints
        drawPoints(PixelBuffer: finalVideoPixelBuffer!, points: leftEyePoint, rect: faceBoundingBox, size: SIZE_POINT)
        
        let rightEye = FaceObservation?.landmarks?.rightEye
        let rightEyePoint = rightEye?.normalizedPoints
        drawPoints(PixelBuffer: finalVideoPixelBuffer!, points: rightEyePoint, rect: faceBoundingBox, size: SIZE_POINT)
        
        let nose = FaceObservation?.landmarks?.nose
        let nosePoint = nose?.normalizedPoints
        drawPoints(PixelBuffer: finalVideoPixelBuffer!, points: nosePoint, rect: faceBoundingBox, size: SIZE_POINT)
        
        let lips = FaceObservation?.landmarks?.innerLips
        let lipsPoint = lips?.normalizedPoints
        drawPoints(PixelBuffer: finalVideoPixelBuffer!, points: lipsPoint, rect: faceBoundingBox, size: SIZE_POINT)
        
        let leftEyebrow = FaceObservation?.landmarks?.leftEyebrow
        let leftEyebrowPoint = leftEyebrow?.normalizedPoints
        drawPoints(PixelBuffer: finalVideoPixelBuffer!, points: leftEyebrowPoint, rect: faceBoundingBox, size: SIZE_POINT)
        
        let rightEyebrow = FaceObservation?.landmarks?.rightEyebrow
        let rightEyebrowPoint = rightEyebrow?.normalizedPoints
        drawPoints(PixelBuffer: finalVideoPixelBuffer!, points: rightEyebrowPoint, rect: faceBoundingBox, size: SIZE_POINT)
        
        let noseCrest = FaceObservation?.landmarks?.noseCrest
        let noseCrestPoint = noseCrest?.normalizedPoints
        drawPoints(PixelBuffer: finalVideoPixelBuffer!, points: [noseCrestPoint![2]], rect: faceBoundingBox, size: 3)
        
        let outerLips = FaceObservation?.landmarks?.outerLips
        let outerLipsPoint = outerLips?.normalizedPoints
        drawPoints(PixelBuffer: finalVideoPixelBuffer!, points: outerLipsPoint, rect: faceBoundingBox, size: SIZE_POINT)*/
    }
    
    func Draw() {
        switch renderStatus {
        case .depth:
            if !videoDepthConverter.isPrepared {
                var formatDescription: CMFormatDescription?
                CMVideoFormatDescriptionCreateForImageBuffer(kCFAllocatorDefault, depthBuffer!, &formatDescription)
                videoDepthConverter.prepare(with: formatDescription!, outputRetainedBufferCountHint: 3, width: Int(sizeDepth.width), height: Int(sizeDepth.height))
            }
            guard let convertedBuffer = videoDepthConverter.render(pixelBuffer: depthBuffer!, mapperBuffer: DepthToRGBBuffer!)  else {
                print("Unable to convert nmap to rgb")
                return
            }
            finalVideoPixelBuffer = convertedBuffer
            
            if !videoMixer.isPrepared {
                var formatDescription: CMFormatDescription?
                CMVideoFormatDescriptionCreateForImageBuffer(kCFAllocatorDefault, finalVideoPixelBuffer!, &formatDescription)
                videoMixer.prepare(with: formatDescription!, outputRetainedBufferCountHint: 3)
            }
            
            guard let mixedBuffer = videoMixer.mix(videoPixelBuffer: finalVideoPixelBuffer!, colorPixelBuffer: rgbBuffer!) else {
                print("Unable to combine video and depth")
                return
            }
            
            finalVideoPixelBuffer = mixedBuffer
            
            if showLandmarks {
                DrawDlibLandmarks()
            }
            
            break
        case .normal:
            if !filterNMapToRGB.isPrepared {
                var formatDescription: CMFormatDescription?
                CMVideoFormatDescriptionCreateForImageBuffer(kCFAllocatorDefault, nmapBuffer!, &formatDescription)
                filterNMapToRGB.prepare(with: formatDescription!, outputRetainedBufferCountHint: 3, width: Int(sizeDepth.width), height: Int(sizeDepth.height))
            }
            guard let convertedBuffer = filterNMapToRGB.render(pixelBuffer: nmapBuffer!, mapperBuffer: DepthToRGBBuffer!)  else {
                print("Unable to convert nmap to rgb")
                return
            }
            finalVideoPixelBuffer = convertedBuffer
            
            if !videoMixer.isPrepared {
                var formatDescription: CMFormatDescription?
                CMVideoFormatDescriptionCreateForImageBuffer(kCFAllocatorDefault, finalVideoPixelBuffer!, &formatDescription)
                videoMixer.prepare(with: formatDescription!, outputRetainedBufferCountHint: 3)
            }
            
            guard let mixedBuffer = videoMixer.mix(videoPixelBuffer: finalVideoPixelBuffer!, colorPixelBuffer: rgbBuffer!) else {
                print("Unable to combine video and depth")
                return
            }
            
            finalVideoPixelBuffer = mixedBuffer
            
            if showLandmarks {
                DrawDlibLandmarks()
            }
            break
        }
    }
    
    func changeMixFactor(mixFactor: Float) {
        videoMixer.mixFactor = mixFactor
    }
    
    func changeLandmarkStatus() {
        showLandmarks = !showLandmarks
    }
    
    func getLandmarks() -> [CGPoint]? {
        if let landmarksResults = FaceObservation!.landmarks {
            let landmarksForAlign: [CGPoint] =
                [ (landmarksResults.leftEyebrow?.normalizedPoints[0])!,
                  CGPoint.init(x: -1.0, y: -1.0),
                  (landmarksResults.leftEyebrow?.normalizedPoints[1])!,
                   (landmarksResults.leftEyebrow?.normalizedPoints[2])!,
                   (landmarksResults.leftEyebrow?.normalizedPoints[3])!, // left eyebrow
                    (landmarksResults.rightEyebrow?.normalizedPoints[0])!,
                    (landmarksResults.rightEyebrow?.normalizedPoints[1])!,
                    CGPoint.init(x: -1.0, y: -1.0),
                    (landmarksResults.rightEyebrow?.normalizedPoints[2])!,
                    (landmarksResults.rightEyebrow?.normalizedPoints[3])!, // right eyebrow
                    (landmarksResults.noseCrest?.normalizedPoints[0])!,
                    (landmarksResults.noseCrest?.normalizedPoints[1])!,
                    CGPoint.init(x: -1.0, y: -1.0),
                    (landmarksResults.noseCrest?.normalizedPoints[2])!, // noseCrest
                    (landmarksResults.nose?.normalizedPoints[2])!,
                    (landmarksResults.nose?.normalizedPoints[3])!,
                    (landmarksResults.nose?.normalizedPoints[4])!,
                    (landmarksResults.nose?.normalizedPoints[5])!,
                    (landmarksResults.nose?.normalizedPoints[6])!, // nose
                    (landmarksResults.leftEye?.normalizedPoints[0])!,
                    (landmarksResults.leftEye?.normalizedPoints[1])!,
                    (landmarksResults.leftEye?.normalizedPoints[3])!,
                    (landmarksResults.leftEye?.normalizedPoints[4])!,
                    (landmarksResults.leftEye?.normalizedPoints[5])!,
                    (landmarksResults.leftEye?.normalizedPoints[7])!, // left eye
                    (landmarksResults.rightEye?.normalizedPoints[0])!,
                    (landmarksResults.rightEye?.normalizedPoints[1])!,
                    (landmarksResults.rightEye?.normalizedPoints[3])!,
                    (landmarksResults.rightEye?.normalizedPoints[4])!,
                    (landmarksResults.rightEye?.normalizedPoints[5])!,
                    (landmarksResults.rightEye?.normalizedPoints[7])!, // right eye
                    (landmarksResults.outerLips?.normalizedPoints[9])!,
                    (landmarksResults.outerLips?.normalizedPoints[0])!,
                    (landmarksResults.outerLips?.normalizedPoints[1])!,
                    (landmarksResults.outerLips?.normalizedPoints[2])!,
                    (landmarksResults.outerLips?.normalizedPoints[3])!,
                    (landmarksResults.outerLips?.normalizedPoints[4])!,
                    (landmarksResults.outerLips?.normalizedPoints[5])!,
                    (landmarksResults.outerLips?.normalizedPoints[6])!,
                    CGPoint.init(x: -1.0, y: -1.0),
                    (landmarksResults.outerLips?.normalizedPoints[7])!,
                    CGPoint.init(x: -1.0, y: -1.0),
                    (landmarksResults.outerLips?.normalizedPoints[8])!,
                    // outerLips
                    CGPoint.init(x: -1.0, y: -1.0),
                    (landmarksResults.innerLips?.normalizedPoints[0])!,
                    (landmarksResults.innerLips?.normalizedPoints[1])!,
                    (landmarksResults.innerLips?.normalizedPoints[2])!,
                    CGPoint.init(x: -1.0, y: -1.0),
                    (landmarksResults.innerLips?.normalizedPoints[3])!,
                    (landmarksResults.innerLips?.normalizedPoints[4])!,
                    (landmarksResults.innerLips?.normalizedPoints[5])! // innerlips
            ] // up of nose
            return landmarksForAlign
        } else {
            return nil
        }
    }
    
    func getrectLandmarks() -> CGRect {
        return faceBoundingBox
    }
    
    func getLandmarksDlib() -> [CGPoint]? {
        return landmarksDlib
    }
    
    func getRectId() -> CGRect {
        return CGRect.init(x: 0.0, y: 0.0, width: 1.0, height: 1.0)
    }
}

