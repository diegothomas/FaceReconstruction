//
//  CaptureController.swift
//  WrinkleMe-mac
//
//  Created by Diego Thomas on 2018/02/09.
//  Copyright © 2018 3DLab. All rights reserved.
//

import Cocoa

extension Date {
    var millisecondsSince1970:Double {
        return (self.timeIntervalSince1970 * 1000.0)
    }
    
    init(milliseconds:Int) {
        self = Date(timeIntervalSince1970: TimeInterval(milliseconds / 1000))
    }
}

enum FusionMethod {
    case VMP
    case Mean
    case Median
}

protocol CaptureDelegate: class {
    func UpdateFPSLabel(text: String)
}

class CaptureController: NSViewController, CaptureMenuDelegate {
    
    @IBOutlet var previewView: PreviewMetalView!
    
    @IBOutlet var meshView: MeshMetalView!
    
    weak var captureDelegate: CaptureDelegate?
    
    var path: String? = nil
    
    var isRunning = false
    
    var renderMode: RGBDController.RenderMode = .normal
    
    var changeLandmarkStatus = false
    
    var changeMixFactor = false
    
    var fusion = FusionMethod.VMP
    
    var mixFactor: Float = 0.5
    
    var fpsValue = 0.0
    var prevTime = Date().millisecondsSince1970
    var elapsedTime: Double?
    
    var rgbdController: RGBDController? = nil
    
    var blendshapeController: Blendshapes!
    
    var Tracker = RegisterController()
    
    private let captureQueue = DispatchQueue(label: "capture queue", qos: DispatchQoS.userInitiated, attributes: [DispatchQueue.Attributes.concurrent], autoreleaseFrequency: .workItem)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //let appDelegate = NSApplication.shared.delegate as! AppDelegate
        //blendshapeController = appDelegate.blendshapeMeshes as Blendshapes
        //print("nb blendshapes: ", blendshapeController.size())
        //blendshapeController.idx(position: 0).scale(factor: float2(0.01))
        
        Tracker = RegisterController()
        
        DispatchQueue.main.async {
            self.meshView.loadData(dataSize: WIDTH_BUMP*HEIGHT_BUMP*4, indices: self.blendshapeController.indices())
               // vertices: self.blendshapeController.idx(position: 0).vertices(), faces: self.blendshapeController.idx(position: 0).faces())
            self.meshView.isPaused = false
        }
        
        previewView.rotation = .rotate0Degrees
        previewView.mirroring = false
        
        // Do any additional setup after loading the view.
        if (path != nil) {
            // Create the rgbd image controller
            rgbdController = RGBDController(pathIn: path!)
            
            if (rgbdController!.LoadImage()) {
                rgbdController!.Draw()
                previewView.pixelBuffer = rgbdController!.finalVideoPixelBuffer
                //meshView.setProjectionMatrix(intrinsic: rgbdController!.intrinsicDepth)
                blendshapeController.drawLandmarks(PixelBuffer: (rgbdController?.finalVideoPixelBuffer!)!, depthToRGB: (rgbdController?.depthToRGB)!, pose: self.Tracker.getPose(), size: 1)
            }
            
        } else {
            print("Show error message")
        }
    }
    
    func setDrawParameters() {
        rgbdController!.renderStatus = renderMode
        
        if changeLandmarkStatus {
            rgbdController!.changeLandmarkStatus()
            changeLandmarkStatus = false
        }
        
        if changeMixFactor {
            self.rgbdController!.changeMixFactor(mixFactor: mixFactor)
            changeMixFactor = false
        }
    }
    
    func StartCapture() {
        isRunning = true
        //self.meshView.objectToDraw.Recorder?.startRecording()
        
        while (isRunning) {
            if self.meshView.objectToDraw.record {
                continue
            }
            
            if !rgbdController!.LoadImage() {
                break
            }
            
            captureQueue.async {
                self.setDrawParameters()
                self.rgbdController!.Draw()
                //self.previewView.pixelBuffer = self.rgbdController!.finalVideoPixelBuffer
            }
            
            // Reset variance every 100 frames
            //if (rgbdController!.indx % 100) == 0{
            //    blendshapeController.ResetVariance()
            //}
            
            //============
            // Track head pose
            //============
            //if rgbdController!.indx > 30 {
                
                ///////////////// TEST
                
                /*for i in 0...27 {
                    let value = Float(drand48())
                    blendshapeController.setCoeff(i, value)
                }
                
                let init_coeff = blendshapeController.getCoeff()
                
                blendshapeController.ComputeVMap()
                
                blendshapeController.ComputeNMap()
                
                for i in 0...27 {
                    blendshapeController.setCoeff(i, 0.0)
                }
                
                Tracker.TrackExpression(blendshapeController, blendshapeController.getVMap(), blendshapeController.getNMap(), (rgbdController?.intrinsicDepth)!, (rgbdController?.sizeDepth)!, rgbdController?.getLandmarks(), (rgbdController?.getrectLandmarks())!, (rgbdController?.intrinsicDepth)!, (rgbdController?.depthToRGB)!)
                
                var res_coeff = Array<Float>.init(repeating: Float(0.0), count: 28)
                let optimized_coeff = blendshapeController.getCoeff()
                for i in 0...27 {
                    res_coeff[i] = init_coeff[i] - optimized_coeff[i]
                }
                print(res_coeff)*/
                
                ///////////////// TEST
                
                Tracker.GICP(blendshapeController.getVMap(), blendshapeController.getNMap(), (rgbdController?.vmapBuffer)!, (rgbdController?.intrinsicDepth)!, (rgbdController?.sizeDepth)!, blendshapeController.getLandmarks(), rgbdController?.getLandmarksDlib(), (rgbdController?.getRectId())!, (rgbdController?.intrinsicRGB)!, (rgbdController?.depthToRGB)!)
                
                Tracker.TrackExpression(blendshapeController, (rgbdController?.vmapBuffer)!, (rgbdController?.nmapBuffer)!, (rgbdController?.RGBToDepthBuffer)!, (rgbdController?.intrinsicDepth)!, (rgbdController?.sizeDepth)!, rgbdController?.getLandmarksDlib(), (rgbdController?.getRectId())!, (rgbdController?.intrinsicRGB)!, (rgbdController?.depthToRGB)!, fusion == .VMP)
            //}
            
            captureQueue.async {
                self.meshView.setModelViewMatrix(self.Tracker.getPose())
                self.rgbdController?.setFaceBoundingBox(self.blendshapeController.getFaceBBox(self.Tracker.getPose(), (self.rgbdController?.intrinsicRGB)!, (self.rgbdController?.depthToRGB)!))
            }
            
            //==================
            //Recompute 3D data
            //==================
            
            ///////////////// TEST
            
            /*blendshapeController.ComputeVMapTemplate()
            
            blendshapeController.ComputeNMap()
            
            meshView.flag = false
            self.meshView.objectToDraw.updateVertexBuffer(VMapBuffer: blendshapeController.getVMap(), NMapBuffer: blendshapeController.getNMap(), RGBBuffer: blendshapeController.getRGBMap())
            
            meshView.setModelViewMatrix(Tracker.getPose())
            
            meshView.draw()
            
            blendshapeController.OcclusionLabelling(depthTexture: meshView.objectToDraw.mainPassDepthTexture, modelViewMatrix: meshView.modelViewMatrix, projectionMatrix: meshView.projectionMatrix)*/
            
            ///////////////// TEST
            
            switch fusion {
            case .VMP:
                blendshapeController.UpdateBumpVMP(inputRGBD: rgbdController!, pose: self.Tracker.getPose())
                blendshapeController.BilateralFilerBump(size: 3, s_r: 0.05, s_d: 4, s_c: 0.002, VMPFlag: fusion == .VMP)
            case .Mean:
                blendshapeController.UpdateBump(inputRGBD: rgbdController!, pose: self.Tracker.getPose())
                blendshapeController.BilateralFilerBump(size: 3, s_r: 0.005, s_d: 4, s_c: 0.002, VMPFlag: fusion == .VMP)
            case .Median:
                blendshapeController.UpdateBumpMedian(inputRGBD: rgbdController!, pose: self.Tracker.getPose())
                blendshapeController.BilateralFilerBump(size: 3, s_r: 0.005, s_d: 4, s_c: 0.002, VMPFlag: fusion == .VMP)
            }
            
            blendshapeController.ComputeVMap(VMPFlag: fusion == .VMP)
            
            blendshapeController.ComputeNMap()
            
            blendshapeController.ComputeRGBMap(RGBSensor: (rgbdController?.rgbBuffer)!, projectionMatrix: (rgbdController?.RGBprojectionMatrix)!, calibMatrix: (rgbdController?.depthToRGBMatrix)!, Pose: self.Tracker.getPose())
            
            blendshapeController.UpdateIndices(indices: meshView.objectToDraw.indexBuffer)
            
            self.meshView.objectToDraw.updateVertexBuffer(VMapBuffer: blendshapeController.getVMap(), NMapBuffer: blendshapeController.getNMap(), RGBBuffer: blendshapeController.getRGBMap())
            
            //self.meshView.objectToDraw.record = true
            //meshView.flag = true
            
            blendshapeController.drawLandmarks(PixelBuffer: (rgbdController?.finalVideoPixelBuffer!)!, depthToRGB: (rgbdController?.depthToRGB)!, pose: self.Tracker.getPose(), size: 1)
            self.previewView.pixelBuffer = self.rgbdController!.finalVideoPixelBuffer
            
            // Update fps
            if elapsedTime == nil {elapsedTime = Date().millisecondsSince1970 - prevTime}
            else {elapsedTime = (9.0*elapsedTime! + Date().millisecondsSince1970 - prevTime)/10.0}
            prevTime = Date().millisecondsSince1970
            fpsValue = 1000.0/elapsedTime!
            self.captureDelegate?.UpdateFPSLabel(text: "\(Int(self.fpsValue.rounded())) fps")
            
        }
    }
    
    func PauseCapture() {
        isRunning = false
        self.meshView.objectToDraw.Recorder?.endRecording {
            self.meshView.objectToDraw.record = false
            print ("Done")
        }
    }
    
    func SetRenderMode(value: String) {
        switch value {
        case "Depth":
            renderMode = .depth
            break
        case "Normals":
            renderMode = .normal
            break
        default:
            break
        }
        
        if !isRunning {
            captureQueue.async {
                self.setDrawParameters()
                self.rgbdController!.Draw()
                self.blendshapeController.drawLandmarks(PixelBuffer: (self.rgbdController?.finalVideoPixelBuffer!)!, depthToRGB: (self.rgbdController?.depthToRGB)!, pose: self.Tracker.getPose(), size: 1)
                self.previewView.pixelBuffer = self.rgbdController!.finalVideoPixelBuffer
            }
        }
    }
    
    func ChangeLandmarksStatus() {
        changeLandmarkStatus = true
        if !isRunning {
            captureQueue.async {
                self.setDrawParameters()
                self.rgbdController!.Draw()
                self.blendshapeController.drawLandmarks(PixelBuffer: (self.rgbdController?.finalVideoPixelBuffer!)!, depthToRGB: (self.rgbdController?.depthToRGB)!, pose: self.Tracker.getPose(), size: 1)
                self.previewView.pixelBuffer = self.rgbdController!.finalVideoPixelBuffer
            }
        }
    }
    
    func ChangeMixFactor(mixFactorIn: Float) {
        changeMixFactor = true
        mixFactor = mixFactorIn
        if !isRunning {
            captureQueue.async {
                self.setDrawParameters()
                self.rgbdController!.Draw()
                self.blendshapeController.drawLandmarks(PixelBuffer: (self.rgbdController?.finalVideoPixelBuffer!)!, depthToRGB: (self.rgbdController?.depthToRGB)!, pose: self.Tracker.getPose(), size: 1)
                self.previewView.pixelBuffer = self.rgbdController!.finalVideoPixelBuffer
            }
        }
    }
    
    func initSystem () {
        //===========================
        // Initialize blendshapes with first input RGB-D image
        //===========================
        rgbdController!.indx = 10
        while (!blendshapeController.initWithRGBDDlib(inputRGBD: rgbdController!)) {
            if (!rgbdController!.LoadImage()) {
                print("Initialization failed")
                break
            }
        }
        
        switch fusion {
        case .VMP:
            blendshapeController.UpdateBumpVMP(inputRGBD: rgbdController!, pose: self.Tracker.getPose())
            blendshapeController.BilateralFilerBump(size: 3, s_r: 0.05, s_d: 4, s_c: 0.002, VMPFlag: fusion == .VMP)
        case .Mean:
            blendshapeController.UpdateBump(inputRGBD: rgbdController!, pose: self.Tracker.getPose())
            blendshapeController.BilateralFilerBump(size: 3, s_r: 0.005, s_d: 4, s_c: 0.002, VMPFlag: fusion == .VMP)
        case .Median:
            blendshapeController.UpdateBumpMedian(inputRGBD: rgbdController!, pose: self.Tracker.getPose())
            blendshapeController.BilateralFilerBump(size: 3, s_r: 0.005, s_d: 4, s_c: 0.002, VMPFlag: fusion == .VMP)
        }
        
        blendshapeController.ComputeVMap(VMPFlag: fusion == .VMP)
        
        blendshapeController.ComputeNMap()
        
        blendshapeController.ComputeRGBMap(RGBSensor: (rgbdController?.rgbBuffer)!, projectionMatrix: (rgbdController?.RGBprojectionMatrix)!, calibMatrix: (rgbdController?.depthToRGBMatrix)!, Pose: self.Tracker.getPose())
        
        blendshapeController.UpdateIndices(indices: meshView.objectToDraw.indexBuffer)
        
        self.meshView.objectToDraw.updateVertexBuffer(VMapBuffer: blendshapeController.getVMap(), NMapBuffer: blendshapeController.getNMap(), RGBBuffer: blendshapeController.getRGBMap())
        
        self.rgbdController!.Draw()
        blendshapeController.drawLandmarks(PixelBuffer: (rgbdController?.finalVideoPixelBuffer!)!, depthToRGB: (rgbdController?.depthToRGB)!, pose: self.Tracker.getPose(), size: 1)
        self.previewView.pixelBuffer = self.rgbdController!.finalVideoPixelBuffer
    }
    
    func SetNeutral() {
        for i in 0...27 {
            blendshapeController.setCoeff(i, 0.0)
        }
        
        blendshapeController.ComputeVMap()
        
        blendshapeController.ComputeNMap()
        
        self.meshView.objectToDraw.updateVertexBuffer(VMapBuffer: blendshapeController.getVMap(), NMapBuffer: blendshapeController.getNMap(), RGBBuffer: blendshapeController.getRGBMap())
        
        self.rgbdController!.Draw()
        blendshapeController.drawLandmarks(PixelBuffer: (rgbdController?.finalVideoPixelBuffer!)!, depthToRGB: (rgbdController?.depthToRGB)!, pose: self.Tracker.getPose(), size: 1)
        self.previewView.pixelBuffer = self.rgbdController!.finalVideoPixelBuffer
    }
    
    func ChangeCoeff(_ ID: Int, _ coeff: Float) {
        blendshapeController.setCoeff(ID, coeff)
        
        blendshapeController.ComputeVMap()
        
        blendshapeController.ComputeNMap()
        
        self.meshView.objectToDraw.updateVertexBuffer(VMapBuffer: blendshapeController.getVMap(), NMapBuffer: blendshapeController.getNMap(), RGBBuffer: blendshapeController.getRGBMap())
        
        self.rgbdController!.Draw()
        blendshapeController.drawLandmarks(PixelBuffer: (rgbdController?.finalVideoPixelBuffer!)!, depthToRGB: (rgbdController?.depthToRGB)!, pose: self.Tracker.getPose(), size: 1)
        self.previewView.pixelBuffer = self.rgbdController!.finalVideoPixelBuffer
    }
    
    func ChangeMethod(_ Flag: FusionMethod) {
        fusion = Flag
        
        blendshapeController.SetBump(fusion == .VMP)
        
        switch fusion {
        case .VMP:
            print("Running with VMP")
        case .Mean:
            print("Running with Mean")
        case .Median:
            print("Running with Median")
        }
        
    }
    
    func ChangeTemplate (_ TemplateID: Int) {
        switch TemplateID {
        case 0:
            blendshapeController.SetTemplate(rootname: "MeshO")
            break
        case 1:
            blendshapeController.SetTemplate(rootname: "MeshR")
            break
        case 2:
            blendshapeController.SetTemplate(rootname: "MeshK")
            break
        case 3:
            blendshapeController.SetTemplate(rootname: "Mesh7")
            break
        case 4:
            blendshapeController.SetTemplate(rootname: "MeshW1")
            break
        case 5:
            blendshapeController.SetTemplate(rootname: "MeshW2")
            break
        default:
            blendshapeController.SetTemplate(rootname: "MeshO")
            break
        }
    }
    
}

