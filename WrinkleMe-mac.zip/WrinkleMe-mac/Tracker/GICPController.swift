//
//  GICP.swift
//  WrinkleMe-mac
//
//  Created by Diego Thomas on 2018/03/09.
//  Copyright © 2018 3DLab. All rights reserved.
//

import Foundation
import CoreMedia
import CoreVideo
import Metal

class GICPController {
    var description: String = "GICP"
    
    var isPrepared = false
    
    private(set) var inputFormatDescription: CMFormatDescription?
    
    private var inputTextureFormat: MTLPixelFormat = .invalid
    
    private let metalDevice = MTLCreateSystemDefaultDevice()!
    
    private var computePipelineState: MTLComputePipelineState?
    private var computePipelineStateReduce: MTLComputePipelineState?
    
    private lazy var commandQueue: MTLCommandQueue? = {
        return self.metalDevice.makeCommandQueue()
    }()
    
    private var textureCache: CVMetalTextureCache!
    
    private var calibBuffer: MTLBuffer
    
    let sizeOfCalib = MemoryLayout<Float>.size * 32// + MemoryLayout<Int32>.size
    
    private var JBuffer: MTLBuffer
    private var OutBuffer: MTLBuffer
    
    private var threadsPerThreadgroup: MTLSize?
    private var threadgroupsPerGrid: MTLSize?
    
    private var threadsPerThreadgroupReduce: MTLSize?
    private var threadgroupsPerGridReduce: MTLSize?
    
    private var offset: Int32 = 0
    
    private var widthIn = 0
    private var heightIn = 0
    
    required init() {
        let defaultLibrary = metalDevice.makeDefaultLibrary()!
        let kernelFunction = defaultLibrary.makeFunction(name: "GICP")
        do {
            computePipelineState = try metalDevice.makeComputePipelineState(function: kernelFunction!)
        } catch {
            fatalError("Unable to create bumpMap pipeline state. (\(error))")
        }
        
        let kernelFunctionReduce = defaultLibrary.makeFunction(name: "reduce_buffer")
        do {
            computePipelineStateReduce = try metalDevice.makeComputePipelineState(function: kernelFunctionReduce!)
        } catch {
            fatalError("Unable to create bumpMap pipeline state. (\(error))")
        }
        
        calibBuffer = metalDevice.makeBuffer(length: sizeOfCalib, options: [])!
        JBuffer = metalDevice.makeBuffer(length: 1, options: [])! // 60 * MemoryLayout<Float>.size * 27 is for the case of a 240*240 bump image
        OutBuffer = metalDevice.makeBuffer(length: MemoryLayout<Float>.size * 27, options: [])!
    }
    
    
    func prepare(with formatDescription: CMFormatDescription, width: Int, height: Int) {
        reset()
        
        widthIn = width
        heightIn = height
        inputFormatDescription = formatDescription
        
        let inputMediaSubType = CMFormatDescriptionGetMediaSubType(formatDescription)
        if inputMediaSubType == kCVPixelFormatType_128RGBAFloat {
            inputTextureFormat = .rgba32Float
        } else {
            assertionFailure("Input format not supported")
        }
        
        var metalTextureCache: CVMetalTextureCache?
        if CVMetalTextureCacheCreate(kCFAllocatorDefault, nil, metalDevice, nil, &metalTextureCache) != kCVReturnSuccess {
            assertionFailure("Unable to allocate depth to vmap texture cache")
        } else {
            textureCache = metalTextureCache
        }
        
        
        // Set up thread groups as described in https://developer.apple.com/reference/metal/mtlcomputecommandencoder
        let w = computePipelineState!.threadExecutionWidth
        let h = computePipelineState!.maxTotalThreadsPerThreadgroup / w
        threadsPerThreadgroup = MTLSizeMake(w, h, 1)
        if (w*h != 1024) {
            print("thread group size does not match 1024: ", threadsPerThreadgroup!)
        }
        threadgroupsPerGrid = MTLSize(width: (width + w - 1) / w,
                                          height: (height + h - 1) / h,
                                          depth: 1)
        //inputTexture0.width
        //print(threadgroupsPerGrid)
        
        JBuffer = metalDevice.makeBuffer(length: (threadgroupsPerGrid?.width)!*(threadgroupsPerGrid?.height)! * MemoryLayout<Float>.size * 27, options: [])!
        
        
        offset = Int32(threadgroupsPerGrid!.width*threadgroupsPerGrid!.height)
        //print("w: ", w)
        //print("offset: ", offset)
        let hReduce = (Int(offset) + w-1)/w
        //print("hReduce", hReduce)
        if (w*hReduce > computePipelineState!.maxTotalThreadsPerThreadgroup) {
            print("thread group size too big: ", hReduce*w)
        }
        threadsPerThreadgroupReduce = MTLSizeMake(w, hReduce, 1)
        
        threadgroupsPerGridReduce = MTLSize(width: 27, height: 1, depth: 1)
        //print(threadgroupsPerGridReduce)
        
        isPrepared = true
    }
    
    func reset() {
        isPrepared = false
    }
    
    func Run(sourceVMap: CVPixelBuffer, sourceNMap: CVPixelBuffer, targetVMap: CVPixelBuffer, Pose: float4x4, lvl: Int) -> MTLBuffer? {
        if !isPrepared {
            assertionFailure("Invalid state: Not prepared")
            return nil
        }
        
        var tmp: [Float] = [Pose.columns.0.x, Pose.columns.0.y, Pose.columns.0.z, Pose.columns.0.w,
                            Pose.columns.1.x, Pose.columns.1.y, Pose.columns.1.z, Pose.columns.1.w,
                            Pose.columns.2.x, Pose.columns.2.y, Pose.columns.2.z, Pose.columns.2.w,
                            Pose.columns.3.x, Pose.columns.3.y, Pose.columns.3.z, Pose.columns.3.w]
        memcpy(calibBuffer.contents(), UnsafeMutableRawPointer(&tmp), MemoryLayout<Float>.size * 16)
        var tmpint = Int32(lvl)
        
        guard let inputTexture0 = makeTextureFromCVPixelBuffer(pixelBuffer: sourceVMap , textureFormat: inputTextureFormat),
            let inputTexture1 = makeTextureFromCVPixelBuffer(pixelBuffer: sourceNMap, textureFormat: inputTextureFormat),
            let inputTexture2 = makeTextureFromCVPixelBuffer(pixelBuffer: targetVMap, textureFormat: inputTextureFormat)   else {
                return nil
        }
        
        // Set up command queue, buffer, and encoder
        guard let commandQueue = commandQueue,
            let commandBuffer = commandQueue.makeCommandBuffer(),
            let commandEncoder = commandBuffer.makeComputeCommandEncoder() else {
                print("Failed to create Metal command queue")
                CVMetalTextureCacheFlush(textureCache!, 0)
                return nil
        }
        
        //print(lvl)
        
        commandEncoder.label = "GICP"
        commandEncoder.setComputePipelineState(computePipelineState!)
        commandEncoder.setTexture(inputTexture0, index: 0)
        commandEncoder.setTexture(inputTexture1, index: 1)
        commandEncoder.setTexture(inputTexture2, index: 2)
        commandEncoder.setBuffer(calibBuffer, offset: 0, index: 0)
        commandEncoder.setBytes(UnsafeMutableRawPointer(&tmpint), length: MemoryLayout<Int32>.size, index: 1)
        commandEncoder.setBuffer(JBuffer, offset: 0, index: 2)
        
        // Set up thread groups as described in https://developer.apple.com/reference/metal/mtlcomputecommandencoder
        let w = computePipelineState!.threadExecutionWidth
        let h = computePipelineState!.maxTotalThreadsPerThreadgroup / w
        threadsPerThreadgroup = MTLSizeMake(w, h, 1)
        if (w*h != 1024) {
            print("thread group size does not match 1024: ", threadsPerThreadgroup!)
        }
        threadgroupsPerGrid = MTLSize(width: (widthIn/lvl + w - 1) / w,
                                      height: (heightIn/lvl + h - 1) / h,
                                      depth: 1)
        //print(w,h)
        //print(widthIn, heightIn)
        //print(threadgroupsPerGrid)
        commandEncoder.dispatchThreadgroups(threadgroupsPerGrid!, threadsPerThreadgroup: threadsPerThreadgroup!)
        
        commandEncoder.endEncoding()
        
        commandBuffer.commit()
        commandBuffer.waitUntilCompleted()
        
        // Set up command queue, buffer, and encoder
        guard let commandBufferReduce = commandQueue.makeCommandBuffer(),
            let commandEncoderReduce = commandBufferReduce.makeComputeCommandEncoder() else {
                print("Failed to create Metal command queue")
                CVMetalTextureCacheFlush(textureCache!, 0)
                return nil
        }
        
        commandEncoderReduce.label = "reduce_buffer"
        commandEncoderReduce.setComputePipelineState(computePipelineStateReduce!)
        commandEncoderReduce.setBuffer(JBuffer, offset: 0, index: 0)
        commandEncoderReduce.setBuffer(OutBuffer, offset: 0, index: 1)
        commandEncoderReduce.setBytes(UnsafeMutableRawPointer(&offset), length: MemoryLayout<Int32>.size, index: 2)
        
        offset = Int32(threadgroupsPerGrid!.width*threadgroupsPerGrid!.height)
        //print("w: ", w)
        //print("offset: ", offset)
        let hReduce = (Int(offset) + w-1)/w
        //print("hReduce", hReduce)
        if (w*hReduce > computePipelineState!.maxTotalThreadsPerThreadgroup) {
            print("thread group size too big: ", hReduce*w)
        }
        threadsPerThreadgroupReduce = MTLSizeMake(w, hReduce, 1)
        
        threadgroupsPerGridReduce = MTLSize(width: 27, height: 1, depth: 1)
        
        commandEncoderReduce.dispatchThreadgroups(threadgroupsPerGridReduce!, threadsPerThreadgroup: threadsPerThreadgroupReduce!)
        
        commandEncoderReduce.endEncoding()
        
        commandBufferReduce.commit()
        commandBufferReduce.waitUntilCompleted()
        
        return OutBuffer
    }
    
    func setParameters(intrinsic: Array<Double>, ref: NSSize) {
        
        var intrinsicFloat: [Float] = []
        for _ in 0...3 {
            for _ in 0...3 {
                intrinsicFloat.append(Float(0.0))
            }
        }
        intrinsicFloat[0] = Float(DEPTH_WIDTH*intrinsic[0]/Double(ref.width))
        intrinsicFloat[5] = Float(DEPTH_HEIGHT*intrinsic[4]/Double(ref.height))
        intrinsicFloat[8] = Float(DEPTH_WIDTH*intrinsic[2]/Double(ref.width))
        intrinsicFloat[9] = Float(DEPTH_HEIGHT*intrinsic[5]/Double(ref.height))
        intrinsicFloat[10] = Float(1.0)
        intrinsicFloat[15] = Float(1.0)
        
        memcpy(calibBuffer.contents() + MemoryLayout<Float>.size * 16, UnsafeMutableRawPointer(&intrinsicFloat), MemoryLayout<Float>.size * 16)
    }
    
    func makeTextureFromCVPixelBuffer(pixelBuffer: CVPixelBuffer, textureFormat: MTLPixelFormat) -> MTLTexture? {
        let width = CVPixelBufferGetWidth(pixelBuffer)
        let height = CVPixelBufferGetHeight(pixelBuffer)
        
        var cvTextureOut: CVMetalTexture?
        CVMetalTextureCacheCreateTextureFromImage(kCFAllocatorDefault, textureCache, pixelBuffer, nil, textureFormat, width, height, 0, &cvTextureOut)
        
        guard let cvTexture = cvTextureOut, let texture = CVMetalTextureGetTexture(cvTexture) else {
            print("Depth converter failed to create preview texture")
            
            CVMetalTextureCacheFlush(textureCache, 0)
            
            return nil
        }
        
        return texture
    }
}
