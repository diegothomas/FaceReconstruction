//
//  ExpressionController.swift
//  WrinkleMe-mac
//
//  Created by Diego Thomas on 2018/04/12.
//  Copyright © 2018 3DLab. All rights reserved.
//

import Foundation
import CoreMedia
import CoreVideo
import Metal

class ExpressionController {
    var description: String = "Expression"
    
    var isPrepared = false
    
    private(set) var inputFormatDescription: CMFormatDescription?
    
    private var inputTextureFormat: MTLPixelFormat = .invalid
    
    private let metalDevice = MTLCreateSystemDefaultDevice()!
    
    private var computePipelineState: MTLComputePipelineState?
    private var computePipelineStateJTJb: MTLComputePipelineState?
    private var computePipelineStateJTJc: MTLComputePipelineState?
    private var computePipelineStateJTJ: MTLComputePipelineState?
    private var computePipelineStatePseudo: MTLComputePipelineState?
    private var computePipelineStateATC: MTLComputePipelineState?
    
    private lazy var commandQueue: MTLCommandQueue? = {
        return self.metalDevice.makeCommandQueue()
    }()
    
    private var textureCache: CVMetalTextureCache!
    
    private var calibBuffer: MTLBuffer
    
    let sizeOfCalib = MemoryLayout<Float>.size * 32// + MemoryLayout<Int32>.size
    
    private var JBuffer: MTLBuffer
    private var TmpBuffer: MTLBuffer
    private var OutBuffer: MTLBuffer
    private var Pseudo: MTLBuffer
    private var X0: MTLBuffer
    private var CoeffBuffer: MTLBuffer
    private var Counter: MTLBuffer
    
    private var threadsPerThreadgroup: MTLSize?
    private var threadgroupsPerGrid: MTLSize?
    
    private var threadsPerThreadgroupReduce: MTLSize?
    private var threadgroupsPerGridReduce: MTLSize?
    
    private var offset: Int32 = 0
    
    private var widthIn = 0
    private var heightIn = 0
    
    required init() {
        let defaultLibrary = metalDevice.makeDefaultLibrary()!
        let kernelFunction = defaultLibrary.makeFunction(name: "System")
        do {
            computePipelineState = try metalDevice.makeComputePipelineState(function: kernelFunction!)
        } catch {
            fatalError("Unable to create bumpMap pipeline state. (\(error))")
        }
        
        let kernelFunctionjtjtb = defaultLibrary.makeFunction(name: "JTJb")
        do {
            computePipelineStateJTJb = try metalDevice.makeComputePipelineState(function: kernelFunctionjtjtb!)
        } catch {
            fatalError("Unable to create jtjb pipeline state. (\(error))")
        }
        
        let kernelFunctionjtjc = defaultLibrary.makeFunction(name: "JTJc")
        do {
            computePipelineStateJTJc = try metalDevice.makeComputePipelineState(function: kernelFunctionjtjc!)
        } catch {
            fatalError("Unable to create jtjc pipeline state. (\(error))")
        }
        
        let kernelFunctionReduce = defaultLibrary.makeFunction(name: "JTJ")
        do {
            computePipelineStateJTJ = try metalDevice.makeComputePipelineState(function: kernelFunctionReduce!)
        } catch {
            fatalError("Unable to create bumpMap pipeline state. (\(error))")
        }
        
        let kernelFunctionPseudo = defaultLibrary.makeFunction(name: "PseudoInverse")
        do {
            computePipelineStatePseudo = try metalDevice.makeComputePipelineState(function: kernelFunctionPseudo!)
        } catch {
            fatalError("Unable to create bumpMap pipeline state. (\(error))")
        }
        
        let kernelFunctionATC = defaultLibrary.makeFunction(name: "ATC")
        do {
            computePipelineStateATC = try metalDevice.makeComputePipelineState(function: kernelFunctionATC!)
        } catch {
            fatalError("Unable to create bumpMap pipeline state. (\(error))")
        }
        
        calibBuffer = metalDevice.makeBuffer(length: sizeOfCalib, options: [])!
        JBuffer = metalDevice.makeBuffer(length: 1, options: [])!
        Pseudo = metalDevice.makeBuffer(length: 1, options: [])!
        TmpBuffer = metalDevice.makeBuffer(length: MemoryLayout<Float>.size * 405 * 1024, options: [])!
        OutBuffer = metalDevice.makeBuffer(length: MemoryLayout<Float>.size * 27*28, options: [])!
        X0 = metalDevice.makeBuffer(length: MemoryLayout<Float>.size * 27, options: [])!
        CoeffBuffer = metalDevice.makeBuffer(length: MemoryLayout<Float>.size * 28, options: [])!
        Counter = metalDevice.makeBuffer(length: MemoryLayout<uint32>.size, options: [])!
    }
    
    
    func prepare(with formatDescription: CMFormatDescription, width: Int, height: Int) {
        reset()
        
        widthIn = width
        heightIn = height
        inputFormatDescription = formatDescription
        
        let inputMediaSubType = CMFormatDescriptionGetMediaSubType(formatDescription)
        if inputMediaSubType == kCVPixelFormatType_128RGBAFloat {
            inputTextureFormat = .rgba32Float
        } else {
            assertionFailure("Input format not supported")
        }
        
        var metalTextureCache: CVMetalTextureCache?
        if CVMetalTextureCacheCreate(kCFAllocatorDefault, nil, metalDevice, nil, &metalTextureCache) != kCVReturnSuccess {
            assertionFailure("Unable to allocate depth to vmap texture cache")
        } else {
            textureCache = metalTextureCache
        }
        
        JBuffer = metalDevice.makeBuffer(length: widthIn*heightIn * MemoryLayout<Float>.size * 28, options: [])!
        Pseudo = metalDevice.makeBuffer(length: widthIn*heightIn * MemoryLayout<Float>.size * 27, options: [])!
        
        // Set up thread groups as described in https://developer.apple.com/reference/metal/mtlcomputecommandencoder
        let w = computePipelineState!.threadExecutionWidth
        let h = computePipelineState!.maxTotalThreadsPerThreadgroup / w
        threadsPerThreadgroup = MTLSizeMake(w, h, 1)
        if (w*h != 1024) {
            print("thread group size does not match 1024: ", threadsPerThreadgroup!)
        }
        threadgroupsPerGrid = MTLSize(width: (width + w - 1) / w,
                                      height: (height + h - 1) / h,
                                      depth: 1)

        print(threadgroupsPerGrid!)
        //inputTexture0.width
        
        
        offset = Int32(threadgroupsPerGrid!.width*threadgroupsPerGrid!.height)
        //print("w: ", w)
        //print("offset: ", offset)
        let hReduce = (Int(offset) + w-1)/w
        //print("hReduce", hReduce)
        if (w*hReduce > computePipelineState!.maxTotalThreadsPerThreadgroup) {
            print("thread group size too big: ", hReduce*w)
        }
        threadsPerThreadgroupReduce = MTLSizeMake(w, hReduce, 1)
        
        threadgroupsPerGridReduce = MTLSize(width: 405, height: 1, depth: 1)
        //print(threadgroupsPerGridReduce!)
        
        isPrepared = true
    }
    
    func reset() {
        isPrepared = false
    }
    
    func Run(input: Param3D, targetVMap: CVPixelBuffer, targetNMap: CVPixelBuffer, Pose: float4x4, coeff: inout [Float], lvl: Int, VMPFlag: Bool = true) -> uint32 {
        if !isPrepared {
            assertionFailure("Invalid state: Not prepared")
            return 0
        }
        
        var tmp: [Float] = [Pose.columns.0.x, Pose.columns.0.y, Pose.columns.0.z, Pose.columns.0.w,
                            Pose.columns.1.x, Pose.columns.1.y, Pose.columns.1.z, Pose.columns.1.w,
                            Pose.columns.2.x, Pose.columns.2.y, Pose.columns.2.z, Pose.columns.2.w,
                            Pose.columns.3.x, Pose.columns.3.y, Pose.columns.3.z, Pose.columns.3.w]
        memcpy(calibBuffer.contents(), UnsafeMutableRawPointer(&tmp), MemoryLayout<Float>.size * 16)
        
        var tmpint = Int32(lvl)
        
        var tmpC: [uint32] = [0]
        memcpy(Counter.contents(), UnsafeMutableRawPointer(&tmpC), MemoryLayout<uint32>.size)
        
        memcpy(CoeffBuffer.contents(), UnsafeMutableRawPointer(&coeff), 28*MemoryLayout<Float>.size)
        
        guard let inputTexture0 = makeTextureFromCVPixelBuffer(pixelBuffer: input.bumpImage! , textureFormat: inputTextureFormat),
            let inputTexture1 = makeTextureFromCVPixelBuffer(pixelBuffer: input.WLImage!, textureFormat: inputTextureFormat),
            let inputTexture2 = makeTextureFromCVPixelBuffer(pixelBuffer: input.NMap!, textureFormat: inputTextureFormat),
            let inputTexture3 = makeTextureFromCVPixelBuffer(pixelBuffer: targetVMap, textureFormat: inputTextureFormat),
            let inputTexture4 = makeTextureFromCVPixelBuffer(pixelBuffer: targetNMap, textureFormat: inputTextureFormat)    else {
                return 0
        }
        
        var Flag = VMPFlag
        
        // Set up command queue, buffer, and encoder
        guard let commandQueue = commandQueue,
            let commandBuffer = commandQueue.makeCommandBuffer(),
            let commandEncoder = commandBuffer.makeComputeCommandEncoder() else {
                print("Failed to create Metal command queue")
                CVMetalTextureCacheFlush(textureCache!, 0)
                return 0
        }
        
        commandEncoder.label = "System"
        commandEncoder.setComputePipelineState(computePipelineState!)
        commandEncoder.setTexture(inputTexture0, index: 0)
        commandEncoder.setTexture(inputTexture1, index: 1)
        commandEncoder.setTexture(inputTexture2, index: 2)
        commandEncoder.setTexture(inputTexture3, index: 3)
        commandEncoder.setTexture(inputTexture4, index: 4)
        commandEncoder.setBuffer(input.VtxBuffer!, offset: 0, index: 0)
        commandEncoder.setBuffer(input.NmleBuffer!, offset: 0, index: 1)
        commandEncoder.setBuffer(input.FaceBuffer!, offset: 0, index: 2)
        commandEncoder.setBuffer(CoeffBuffer, offset: 0, index: 3)
        commandEncoder.setBuffer(calibBuffer, offset: 0, index: 4)
        commandEncoder.setBuffer(JBuffer, offset: 0, index: 5)
        commandEncoder.setBuffer(Counter, offset: 0, index: 6)
        commandEncoder.setBytes( UnsafeMutableRawPointer(&Flag), length: MemoryLayout<Bool>.size, index: 7)
        commandEncoder.setBytes(UnsafeMutableRawPointer(&tmpint), length: MemoryLayout<Int32>.size, index: 8)
        
        // Set up thread groups as described in https://developer.apple.com/reference/metal/mtlcomputecommandencoder
        let w = computePipelineState!.threadExecutionWidth
        let h = computePipelineState!.maxTotalThreadsPerThreadgroup / w
        threadsPerThreadgroup = MTLSizeMake(w, h, 1)
        if (w*h != 1024) {
            print("thread group size does not match 1024: ", threadsPerThreadgroup!)
        }
        threadgroupsPerGrid = MTLSize(width: (widthIn/lvl + w - 1) / w,
                                      height: (heightIn/lvl + h - 1) / h,
                                      depth: 1)
        //print(threadgroupsPerGrid)
        commandEncoder.dispatchThreadgroups(threadgroupsPerGrid!, threadsPerThreadgroup: threadsPerThreadgroup!)
        
        commandEncoder.endEncoding()
        
        commandBuffer.commit()
        commandBuffer.waitUntilCompleted()
        
        let Counter_pointer = Counter.contents().assumingMemoryBound(to: uint32.self)
        //print("nbmatches: ", Counter_pointer[0])
        
        return Counter_pointer[0]
    }
    
    func JTJalt(_ nblines: Int) -> MTLBuffer? {
        // Set up command queue, buffer, and encoder
        guard let commandQueue = commandQueue,
            let commandBuffer = commandQueue.makeCommandBuffer(),
            let commandEncoder = commandBuffer.makeComputeCommandEncoder() else {
                print("Failed to create Metal command queue")
                CVMetalTextureCacheFlush(textureCache!, 0)
                return nil
        }
        
        let w = computePipelineState!.threadExecutionWidth
        let h = computePipelineState!.maxTotalThreadsPerThreadgroup / w
        threadsPerThreadgroupReduce = MTLSizeMake(w, h, 1)
        let hReduce = (nblines + w*h-1)/(w*h)
        //print("hReduce", hReduce)
        ///print(threadsPerThreadgroupReduce)
        
        if hReduce > 1024 {
            print ("too many points!!")
        }
        
        offset = Int32(nblines)
        
        commandEncoder.label = "JTJb"
        commandEncoder.setComputePipelineState(computePipelineStateJTJb!)
        commandEncoder.setBuffer(JBuffer, offset: 0, index: 0)
        commandEncoder.setBuffer(TmpBuffer, offset: 0, index: 1)
        commandEncoder.setBytes(UnsafeMutableRawPointer(&offset), length: MemoryLayout<Int32>.size, index: 2)
        
        threadgroupsPerGridReduce = MTLSize(width: 405, height: hReduce, depth: 1)
        //print(threadgroupsPerGridReduce)
        commandEncoder.dispatchThreadgroups(threadgroupsPerGridReduce!, threadsPerThreadgroup: threadsPerThreadgroupReduce!)
        
        commandEncoder.endEncoding()
        
        guard let commandEncoderR = commandBuffer.makeComputeCommandEncoder() else {
            print("Failed to create Metal command queue")
            CVMetalTextureCacheFlush(textureCache!, 0)
            return nil
        }
        
        offset = Int32(hReduce)
        
        commandEncoderR.label = "JTJc"
        commandEncoderR.setComputePipelineState(computePipelineStateJTJc!)
        commandEncoderR.setBuffer(TmpBuffer, offset: 0, index: 0)
        commandEncoderR.setBuffer(OutBuffer, offset: 0, index: 1)
        commandEncoderR.setBytes(UnsafeMutableRawPointer(&offset), length: MemoryLayout<Int32>.size, index: 2)
        
        threadgroupsPerGridReduce = MTLSize(width: 405, height: 1, depth: 1)
        //print(threadgroupsPerGridReduce)
        commandEncoderR.dispatchThreadgroups(threadgroupsPerGridReduce!, threadsPerThreadgroup: threadsPerThreadgroupReduce!)
        
        commandEncoderR.endEncoding()
        
        commandBuffer.commit()
        commandBuffer.waitUntilCompleted()
        
        return OutBuffer
    }
    
    func JTJ(_ nblines: Int) -> MTLBuffer? {
        // Set up command queue, buffer, and encoder
        guard let commandQueue = commandQueue,
            let commandBuffer = commandQueue.makeCommandBuffer(),
            let commandEncoder = commandBuffer.makeComputeCommandEncoder() else {
                print("Failed to create Metal command queue")
                CVMetalTextureCacheFlush(textureCache!, 0)
                return nil
        }
        
        offset = Int32(nblines)
        
        commandEncoder.label = "JTJ"
        commandEncoder.setComputePipelineState(computePipelineStateJTJ!)
        commandEncoder.setBuffer(JBuffer, offset: 0, index: 0)
        commandEncoder.setBuffer(OutBuffer, offset: 0, index: 1)
        commandEncoder.setBytes(UnsafeMutableRawPointer(&offset), length: MemoryLayout<Int32>.size, index: 2)
        
        
        let w = computePipelineStateJTJ!.threadExecutionWidth
        let h = computePipelineState!.maxTotalThreadsPerThreadgroup / w
        threadsPerThreadgroupReduce = MTLSizeMake(w, h, 1)
        var hReduce = (Int(offset) + w*h-1)/(w*h)
        print("hReduce", hReduce)
        /*if (w*hReduce > computePipelineStateJTJ!.maxTotalThreadsPerThreadgroup) {
            print("thread group size too big: ", hReduce*w)
            hReduce = computePipelineStateJTJ!.maxTotalThreadsPerThreadgroup / w
        }*/
        //threadsPerThreadgroupReduce = MTLSizeMake(w, hReduce, 1)
        print(threadsPerThreadgroupReduce)
        
        //threadgroupsPerGridReduce = MTLSize(width: 27, height: 28, depth: 1)
        threadgroupsPerGridReduce = MTLSize(width: 405, height: hReduce, depth: 1)
        print(threadgroupsPerGridReduce)
        commandEncoder.dispatchThreadgroups(threadgroupsPerGridReduce!, threadsPerThreadgroup: threadsPerThreadgroupReduce!)
        
        commandEncoder.endEncoding()
        
        commandBuffer.commit()
        commandBuffer.waitUntilCompleted()
        
        return OutBuffer
    }
    
    func PseudoInverse(_ Q_inv: [Double], _ nblines: Int) {
        
        var tmp: [Float] = Array<Float>.init(repeating: Float(0.0), count: 27*27)
        
        for i in 0...27*27-1 {
            tmp[i] = Float(Q_inv[i])
        }
        
        memcpy(OutBuffer.contents(), UnsafeMutableRawPointer(&tmp), MemoryLayout<Float>.size * 27*27)
        
        // Set up command queue, buffer, and encoder
        guard let commandQueue = commandQueue,
            let commandBuffer = commandQueue.makeCommandBuffer(),
            let commandEncoder = commandBuffer.makeComputeCommandEncoder() else {
                print("Failed to create Metal command queue")
                CVMetalTextureCacheFlush(textureCache!, 0)
                return
        }
        
        offset = Int32(nblines)
        
        commandEncoder.label = "PseudoInverse"
        commandEncoder.setComputePipelineState(computePipelineStatePseudo!)
        commandEncoder.setBuffer(JBuffer, offset: 0, index: 0)
        commandEncoder.setBuffer(OutBuffer, offset: 0, index: 1)
        commandEncoder.setBuffer(Pseudo, offset: 0, index: 2)
        commandEncoder.setBytes(UnsafeMutableRawPointer(&offset), length: MemoryLayout<Int32>.size, index: 3)
        
        
        let w = computePipelineStatePseudo!.threadExecutionWidth
        var hReduce = (Int(27*offset) + w-1)/w
        //print("hReduce", hReduce)
        if (w*hReduce > computePipelineStatePseudo!.maxTotalThreadsPerThreadgroup) {
            //print("thread group size too big: ", hReduce*w)
            hReduce = computePipelineStatePseudo!.maxTotalThreadsPerThreadgroup / w
        }
        threadsPerThreadgroupReduce = MTLSizeMake(w, hReduce, 1)
        
        let wh_f = Int(sqrt(Float(27*offset)/Float(w*hReduce)))
        threadgroupsPerGridReduce = MTLSize(width: wh_f + 1,
                                                height: wh_f + 1,
                                                depth: 1)
        //print(threadsPerThreadgroupReduce)
        //print(threadgroupsPerGridReduce)
        commandEncoder.dispatchThreadgroups(threadgroupsPerGridReduce!, threadsPerThreadgroup: threadsPerThreadgroupReduce!)
        
        commandEncoder.endEncoding()
        
        commandBuffer.commit()
        //commandBuffer.waitUntilCompleted()
    }
    
    func ATC(_ nblines: Int) -> MTLBuffer? {
        // Set up command queue, buffer, and encoder
        guard let commandQueue = commandQueue,
            let commandBuffer = commandQueue.makeCommandBuffer(),
            let commandEncoder = commandBuffer.makeComputeCommandEncoder() else {
                print("Failed to create Metal command queue")
                CVMetalTextureCacheFlush(textureCache!, 0)
                return nil
        }
        
        offset = Int32(nblines)
        
        commandEncoder.label = "ATC"
        commandEncoder.setComputePipelineState(computePipelineStateATC!)
        commandEncoder.setBuffer(Pseudo, offset: 0, index: 0)
        commandEncoder.setBuffer(JBuffer, offset: 0, index: 1)
        commandEncoder.setBuffer(X0, offset: 0, index: 2)
        commandEncoder.setBytes(UnsafeMutableRawPointer(&offset), length: MemoryLayout<Int32>.size, index: 3)
        
        
        let w = computePipelineStateATC!.threadExecutionWidth
        var hReduce = (Int(27*offset) + w-1)/w
        //print("hReduce", hReduce)
        if (w*hReduce > computePipelineStateATC!.maxTotalThreadsPerThreadgroup) {
            //print("thread group size too big: ", hReduce*w)
            hReduce = computePipelineStateATC!.maxTotalThreadsPerThreadgroup / w
        }
        threadsPerThreadgroupReduce = MTLSizeMake(w, hReduce, 1)
        
        threadgroupsPerGridReduce = MTLSize(width: 27,
                                            height: 1,
                                            depth: 1)
        //print(threadsPerThreadgroupReduce)
        //print(threadgroupsPerGridReduce)
        commandEncoder.dispatchThreadgroups(threadgroupsPerGridReduce!, threadsPerThreadgroup: threadsPerThreadgroupReduce!)
        
        commandEncoder.endEncoding()
        
        commandBuffer.commit()
        commandBuffer.waitUntilCompleted()
        
        return X0
    }
    
    func setParameters(intrinsic: Array<Double>, ref: NSSize) {
        
        var intrinsicFloat: [Float] = []
        for _ in 0...3 {
            for _ in 0...3 {
                intrinsicFloat.append(Float(0.0))
            }
        }
        intrinsicFloat[0] = Float(DEPTH_WIDTH*intrinsic[0]/Double(ref.width))
        intrinsicFloat[5] = Float(DEPTH_HEIGHT*intrinsic[4]/Double(ref.height))
        intrinsicFloat[8] = Float(DEPTH_WIDTH*intrinsic[2]/Double(ref.width))
        intrinsicFloat[9] = Float(DEPTH_HEIGHT*intrinsic[5]/Double(ref.height))
        intrinsicFloat[10] = Float(1.0)
        intrinsicFloat[15] = Float(1.0)
        
        memcpy(calibBuffer.contents() + MemoryLayout<Float>.size * 16, UnsafeMutableRawPointer(&intrinsicFloat), MemoryLayout<Float>.size * 16)
    }
    
    func makeTextureFromCVPixelBuffer(pixelBuffer: CVPixelBuffer, textureFormat: MTLPixelFormat) -> MTLTexture? {
        let width = CVPixelBufferGetWidth(pixelBuffer)
        let height = CVPixelBufferGetHeight(pixelBuffer)
        
        var cvTextureOut: CVMetalTexture?
        CVMetalTextureCacheCreateTextureFromImage(kCFAllocatorDefault, textureCache, pixelBuffer, nil, textureFormat, width, height, 0, &cvTextureOut)
        
        guard let cvTexture = cvTextureOut, let texture = CVMetalTextureGetTexture(cvTexture) else {
            print("Depth converter failed to create preview texture")
            
            CVMetalTextureCacheFlush(textureCache, 0)
            
            return nil
        }
        
        return texture
    }
    
    func getJacobian() -> MTLBuffer {
        return JBuffer
    }
}
