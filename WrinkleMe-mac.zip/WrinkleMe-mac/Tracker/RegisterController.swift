//
//  TrackerController.swift
//  WrinkleMe-mac
//
//  Created by Diego Thomas on 2018/03/09.
//  Copyright © 2018 3DLab. All rights reserved.
//

import Foundation
import MetalPerformanceShaders
import CoreMedia
import CoreVideo
import Metal


class RegisterController {
    
    private var level: Int = 1
    private var maxIter: [Int] = [1,2,2]
    
    private let GICPTracker = GICPController()
    
    private let ExpressionTracker = ExpressionController()
    
    private var pose: float4x4 = float4x4.init(diagonal: float4(1.0))
    
    private let metalDevice = MTLCreateSystemDefaultDevice()!
    
    private lazy var commandQueue: MTLCommandQueue? = {
        return self.metalDevice.makeCommandQueue()
    }()
    
    init() {
    }
    
    init(level: Int, maxIter: [Int]) {
        self.level = level
        for i in 0...maxIter.count {
            self.maxIter[i] = maxIter[i]
        }
    }
    
    func GICP(_ sourceVMap: CVPixelBuffer,_  sourceNMap: CVPixelBuffer,_  targetVMap: CVPixelBuffer, _ intrinsic: Array<Double>, _ ref: NSSize, _ sourcelandmarks: [float4], _ targetlandmarks: [CGPoint]?, _ rect: CGRect, _ intrinsicRGB: Array<Double>, _ depthToRGB: Array<Double>) {
        
        if !GICPTracker.isPrepared {
            var depthFormatDescription: CMFormatDescription?
            CMVideoFormatDescriptionCreateForImageBuffer(kCFAllocatorDefault, sourceVMap, &depthFormatDescription)
            GICPTracker.setParameters(intrinsic: intrinsic, ref: ref)
            
            let width = CVPixelBufferGetBytesPerRow(sourceVMap)/16
            let height = (CVPixelBufferGetDataSize(sourceVMap)/16)/width
            GICPTracker.prepare(with: depthFormatDescription!, width: width, height: height)
        }
        
        var poseToRGB: float4x4 = float4x4.init([float4(Float(depthToRGB[0]), Float(depthToRGB[4]), Float(depthToRGB[8]), Float(depthToRGB[12])),
                                                 float4(Float(depthToRGB[1]), Float(depthToRGB[5]), Float(depthToRGB[9]), Float(depthToRGB[13])),
                                                 float4(Float(depthToRGB[2]), Float(depthToRGB[6]), Float(depthToRGB[10]), Float(depthToRGB[14])),
                                                 float4(Float(depthToRGB[3]), Float(depthToRGB[7]), Float(depthToRGB[11]), Float(depthToRGB[15]))])
        
        let RotToRGB = float3x3.init([float3(Float(depthToRGB[0]), Float(depthToRGB[4]), Float(depthToRGB[8])),
                                      float3(Float(depthToRGB[1]), Float(depthToRGB[5]), Float(depthToRGB[9])),
                                      float3(Float(depthToRGB[2]), Float(depthToRGB[6]), Float(depthToRGB[10]))])
        
        var AMat: [Double] = Array<Double>.init(repeating: 0.0, count: 6*6)
        var bMat: [Double] = Array<Double>.init(repeating: 0.0, count: 6)
        var xres: [Float] = Array<Float>.init(repeating: 0.0, count: 6)
        var rowX = Array<Float>.init(repeating: 0.0, count: 7)
        var rowY = Array<Float>.init(repeating: 0.0, count: 7)
        
        for lvl in (0...level).reversed() {
            for iter in 0...maxIter[lvl] {
                let fact = 1 //pow(Float(2.0),Float(lvl))
                
                /*for k in 0...5 {
                    for l in k...5 {
                        AMat[k*6+l] = 0.0
                        AMat[l*6+k] = 0.0
                    }
                    bMat[k] = 0.0
                }*/
                
                // ========================
                // Compute Jacobian from model to depth
                // ========================
                let Jacobian = GICPTracker.Run(sourceVMap: sourceVMap, sourceNMap: sourceNMap, targetVMap: targetVMap, Pose: pose, lvl: Int(fact))
                if Jacobian == nil {
                    break
                }
                let J_pointer = Jacobian!.contents().assumingMemoryBound(to: Float.self)
                
                var shift = 0
                for i in 0...5 {
                    for j in i...6 {
                        let value = J_pointer[shift]
                        shift += 1
                        if j == 6{
                            bMat[i] = Double(value)
                        } else {
                            AMat[i*6+j] = Double(value)
                            AMat[j*6+i] = Double(value)
                        }
                    }
                }
                
                let weight_landmark = Float(1.0)
                
                // ========================
                // Compute Jacobian from landmarks to RGB
                // ========================
                var rmse: Float = 0.0
                if false { //iter == 0 {
                    for i in 0...50 {
                        if targetlandmarks![i].x <= 0.0 && targetlandmarks![i].y <= 0.0 {
                            continue
                        }
                        // Image coordinates of detected landmarks
                        let landmark_p = CGPoint(x: CGFloat(rect.origin.x + targetlandmarks![i].x * rect.width), y: CGFloat(rect.origin.y + targetlandmarks![i].y * rect.height))
                        
                        // 3D coordinates of model landmarks
                        let source_landmark_ref = float4(sourcelandmarks[i].x, sourcelandmarks[i].y, sourcelandmarks[i].z, 1.0)
                        
                        // Transform with current pose estimate to align with depth image
                        var source_landmark_D = pose*source_landmark_ref
                        
                        // Build Jacobian matrix
                        // 1 column = x,y,z coordinates of the derivative for the corresponding transfo parameter
                        let JRot = float3x3.init(float3(0.0, -source_landmark_D.z, source_landmark_D.y),
                                                 float3(source_landmark_D.z, 0.0, -source_landmark_D.x),
                                                 float3(-source_landmark_D.y, source_landmark_D.x, 0.0))
                        
                        // Rotated derivatives
                        let JRotRGB = RotToRGB*JRot
                        
                        // Transform into RGB image coordinate system
                        var source_landmark = poseToRGB*(pose*source_landmark_ref)
                        
                        let z_sqr = source_landmark.z*source_landmark.z
                        
                        rowX[0] = weight_landmark*Float(intrinsicRGB[0])*(poseToRGB.columns.0.x*source_landmark.z - poseToRGB.columns.0.z*source_landmark.x)/z_sqr
                        rowX[1] = weight_landmark*Float(intrinsicRGB[0])*(poseToRGB.columns.1.x*source_landmark.z - poseToRGB.columns.1.z*source_landmark.x)/z_sqr
                        rowX[2] = weight_landmark*Float(intrinsicRGB[0])*(poseToRGB.columns.2.x*source_landmark.z - poseToRGB.columns.2.z*source_landmark.x)/z_sqr
                        rowX[3] = weight_landmark*Float(intrinsicRGB[0])*(JRotRGB.columns.0.x*source_landmark.z - JRotRGB.columns.0.z*source_landmark.x)/z_sqr
                        rowX[4] = weight_landmark*Float(intrinsicRGB[0])*(JRotRGB.columns.1.x*source_landmark.z - JRotRGB.columns.1.z*source_landmark.x)/z_sqr
                        rowX[5] = weight_landmark*Float(intrinsicRGB[0])*(JRotRGB.columns.2.x*source_landmark.z - JRotRGB.columns.2.z*source_landmark.x)/z_sqr
                        rowX[6] = -weight_landmark*(Float(landmark_p.x) - ((source_landmark.x/(-source_landmark.z))*Float(intrinsicRGB[0]) + Float(intrinsicRGB[2])))
                        
                        rowY[0] = weight_landmark*Float(intrinsicRGB[4])*(poseToRGB.columns.0.y*source_landmark.z - poseToRGB.columns.0.z*source_landmark.y)/z_sqr
                        rowY[1] = weight_landmark*Float(intrinsicRGB[4])*(poseToRGB.columns.1.y*source_landmark.z - poseToRGB.columns.1.z*source_landmark.y)/z_sqr
                        rowY[2] = weight_landmark*Float(intrinsicRGB[4])*(poseToRGB.columns.2.y*source_landmark.z - poseToRGB.columns.2.z*source_landmark.y)/z_sqr
                        rowY[3] = weight_landmark*Float(intrinsicRGB[4])*(JRotRGB.columns.0.y*source_landmark.z - JRotRGB.columns.0.z*source_landmark.y)/z_sqr
                        rowY[4] = weight_landmark*Float(intrinsicRGB[4])*(JRotRGB.columns.1.x*source_landmark.z - JRotRGB.columns.1.z*source_landmark.y)/z_sqr
                        rowY[5] = weight_landmark*Float(intrinsicRGB[4])*(JRotRGB.columns.2.x*source_landmark.z - JRotRGB.columns.2.z*source_landmark.y)/z_sqr
                        rowY[6] = -weight_landmark*(Float(landmark_p.y) - ((source_landmark.y/(-source_landmark.z))*Float(intrinsicRGB[4]) + Float(intrinsicRGB[5])))
                        
                        //print(landmark_p.x, ", ", ((source_landmark.x/abs(source_landmark.z))*Float(intrinsicRGB[0]) + Float(intrinsicRGB[2])))
                        //print(CGFloat(height)-landmark_p.y, ", ", Float(height)-((source_landmark.y/abs(source_landmark.z))*Float(intrinsicRGB[4]) + Float(intrinsicRGB[5])))
                        
                        rmse += sqrt(rowX[6]*rowX[6]) + sqrt(rowY[6]*rowY[6])
                        
                        for k in 0...5 {
                            for l in k...6 {
                                var value = (rowX[k]*rowX[l])
                                value = value + (rowY[k]*rowY[l])
                                if l == 6 {
                                    bMat[k] = bMat[k] + Double(value)
                                } else {
                                    AMat[k*6+l] = AMat[k*6+l] + Double(value)
                                    AMat[l*6+k] = AMat[l*6+k] + Double(value)
                                }
                            }
                        }
                    }
                }
                
                //print("rmse: ", rmse)
                
                let A_inv = invert(matrix: AMat)
                
                for i in 0...5 {
                    var value = 0.0
                    for j in 0...5 {
                        value += A_inv[i*6 + j]*bMat[j]
                    }
                    xres[i] = Float(value)
                }
                
                let delta_transfo = Exponential(qsi: xres)
                
                pose = delta_transfo*pose
            }
        }
        
        //print(pose)
    }
    
    func getPose() -> float4x4 {
        return pose
    }
    
    func TrackExpression(_ blendshapes: Blendshapes,_  targetVMap: CVPixelBuffer,_  targetNMap: CVPixelBuffer, _ mappingBuffer: CVPixelBuffer, _ intrinsic: Array<Double>, _ ref: NSSize, _ targetlandmarks: [CGPoint]?, _ rect: CGRect, _ intrinsicRGB: Array<Double>, _ depthToRGB: Array<Double>, _ VMPFlag: Bool = true) {
    
        let face_orientation = pose*float4(0.0,0.0,1.0,0.0)
        if (face_orientation.z < 0.8 || abs(face_orientation.y) > 0.6) {
            for i in 0...27 {
                blendshapes.setCoeff(i, 0.0)
            }
            return
        }
        
        if !ExpressionTracker.isPrepared {
            var depthFormatDescription: CMFormatDescription?
            CMVideoFormatDescriptionCreateForImageBuffer(kCFAllocatorDefault, blendshapes.getBumpImage()!, &depthFormatDescription)
            ExpressionTracker.setParameters(intrinsic: intrinsic, ref: ref)
        
            let width = CVPixelBufferGetBytesPerRow(blendshapes.getBumpImage()!)/16
            let height = (CVPixelBufferGetDataSize(blendshapes.getBumpImage()!)/16)/width
            ExpressionTracker.prepare(with: depthFormatDescription!, width: width, height: height)
        }
    
        let poseToRGB: float4x4 = float4x4.init([float4(Float(depthToRGB[0]), Float(depthToRGB[4]), Float(depthToRGB[8]), Float(depthToRGB[12])),
                                                float4(Float(depthToRGB[1]), Float(depthToRGB[5]), Float(depthToRGB[9]), Float(depthToRGB[13])),
                                                float4(Float(depthToRGB[2]), Float(depthToRGB[6]), Float(depthToRGB[10]), Float(depthToRGB[14])),
                                                float4(Float(depthToRGB[3]), Float(depthToRGB[7]), Float(depthToRGB[11]), Float(depthToRGB[15]))])
        
        var coeff = blendshapes.getCoeff()
        var coeff_ref: [Float] = Array<Float>.init(repeating: Float(0.0), count: 28)
        for i in 0...27 {
            coeff_ref[i] = coeff[i]
        }
        
        var AMat: [Double] = Array<Double>.init(repeating: 0.0, count: 27*27)
        var bMat: [Double] = Array<Double>.init(repeating: 0.0, count: 27)
        var x0: [Double] = Array<Double>.init(repeating: 0.0, count: 27)
        var lb: [Double] = Array<Double>.init(repeating: 0.0, count: 27)
        var ub: [Double] = Array<Double>.init(repeating: 0.0, count: 27)
        var Identity = Array<Double>.init(repeating: 0.0, count: 27*27)
        for i in 0...26 {
            Identity[i*27 + i] = 1.0
        }
        
        for lvl in (0...level).reversed() {
            for iter in 0...maxIter[lvl] {
                let fact = pow(Float(2.0),Float(lvl))
            
                for k in 0...26 {
                    for l in k...26 {
                        AMat[k*27+l] = 0.0
                        AMat[l*27+k] = 0.0
                    }
                    bMat[k] = 0.0
                }
                
                //=====================================
                // Compute matrix B = [A b] constraint system
                //=====================================
                // Return the upper triangle of BTB
                var nbmatches = Int(ExpressionTracker.Run(input: blendshapes.getAttributes(), targetVMap: targetVMap, targetNMap: targetNMap, Pose: pose, coeff: &coeff, lvl: Int(fact), VMPFlag: VMPFlag))
                
                let Jacobian = ExpressionTracker.getJacobian()
                let J_pointer = Jacobian.contents().assumingMemoryBound(to: Float.self)
                //print("Jacobian computed")
                
                
                let weight_landmark = Float(1.0)
                
                if iter < 10 {
                    /*CVPixelBufferLockBaseAddress(targetVMap, CVPixelBufferLockFlags(rawValue: 0))
                    let bufferVMap = unsafeBitCast(CVPixelBufferGetBaseAddress(targetVMap), to: UnsafeMutablePointer<Float32>.self)
                    
                    CVPixelBufferLockBaseAddress(targetNMap, CVPixelBufferLockFlags(rawValue: 0))
                    let bufferNMap = unsafeBitCast(CVPixelBufferGetBaseAddress(targetNMap), to: UnsafeMutablePointer<Float32>.self)
                    
                    CVPixelBufferLockBaseAddress(mappingBuffer, CVPixelBufferLockFlags(rawValue: 0));
                    let mappingBufferFloat = unsafeBitCast(CVPixelBufferGetBaseAddress(mappingBuffer), to: UnsafeMutablePointer<uint16>.self)
                    
                    let width = CVPixelBufferGetWidth(targetVMap)
                    let height = CVPixelBufferGetHeight(targetVMap)*/
 
                    // ========================
                    // Compute Jacobian from landmarks to RGB
                    // ========================
                    var countL = 0
                    for i in 0...50 {
                        if targetlandmarks![i].x <= 0.0 && targetlandmarks![i].y <= 0.0 {
                            continue
                        }
                        // Image coordinates of detected landmarks
                        let landmark_p = CGPoint(x: CGFloat(rect.origin.x + targetlandmarks![i].x * rect.width), y: CGFloat(rect.origin.y + targetlandmarks![i].y * rect.height))
                        /*var pixelInfo = (Int(landmark_p.x) + width * (height-Int(landmark_p.y)))*4
                        var idx = int2(Int32(mappingBufferFloat[pixelInfo]), Int32(mappingBufferFloat[pixelInfo+1]))
                        
                        //print("idx: ", idx)
                        if idx.x == 0 && idx.y == 0 {
                            continue
                        }
                        
                        pixelInfo = (Int(idx.x) + width * Int(idx.y))*4
                        let landmark3D = float3(bufferVMap[pixelInfo], bufferVMap[pixelInfo+1], bufferVMap[pixelInfo+2])
                        let landmarkNmle = float3(bufferNMap[pixelInfo], bufferNMap[pixelInfo+1], bufferNMap[pixelInfo+2])
                        
                        //print("Normal: ", landmarkNmle)
                        if landmarkNmle.z < 0.4 {
                            continue
                        }*/
                        
                        
                        // 3D coordinates of model landmarks
                        let source_landmark_ref = blendshapes.getLandmark(0,i)
                        var source_landmark = float4(source_landmark_ref.x, source_landmark_ref.y, source_landmark_ref.z, source_landmark_ref.w)
                        
                        // Normal vector
                        var source_landmark_nmle = blendshapes.getNmleLandmark(0,i)
                        source_landmark_nmle = pose*source_landmark_nmle
                        //print("normale: ", source_landmark_nmle)
                        //print("source_landmark_ref: ", source_landmark_ref)
                        if source_landmark_ref.z == 0.0 || source_landmark_nmle.z > -0.3 {
                            continue
                        }
                        
                        // blend the shapes with current coeff
                        for k in 1...27 {
                            let vector = blendshapes.getBlendVector(k-1,i)
                            source_landmark = source_landmark + coeff[k]*vector
                        }
                        
                        
                        /////////
                        // 3D distance
                        ////////
                        /*source_landmark = pose*source_landmark
                        
                        print("error: ", dot(source_landmark - float4(landmark3D.x, landmark3D.y, landmark3D.z, 1.0), source_landmark - float4(landmark3D.x, landmark3D.y, landmark3D.z, 1.0)))*/
                        
                        // Transform with current pose estimate to align with RGB image
                        source_landmark = poseToRGB*pose*source_landmark
                        let z_sqr = source_landmark.z*source_landmark.z
                        //let v_i = Float(landmark_p.x) - ((source_landmark.x/(-source_landmark.z))*Float(intrinsicRGB[0]) + Float(intrinsicRGB[2]))
                        //let v_j = Float(landmark_p.y) - ((source_landmark.y/(-source_landmark.z))*Float(intrinsicRGB[4]) + Float(intrinsicRGB[5]))
                        //let dist_2D = sqrt(v_i*v_i + v_j*v_j)
                        
                        /*if dist_2D > 8 {
                            continue
                        }*/
                        
                        // Build Jacobian matrix
                        // 1 column = x,y,z coordinates of the derivative for the corresponding transfo parameter
                        for k in 1...27 {
                            let vector_in = blendshapes.getBlendVector(k-1,i) // w component = 0
                            var vector = poseToRGB*pose*vector_in
                            J_pointer[28*nbmatches + k-1] = weight_landmark*(Float(intrinsicRGB[0])*(vector.x*source_landmark.z - vector.z*source_landmark.x)/z_sqr)
                            J_pointer[28*nbmatches + 28 + k-1] = weight_landmark*(Float(intrinsicRGB[4])*(vector.y*source_landmark.z - vector.z*source_landmark.y)/z_sqr)
                            
                            /////////
                            // 3D distance
                            ////////
                            /*var vector = pose*vector_in
                            J_pointer[28*nbmatches + k-1] = weight_landmark*vector.x
                            J_pointer[28*nbmatches + 28 + k-1] = weight_landmark*vector.y
                            J_pointer[28*nbmatches + 2*28 + k-1] = weight_landmark*vector.z*/
                        }
                        
                        J_pointer[28*nbmatches + 27] = -weight_landmark*(Float(landmark_p.x) - ((source_landmark.x/(-source_landmark.z))*Float(intrinsicRGB[0]) + Float(intrinsicRGB[2])))
                        
                        J_pointer[28*nbmatches + 28 + 27] = -weight_landmark*(Float(landmark_p.y) - ((source_landmark.y/(-source_landmark.z))*Float(intrinsicRGB[4]) + Float(intrinsicRGB[5])))
                        
                        /////////
                        // 3D distance
                        ////////
                        /*J_pointer[28*nbmatches + 27] = weight_landmark*(landmark3D.x-source_landmark.x)
                        J_pointer[28*nbmatches + 28 + 27] = weight_landmark*(landmark3D.y-source_landmark.y)
                        J_pointer[28*nbmatches + 2*28 + 27] = weight_landmark*(landmark3D.z-source_landmark.z)*/
                        
                        
                        nbmatches = nbmatches+2
                        countL = countL+1
                    }
                    //print(countL, " landmarks used")
                    
                    //=================================
                    // Add smoothness constraints
                    //=================================
                    let w_1 = Float(0.001)
                    let w_2 = Float(20.001)
                    for i in 0...26 {
                        for j in 0...26 {
                            J_pointer[28*nbmatches + 2*i*28 + j] = 0.0
                            J_pointer[28*nbmatches + (2*i+1)*28 + j] = 0.0
                        }
                        J_pointer[28*nbmatches + 2*i*28 + i] = w_1
                        J_pointer[28*nbmatches + (2*i+1)*28 + i] = w_2
                        J_pointer[28*nbmatches + 2*i*28 + 27] = 0.0
                        J_pointer[28*nbmatches + 2*(i+1)*28 + 27] = w_2*(coeff_ref[i + 1]-coeff[i+1])
                    }
                    nbmatches = nbmatches+2*27
                }
                
                /*CVPixelBufferUnlockBaseAddress(mappingBuffer, CVPixelBufferLockFlags(rawValue: 0))
                CVPixelBufferUnlockBaseAddress(targetVMap, CVPixelBufferLockFlags(rawValue: 0))
                CVPixelBufferUnlockBaseAddress(targetNMap, CVPixelBufferLockFlags(rawValue: 0))*/
                
                
                // Compute JTJ
                let JTJ = ExpressionTracker.JTJalt(nbmatches)
                let JTJ_Pointer = JTJ!.contents().assumingMemoryBound(to: Float.self)
                
                //print("JTJ computed: ", JTJ_Pointer[5*28+5])
                
                for k in 0...26 {
                    for l in k...27 {
                        if l == 27 {
                            bMat[k] = Double(JTJ_Pointer[k*28+l])
                        } else {
                            AMat[k*27+l] = Double(JTJ_Pointer[k*28+l])
                            AMat[l*27+k] = Double(JTJ_Pointer[l*28+k])
                        }
                    }
                }
                //print(AMat)
                let A_inv = invert(matrix: AMat)
                //print(A_inv)
                
                /*var xres: [Float] = Array<Float>.init(repeating: Float(0.0), count: 27)
                for i in 0...26 {
                    var value = 0.0
                    for j in 0...26 {
                        value += A_inv[i*27 + j]*bMat[j]
                    }
                    xres[i] = Float(value)
                }*/
                
                ////////////////////////////
                // Compute pseudo inverse
                ////////////////////////////
                
                ExpressionTracker.PseudoInverse(A_inv, nbmatches)
                
                //print("Pseudo inverse computed")
                
                let x0_GPU = ExpressionTracker.ATC(nbmatches)
                let x0_Pointer = x0_GPU!.contents().assumingMemoryBound(to: Float.self)
                
                for i in 0...26 {
                    x0[i] = Double(x0_Pointer[i])
                    lb[i] = Double(0.0 - coeff[i + 1])
                    ub[i] = Double(1.0 - coeff[i + 1])
                }
                //print("X0 computed: ", x0)
                
                //let xres = ParallelRelaxation(A_inv, x0, Identity, Minus, Ones)
                var xres = ParallelRelaxation(A_inv, x0, lb, ub)
                
                var delta = Float(1.0)
                
                for i in 0...26 {
                    if (coeff[i+1] == 0.0 && xres[i] < 0.0) {
                        xres[i] = 0.0
                    }
                    
                    if (coeff[i+1] == 1.0 && xres[i] > 0.0) {
                        xres[i] = 0.0
                    }
                    
                    if (coeff[i+1] + Float(xres[i]) < 0.0) {
                        delta = min(delta, -coeff[i+1]/Float(xres[i]))
                    }
                    if (coeff[i+1] + Float(xres[i]) > 1.0) {
                        delta = min(delta, (1.0-coeff[i+1])/Float(xres[i]))
                    }
                }
                
                for i in 0...26 {
                    coeff[i+1] = coeff[i+1]+delta*Float(xres[i])
                    if coeff[i+1] < 0.0 {
                        coeff[i+1] = 0.0 //print("humm....: ", coeff[i+1]) //coeff[i+1] = 0.0
                    }
                    if (coeff[i+1] > 1.0) {
                        coeff[i+1] = 1.0 //print("humm....: ", coeff[i+1]) //coeff[i+1] = 1.0
                    }
                }
            }
        }
        //print ("coeff: ", coeff)
        for i in 0...27 {
            blendshapes.setCoeff(i, coeff[i])
        }
    }
}
