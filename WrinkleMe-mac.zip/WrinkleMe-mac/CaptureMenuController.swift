//
//  CaptureMenuController.swift
//  WrinkleMe-mac
//
//  Created by Diego Thomas on 2018/02/19.
//  Copyright © 2018 3DLab. All rights reserved.
//

import Foundation
import Cocoa

protocol CaptureMenuDelegate: class {
    func StartCapture()
    func PauseCapture()
    func SetRenderMode(value: String)
    func ChangeLandmarksStatus()
    func ChangeMixFactor(mixFactorIn: Float)
    func initSystem ()
    func SetNeutral()
    func ChangeCoeff(_ ID: Int, _ coeff: Float)
    func ChangeMethod(_ Flag: FusionMethod)
    func ChangeTemplate(_ TemplateID: Int)
}

class CaptureMenuController: NSViewController, CaptureDelegate {
    
    @IBOutlet var StartButton: NSButton!
    
    @IBOutlet var FPSLabel: NSTextField!
    
    @IBOutlet var renderButton: NSButton!
    
    @IBOutlet var MethodButton: NSButton!
    
    @IBOutlet var LandmarksButton: NSButton!
    
    @IBOutlet var mixFactorSlider: NSSlider!
    
    @IBOutlet var ShapeID: NSPopUpButton!
    
    @IBOutlet var TemplateID: NSPopUpButton!
    
    weak var menuDelegate: CaptureMenuDelegate?

    private let sessionQueue = DispatchQueue(label: "session queue", qos: DispatchQoS.userInitiated, attributes: [DispatchQueue.Attributes.concurrent], autoreleaseFrequency: .workItem)
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func StartAction(_ sender: Any) {
        switch StartButton.title {
        case "Start":
            sessionQueue.async { 
                self.menuDelegate?.StartCapture()
            }
            StartButton.title = "Pause"
            StartButton.sizeToFit()
            break
        case "Pause":
            sessionQueue.async {
                self.menuDelegate?.PauseCapture()
            }
            StartButton.title = "Resume"
            StartButton.sizeToFit()
            break
        case "Resume":
            sessionQueue.async {
                self.menuDelegate?.StartCapture()
            }
            StartButton.title = "Pause"
            StartButton.sizeToFit()
            break
        default:
            break
        }
    }
    
    func UpdateFPSLabel(text: String) {
        DispatchQueue.main.async {
            self.FPSLabel.stringValue = text
            self.FPSLabel.sizeToFit()
        }
    }
    
    @IBAction func ChangeInputRenderMode(_ sender: Any) {
        self.menuDelegate?.SetRenderMode(value: renderButton.title)
        if renderButton.title == "Depth" {
            renderButton.title = "Normals"
            self.renderButton.sizeToFit()
        } else {
            renderButton.title = "Depth"
            self.renderButton.sizeToFit()
        }
    }
    
    @IBAction func ChangeLandmarksStatus(_ sender: Any) {
        self.menuDelegate?.ChangeLandmarksStatus()
    }
    
    @IBAction func changeMixFactor(_ sender: NSSliderCell) {
        let mixFactor = Float(sender.intValue)/Float(sender.maxValue - sender.minValue)
        
        //sessionQueue.async {
            self.menuDelegate?.ChangeMixFactor(mixFactorIn: mixFactor)
        //}
    }
    
    @IBAction func initSystem(_ sender: Any) {
        self.menuDelegate?.initSystem()
    }
    
    @IBAction func resetSystem(_ sender: Any) {
    }
    
    @IBAction func SetNeutral(_ sender: Any) {
        self.menuDelegate?.SetNeutral()
    }
    
    @IBAction func ChangeCoeff(_ sender: NSSliderCell) {
        let newCoeff = Float(sender.intValue)/Float(sender.maxValue - sender.minValue)
        
        self.menuDelegate?.ChangeCoeff(ShapeID.indexOfSelectedItem+1, newCoeff)
    }
    
    @IBAction func SwitchMethod(_ sender: Any) {
        if MethodButton.title == "Switch Mean" {
            MethodButton.title = "Switch Median"
            self.MethodButton.sizeToFit()
            
            self.menuDelegate?.ChangeMethod(FusionMethod.Mean)
        } else {
            if MethodButton.title == "Switch Median" {
                MethodButton.title = "Switch VMP"
                self.MethodButton.sizeToFit()
                
                self.menuDelegate?.ChangeMethod(FusionMethod.Median)
            } else {
                MethodButton.title = "Switch Mean"
                self.MethodButton.sizeToFit()
                
                self.menuDelegate?.ChangeMethod(FusionMethod.VMP)
            }
        }
    }
    
    @IBAction func ChangeTemplate(_ sender: Any) {
        self.menuDelegate?.ChangeTemplate(TemplateID.indexOfSelectedItem)
    }
}
