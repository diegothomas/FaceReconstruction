//
//  PostProcessing.swift
//  WrinkleMe-mac
//
//  Created by Diego Thomas on 2018/04/11.
//  Copyright © 2018 3DLab. All rights reserved.
//

import Foundation
import CoreMedia
import CoreVideo
import Metal

class PostProcessing {
    var description: String = "Post Processing"
    
    var isPrepared = false
    
    private(set) var inputFormatDescription: CMFormatDescription?
    
    private(set) var outputFormatDescription: CMFormatDescription?
    
    private var inputTextureFormat: MTLPixelFormat = .invalid
    
    private var outputPixelBufferPool: CVPixelBufferPool!
    
    private let metalDevice = MTLCreateSystemDefaultDevice()!
    
    private var computePipelineState: MTLComputePipelineState?
    
    private var computePipelineStateIndices: MTLComputePipelineState?
    
    private var computePipelineStateReset: MTLComputePipelineState?
    
    
    private lazy var commandQueue: MTLCommandQueue? = {
        return self.metalDevice.makeCommandQueue()
    }()
    
    private var textureCache: CVMetalTextureCache!
    
    private var param: MTLBuffer
    
    required init() {
        let defaultLibrary = metalDevice.makeDefaultLibrary()!
        let kernelFunction = defaultLibrary.makeFunction(name: "BilateralFilter")
        do {
            computePipelineState = try metalDevice.makeComputePipelineState(function: kernelFunction!)
        } catch {
            fatalError("Unable to create ColorMap pipeline state. (\(error))")
        }
        
        let kernelFunction2 = defaultLibrary.makeFunction(name: "UpdateIndices")
        do {
            computePipelineStateIndices = try metalDevice.makeComputePipelineState(function: kernelFunction2!)
        } catch {
            fatalError("Unable to create UpdateIndices pipeline state. (\(error))")
        }
        
        let kernelFunction3 = defaultLibrary.makeFunction(name: "ResetVariance")
        do {
            computePipelineStateReset = try metalDevice.makeComputePipelineState(function: kernelFunction3!)
        } catch {
            fatalError("Unable to create UpdateIndices pipeline state. (\(error))")
        }
        
        param = metalDevice.makeBuffer(length: 4*MemoryLayout<Float>.size, options: [])!
        
    }
    
    static private func allocateOutputBufferPool(with formatDescription: CMFormatDescription, outputRetainedBufferCountHint: Int) -> CVPixelBufferPool? {
        let inputDimensions = CMVideoFormatDescriptionGetDimensions(formatDescription)
        let outputPixelBufferAttributes: [String: Any] = [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_128RGBAFloat,
            kCVPixelBufferWidthKey as String: Int(inputDimensions.width),
            kCVPixelBufferHeightKey as String: Int(inputDimensions.height),
            kCVPixelBufferIOSurfacePropertiesKey as String: [:]
        ]
        
        let poolAttributes = [kCVPixelBufferPoolMinimumBufferCountKey as String: outputRetainedBufferCountHint]
        var cvPixelBufferPool: CVPixelBufferPool?
        // Create a pixel buffer pool with the same pixel attributes as the input format description
        CVPixelBufferPoolCreate(kCFAllocatorDefault, poolAttributes as NSDictionary?, outputPixelBufferAttributes as NSDictionary?, &cvPixelBufferPool)
        guard let pixelBufferPool = cvPixelBufferPool else {
            assertionFailure("Allocation failure: Could not create pixel buffer pool")
            return nil
        }
        return pixelBufferPool
    }
    
    func prepare(with formatDescription: CMFormatDescription, outputRetainedBufferCountHint: Int) {
        reset()
        
        outputPixelBufferPool = PostProcessing.allocateOutputBufferPool(with: formatDescription,
                                                                      outputRetainedBufferCountHint: outputRetainedBufferCountHint)
        if outputPixelBufferPool == nil {
            return
        }
        
        var pixelBuffer: CVPixelBuffer?
        var pixelBufferFormatDescription: CMFormatDescription?
        _ = CVPixelBufferPoolCreatePixelBuffer(kCFAllocatorDefault, outputPixelBufferPool!, &pixelBuffer)
        if let pixelBuffer = pixelBuffer {
            CMVideoFormatDescriptionCreateForImageBuffer(kCFAllocatorDefault, pixelBuffer, &pixelBufferFormatDescription)
        }
        pixelBuffer = nil
        
        inputFormatDescription = formatDescription
        outputFormatDescription = pixelBufferFormatDescription
        
        let inputMediaSubType = CMFormatDescriptionGetMediaSubType(formatDescription)
        if inputMediaSubType == kCVPixelFormatType_128RGBAFloat {
            inputTextureFormat = .rgba32Float
        } else {
            assertionFailure("Input format not supported")
        }
        
        var metalTextureCache: CVMetalTextureCache?
        if CVMetalTextureCacheCreate(kCFAllocatorDefault, nil, metalDevice, nil, &metalTextureCache) != kCVReturnSuccess {
            assertionFailure("Unable to allocate depth to vmap texture cache")
        } else {
            textureCache = metalTextureCache
        }
        
        
        isPrepared = true
    }
    
    func reset() {
        isPrepared = false
    }
    
    func BilateralFilter(input: Param3D, size: Float, s_r: Float, s_d: Float, s_c: Float, VMPFlag: Bool = true) -> CVPixelBuffer? {
        if !isPrepared {
            assertionFailure("Invalid state: Not prepared")
            return nil
        }
        
        var newPixelBuffer: CVPixelBuffer?
        CVPixelBufferPoolCreatePixelBuffer(kCFAllocatorDefault, outputPixelBufferPool!, &newPixelBuffer)
        guard let outputPixelBuffer = newPixelBuffer else {
            print("Allocation failure: Could not get pixel buffer from pool (\(self.description))")
            return nil
        }
        
        var tmp: [Float] = [size, s_r, s_d, s_c]
        memcpy(param.contents(), UnsafeMutableRawPointer(&tmp), MemoryLayout<Float>.size * 4)
        
        var Flag = VMPFlag
        
        guard let outputTexture = makeTextureFromCVPixelBuffer(pixelBuffer: outputPixelBuffer, textureFormat: inputTextureFormat),
            let inputTexture0 = makeTextureFromCVPixelBuffer(pixelBuffer: input.bumpImage! , textureFormat: .rgba32Float),
            let inputTexture1 = makeTextureFromCVPixelBuffer(pixelBuffer: input.RGBImage! , textureFormat: .rgba32Float)else {
                return nil
        }
        
        // Set up command queue, buffer, and encoder
        guard let commandQueue = commandQueue,
            let commandBuffer = commandQueue.makeCommandBuffer(),
            let commandEncoder = commandBuffer.makeComputeCommandEncoder() else {
                print("Failed to create Metal command queue")
                CVMetalTextureCacheFlush(textureCache!, 0)
                return nil
        }
        
        commandEncoder.label = "Color Mapping"
        commandEncoder.setComputePipelineState(computePipelineState!)
        commandEncoder.setTexture(outputTexture, index: 0)
        commandEncoder.setTexture(inputTexture0, index: 1)
        commandEncoder.setTexture(inputTexture1, index: 2)
        commandEncoder.setBuffer(param, offset: 0 , index: 0)
        commandEncoder.setBytes( UnsafeMutableRawPointer(&Flag), length: MemoryLayout<Bool>.size, index: 1)
        
        // Set up thread groups as described in https://developer.apple.com/reference/metal/mtlcomputecommandencoder
        let w = computePipelineState!.threadExecutionWidth
        let h = computePipelineState!.maxTotalThreadsPerThreadgroup / w
        let threadsPerThreadgroup = MTLSizeMake(w, h, 1)
        let threadgroupsPerGrid = MTLSize(width: (input.width + w - 1) / w,
                                          height: (input.height + h - 1) / h,
                                          depth: 1)
        commandEncoder.dispatchThreadgroups(threadgroupsPerGrid, threadsPerThreadgroup: threadsPerThreadgroup)
        
        commandEncoder.endEncoding()
        
        commandBuffer.commit()
        commandBuffer.waitUntilCompleted()
        
        return outputPixelBuffer
    }
    
    
    func UpdateIndices(input: Param3D, indices: MTLBuffer) {
        if !isPrepared {
            assertionFailure("Invalid state: Not prepared")
            return
        }
        
    
        guard let inputTexture = makeTextureFromCVPixelBuffer(pixelBuffer: input.VMap! , textureFormat: .rgba32Float)
            else {
                return
        }
        
        // Set up command queue, buffer, and encoder
        guard let commandQueue = commandQueue,
            let commandBuffer = commandQueue.makeCommandBuffer(),
            let commandEncoder = commandBuffer.makeComputeCommandEncoder() else {
                print("Failed to create Metal command queue")
                CVMetalTextureCacheFlush(textureCache!, 0)
                return
        }
        
        commandEncoder.label = "Indices update"
        commandEncoder.setComputePipelineState(computePipelineStateIndices!)
        commandEncoder.setTexture(inputTexture, index: 0)
        commandEncoder.setBuffer(indices, offset: 0 , index: 0)
        
        // Set up thread groups as described in https://developer.apple.com/reference/metal/mtlcomputecommandencoder
        let w = computePipelineStateIndices!.threadExecutionWidth
        let h = computePipelineStateIndices!.maxTotalThreadsPerThreadgroup / w
        let threadsPerThreadgroup = MTLSizeMake(w, h, 1)
        let threadgroupsPerGrid = MTLSize(width: (input.width + w - 1) / w,
                                          height: (input.height + h - 1) / h,
                                          depth: 1)
        commandEncoder.dispatchThreadgroups(threadgroupsPerGrid, threadsPerThreadgroup: threadsPerThreadgroup)
        
        commandEncoder.endEncoding()
        
        commandBuffer.commit()
        commandBuffer.waitUntilCompleted()
    }
    
    func ResetVariance(input: Param3D, PriorBuffer: MTLBuffer) {
        if !isPrepared {
            assertionFailure("Invalid state: Not prepared")
            return
        }
        
        
        guard let inputTexture0 = makeTextureFromCVPixelBuffer(pixelBuffer: input.bumpImage! , textureFormat: .rgba32Float)else {
                return
        }
        
        // Set up command queue, buffer, and encoder
        guard let commandQueue = commandQueue,
            let commandBuffer = commandQueue.makeCommandBuffer(),
            let commandEncoder = commandBuffer.makeComputeCommandEncoder() else {
                print("Failed to create Metal command queue")
                CVMetalTextureCacheFlush(textureCache!, 0)
                return
        }
        
        commandEncoder.label = "Reset Mapping"
        commandEncoder.setComputePipelineState(computePipelineStateReset!)
        commandEncoder.setTexture(inputTexture0, index: 0)
        commandEncoder.setBuffer(PriorBuffer, offset: 0, index: 0)
        
        // Set up thread groups as described in https://developer.apple.com/reference/metal/mtlcomputecommandencoder
        let w = computePipelineStateReset!.threadExecutionWidth
        let h = computePipelineStateReset!.maxTotalThreadsPerThreadgroup / w
        let threadsPerThreadgroup = MTLSizeMake(w, h, 1)
        let threadgroupsPerGrid = MTLSize(width: (input.width + w - 1) / w,
                                          height: (input.height + h - 1) / h,
                                          depth: 1)
        commandEncoder.dispatchThreadgroups(threadgroupsPerGrid, threadsPerThreadgroup: threadsPerThreadgroup)
        
        commandEncoder.endEncoding()
        
        commandBuffer.commit()
        commandBuffer.waitUntilCompleted()
    }
    
    
    func makeTextureFromCVPixelBuffer(pixelBuffer: CVPixelBuffer, textureFormat: MTLPixelFormat) -> MTLTexture? {
        let width = CVPixelBufferGetWidth(pixelBuffer)
        let height = CVPixelBufferGetHeight(pixelBuffer)
        
        var cvTextureOut: CVMetalTexture?
        CVMetalTextureCacheCreateTextureFromImage(kCFAllocatorDefault, textureCache, pixelBuffer, nil, textureFormat, width, height, 0, &cvTextureOut)
        
        guard let cvTexture = cvTextureOut, let texture = CVMetalTextureGetTexture(cvTexture) else {
            print("Depth converter failed to create preview texture")
            
            CVMetalTextureCacheFlush(textureCache, 0)
            
            return nil
        }
        
        return texture
    }
}

