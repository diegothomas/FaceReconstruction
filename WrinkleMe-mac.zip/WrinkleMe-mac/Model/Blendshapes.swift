//
//  Blendshapes.swift
//  WrinkleMe-mac
//
//  Created by Diego Thomas on 2018/02/19.
//  Copyright © 2018 3DLab. All rights reserved.
//

import Foundation
import MetalPerformanceShaders
import Vision
import Cocoa
import CoreMedia
import CoreVideo
import Accelerate
import MetalKit

struct Param3D {
    var bumpImage: CVPixelBuffer? = nil
    var RGBImage: CVPixelBuffer? = nil
    var WLImage: CVPixelBuffer? = nil
    var Labels: CVPixelBuffer? = nil
    var VMap: CVPixelBuffer? = nil
    var NMap: CVPixelBuffer? = nil
    var CoeffBuffer: MTLBuffer? = nil
    var VtxBuffer: MTLBuffer? = nil
    var NmleBuffer: MTLBuffer? = nil
    var FaceBuffer: MTLBuffer? = nil
    var width: Int = 0
    var height: Int = 0
}

let WIDTH_BUMP = 240
let HEIGHT_BUMP = 240

//let DEPTH_WIDTH = 512.0
//let DEPTH_HEIGHT = 424.0
let DEPTH_WIDTH = 640.0
let DEPTH_HEIGHT = 480.0

class Blendshapes {
    
    private var List: [Template] = []
    
    private var Landmarks: [float4] = Array<float4>.init(repeating: float4(0.0), count: 51)
    
    private var FACIAL_LANDMARKS = [3749, 3745, 3731, 3725, 3704, 1572, 1592, 1598, 1612, 1617, 3662,
                                    2207, 3093, 966, 2650, 2774, 2693, 662, 558, 2345, 2336, 2369,
                                    4266, 2237, 2298, 2096, 1981, 1980, 1978, 237, 181, 2838, 4307,
                                    4304, 4301, 4298, 4295, 732, 996, 998, 4277, 3148, 3133, 2865,
                                    2728, 2188,  629, 733, 1011, 3114, 3110]
    
    private let indexForScale = [19, 28, 22, 25, 31, 37, 10, 16]
    
    private var Landmarks3D: [float4] = []
    
    private var blendVector: [[float4]] = Array<[float4]>.init(repeating: Array<float4>.init(repeating: float4(0), count: 51), count: 27)
    
    private var FaceBBox: CGRect = CGRect.init(x: 0, y: 0, width: 0, height: 0)
    
    private var IndexBuffer: MTLBuffer?
    
    private var MatAT: SparseMatrix_Float?
    private var SparseParamAT: SparseParam = SparseParam()
    private var MatATA: SparseMatrix_Float?
    private var SparseParamATA: SparseParam = SparseParam()
    
    // Data to maintain 3D geometry
    private var attributes: Param3D = Param3D()
    private var coefficients: [Float] = Array<Float>.init(repeating: 0.0, count: 28)
    
    private let bumpMapper: BumpMapping = BumpMapping()
    
    private let colorMapper: ColorMapping = ColorMapping()
    
    private let PostProcessor: PostProcessing = PostProcessing()
    
    private let filterVMapToNMap = VMapToNMap()
    
    private let metalDevice = MTLCreateSystemDefaultDevice()!
    
    private let BSQueue = DispatchQueue(label: "BS queue", qos: DispatchQoS.userInitiated, attributes: [DispatchQueue.Attributes.concurrent], autoreleaseFrequency: .workItem)
    
    private lazy var commandQueue: MTLCommandQueue? = {
        return self.metalDevice.makeCommandQueue()
    }()
    
    private var VMPManager = VariationalBump()
    
    init(path: String) {
        attributes.width = WIDTH_BUMP
        attributes.height = HEIGHT_BUMP
        
        List.append(Template(filename: path + "/Template/Mesh_0.obj"))
        print("neutral mesh loaded")
        
        BSQueue.async {
            for i in 1...27 {
                self.List.append(Template(filename: path + "/Template/Mesh_\(i).obj"))
                print("mesh \(i) loaded")
            }
        }
        
        //BSQueue.async {
        //    self.initSparseSystem()
        //}
        
        // Allocate memory for buffers
        let attrsFloat4: [String: Any] = [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_128RGBAFloat,
            kCVPixelBufferWidthKey as String: Int(WIDTH_BUMP),
            kCVPixelBufferHeightKey as String: Int(HEIGHT_BUMP),
            kCVPixelBufferIOSurfacePropertiesKey as String: [:]
        ]
        
        var status = CVPixelBufferCreate(kCFAllocatorDefault, WIDTH_BUMP, HEIGHT_BUMP, kCVPixelFormatType_128RGBAFloat, attrsFloat4 as CFDictionary, &attributes.bumpImage)
        if status != kCVReturnSuccess {
            print("Could not allocate bumpImage")
        }
        
        /*let attrsUINT8: [String: Any] = [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
            kCVPixelBufferWidthKey as String: Int(width),
            kCVPixelBufferHeightKey as String: Int(height),
            kCVPixelBufferIOSurfacePropertiesKey as String: [:]
        ]*/
        
        status = CVPixelBufferCreate(kCFAllocatorDefault, WIDTH_BUMP, HEIGHT_BUMP, kCVPixelFormatType_128RGBAFloat, attrsFloat4 as CFDictionary, &attributes.RGBImage)
        if status != kCVReturnSuccess {
            print("Could not allocate RGBImage")
        }
        
        status = CVPixelBufferCreate(kCFAllocatorDefault, WIDTH_BUMP, HEIGHT_BUMP, kCVPixelFormatType_128RGBAFloat, attrsFloat4 as CFDictionary, &attributes.WLImage)
        if status != kCVReturnSuccess {
            print("Could not allocate WLImage")
        }
        
        //====================================
        // Load Images
        //====================================
        
        var path = Bundle.main.path(forResource: "Labels-\(WIDTH_BUMP)", ofType: "png")
        let imageLabel = NSImage(contentsOfFile: path!)
        if imageLabel == nil {
            print ("Can not load: ", "Labels-¥(width).png")
            return
        }
        
        path = Bundle.main.path(forResource: "Labelsb-\(WIDTH_BUMP) copy", ofType: "png")
        let imageNGLabel = NSImage(contentsOfFile: path!)
        if imageNGLabel == nil {
            print ("Can not load: ", "Labelsb-¥(width).png")
            return
        }
        
        path = Bundle.main.path(forResource: "Weights-\(WIDTH_BUMP)", ofType: "png")
        let imageWeight = NSImage(contentsOfFile: path!)
        if imageLabel == nil {
            print ("Can not load: ", "Weight-¥(width).png")
            return
        }
        
        
        let bmpNG = imageNGLabel!.representations[0] as! NSBitmapImageRep
        let dataNG: UnsafeMutablePointer<UInt8> = bmpNG.bitmapData!
        let uint8pointerNG = UnsafeRawPointer(dataNG).bindMemory(to: UInt8.self, capacity: 1)
        print (bmpNG.bitmapFormat)
        print (bmpNG.bitsPerPixel)
        print (bmpNG.bytesPerRow)
        
        var dataZeros: [Float] = Array<Float>.init(repeating: 0.0, count: Int(4*WIDTH_BUMP*HEIGHT_BUMP))
        
        CVPixelBufferLockBaseAddress(attributes.RGBImage!, CVPixelBufferLockFlags(rawValue: 0));
        let rgbBuffer = unsafeBitCast(CVPixelBufferGetBaseAddress(attributes.RGBImage!), to: UnsafeMutablePointer<Float>.self)
        
        rgbBuffer.initialize(from: &dataZeros, count: Int(4*WIDTH_BUMP*HEIGHT_BUMP))
        
        CVPixelBufferUnlockBaseAddress(attributes.RGBImage!, CVPixelBufferLockFlags(rawValue: 0))
        
        
        for i in 0...HEIGHT_BUMP-1 {
            for j in 0...WIDTH_BUMP-1 {
                dataZeros[4*(i*WIDTH_BUMP+j)+1] = -200.0
                //print(uint8pointerNG[4*(i*width+j)], ", ", uint8pointerNG[4*(i*width+j)+1] , ", ", uint8pointerNG[4*(i*width+j)+2], ", ", uint8pointerNG[4*(i*width+j)+3])
                if uint8pointerNG[4*(i*WIDTH_BUMP+j)] > 200 {
                    dataZeros[4*(i*WIDTH_BUMP+j)+2] = -1.0
                } else {
                    dataZeros[4*(i*WIDTH_BUMP+j)+2] = 0.0
                }
            }
        }
        CVPixelBufferLockBaseAddress(attributes.bumpImage!, CVPixelBufferLockFlags(rawValue: 0));
        let bumpBuffer = unsafeBitCast(CVPixelBufferGetBaseAddress(attributes.bumpImage!), to: UnsafeMutablePointer<Float>.self)
        
        bumpBuffer.initialize(from: &dataZeros, count: Int(4*WIDTH_BUMP*HEIGHT_BUMP))
        
        CVPixelBufferUnlockBaseAddress(attributes.bumpImage!, CVPixelBufferLockFlags(rawValue: 0))
        
        var dataWL: [Float] = Array<Float>.init(repeating: 0.0, count: 4*WIDTH_BUMP*HEIGHT_BUMP)
        
        let bmp = imageLabel!.representations[0] as! NSBitmapImageRep
        let data: UnsafeMutablePointer<UInt8> = bmp.bitmapData!
        let uint16pointerL = UnsafeRawPointer(data).bindMemory(to: UInt16.self, capacity: 1)
        print (bmp.bitmapFormat)
        print (bmp.bitsPerPixel)
        print (bmp.bytesPerRow)
        
        let bmp2 = imageWeight!.representations[0] as! NSBitmapImageRep
        let data2: UnsafeMutablePointer<UInt8> = bmp2.bitmapData!
        let uint16pointerW = UnsafeRawPointer(data2).bindMemory(to: UInt16.self, capacity: 1)
        
        NSLog("%d", bmp.pixelsHigh)
        NSLog("%d", bmp.pixelsWide)
        for i in 0..<bmp.pixelsHigh {
            for j in 0..<bmp.pixelsWide {
                dataWL[4*(i*WIDTH_BUMP+j)] = Float(uint16pointerW[3*(i*WIDTH_BUMP+j)+2])/65535.0
                dataWL[4*(i*WIDTH_BUMP+j)+1] = Float(uint16pointerW[3*(i*WIDTH_BUMP+j)+1])/65535.0
                dataWL[4*(i*WIDTH_BUMP+j)+2] = Float(uint16pointerW[3*(i*WIDTH_BUMP+j)])/65535.0
                dataWL[4*(i*WIDTH_BUMP+j)+3] = Float(uint16pointerL[i*WIDTH_BUMP+j])-1.0
            }
        }
        
        CVPixelBufferLockBaseAddress(attributes.WLImage!, CVPixelBufferLockFlags(rawValue: 0));
        let Buffer = unsafeBitCast(CVPixelBufferGetBaseAddress(attributes.WLImage!), to: UnsafeMutablePointer<Float>.self)
        
        Buffer.initialize(from: &dataWL, count: Int(4*WIDTH_BUMP*HEIGHT_BUMP))
        
        CVPixelBufferUnlockBaseAddress(attributes.WLImage!, CVPixelBufferLockFlags(rawValue: 0))
        
        
        var MeshIndices: [Int32] = Array<Int32>.init(repeating: 0, count: 6*(WIDTH_BUMP-1)*(HEIGHT_BUMP-1))
        for i in 0...WIDTH_BUMP-2 {
            for j in 0...HEIGHT_BUMP-2 {
                MeshIndices[6*(j*(WIDTH_BUMP-1)+i)] = Int32(1*(j*WIDTH_BUMP+i))
                MeshIndices[6*(j*(WIDTH_BUMP-1)+i)+1] = Int32(1*(j*WIDTH_BUMP+i+1))
                MeshIndices[6*(j*(WIDTH_BUMP-1)+i)+2] = Int32(1*((j+1)*WIDTH_BUMP+i))
                
                MeshIndices[6*(j*(WIDTH_BUMP-1)+i)+3] = Int32(1*(j*WIDTH_BUMP+i+1))
                MeshIndices[6*(j*(WIDTH_BUMP-1)+i)+4] = Int32(1*((j+1)*WIDTH_BUMP+i+1))
                MeshIndices[6*(j*(WIDTH_BUMP-1)+i)+5] = Int32(1*((j+1)*WIDTH_BUMP+i))
            }
        }
        IndexBuffer = metalDevice.makeBuffer(length: 6*(WIDTH_BUMP-1)*(HEIGHT_BUMP-1)*MemoryLayout<Int32>.size, options: [])!
        IndexBuffer?.contents().copyMemory(from: MeshIndices, byteCount: 6*(WIDTH_BUMP-1)*(HEIGHT_BUMP-1)*MemoryLayout<Int32>.size)
        //memcpy(IndexBuffer!.contents(), UnsafeMutableRawPointer(&MeshIndices), 6*(width-1)*(height-1)*MemoryLayout<Int32>.size)
    }
    
    func reset() {
        attributes.bumpImage = nil
        attributes.RGBImage = nil
        attributes.WLImage = nil
        attributes.VMap = nil
        attributes.NMap = nil
    }
    
    func drawLandmarks(PixelBuffer: CVPixelBuffer, depthToRGB: [Double], pose: float4x4, size: Int) {
        let count = FACIAL_LANDMARKS.count
        CVPixelBufferLockBaseAddress(PixelBuffer, CVPixelBufferLockFlags(rawValue: 0));
        let floatBuffer = unsafeBitCast(CVPixelBufferGetBaseAddress(PixelBuffer), to: UnsafeMutablePointer<UInt8>.self)
        let floatPerRow = CVPixelBufferGetBytesPerRow(PixelBuffer)/4
        let floatPerCol = (CVPixelBufferGetDataSize(PixelBuffer)/4)/floatPerRow
        
        var pixelInfo : Int
        var bounds = [0, 0, 0, 0]
        for k in 0...count-1 {
            var point_in = float4(List[0].RawVertex(FACIAL_LANDMARKS[k]).x, List[0].RawVertex(FACIAL_LANDMARKS[k]).y, List[0].RawVertex(FACIAL_LANDMARKS[k]).z, 1.0)
            
            // blend the shapes with current coeff
            for l in 1...List.count-1 {
                let vector = blendVector[l-1][k]
                point_in = point_in + coefficients[l]*vector
            }
            
            point_in = pose * point_in
            var point = float3(0.0,0.0,0.0)
            point.x = Float(depthToRGB[0])*point_in.x + Float(depthToRGB[1])*point_in.y + Float(depthToRGB[2])*point_in.z + Float(depthToRGB[3])
            point.y = Float(depthToRGB[4])*point_in.x + Float(depthToRGB[5])*point_in.y + Float(depthToRGB[6])*point_in.z + Float(depthToRGB[7])
            point.z = Float(depthToRGB[8])*point_in.x + Float(depthToRGB[9])*point_in.y + Float(depthToRGB[10])*point_in.z + Float(depthToRGB[11])
            
            let p = CGPoint(x: CGFloat((point.x/fabsf(point.z))*456.79998778999999 + 308.5),
                            y: CGFloat((point.y/fabsf(point.z))*458.59997558999999 + 480.0-242.5))
            //let p = CGPoint(x: CGFloat((point.x/fabsf(point.z))*580.857 + 319.5),
            //                y: CGFloat((point.y/fabsf(point.z))*583.317 + 480.0-239.5))
            //let p = CGPoint(x: CGFloat((point.x/fabsf(point.z))*357.324 + 250.123),
            //               y: CGFloat((point.y/fabsf(point.z))*362.123 + 424.0-217.526))

            bounds[0] = min(floatPerCol-1, max(Int(p.y)-size, 0))
            bounds[1] = max(0, min(Int(p.y)+size, floatPerCol-1))
            bounds[2] = min(floatPerRow-1, max(Int(p.x)-size, 0))
            bounds[3] = max(0, min(Int(p.x)+size, floatPerRow-1))
            for i in bounds[0]...bounds[1] {
                for j in bounds[2]...bounds[3] {
                    pixelInfo = ((floatPerRow * (floatPerCol-i)) + j) * 4
                    floatBuffer[pixelInfo] = 0
                    floatBuffer[pixelInfo+1] = 0
                    floatBuffer[pixelInfo+2] = 255
                    
                }
            }
        }
        
        CVPixelBufferUnlockBaseAddress(PixelBuffer, CVPixelBufferLockFlags(rawValue: 0))
        
    }
    
    func size() -> Int {
        return List.count
    }
    
    func idx(position: Int) -> Template {
        return List[position]
    }
    
    func indices() -> MTLBuffer {
        return IndexBuffer!
    }
    
    func getVMap() -> CVPixelBuffer {
        return attributes.VMap!
    }
    
    func getNMap() -> CVPixelBuffer {
        return attributes.NMap!
    }
    
    func getRGBMap() -> CVPixelBuffer {
        return attributes.RGBImage!
    }
    
    func getLandmarks() -> [float4] {
        if Landmarks3D.count == 0 {
            for i in FACIAL_LANDMARKS {
                Landmarks3D.append(float4(List[0].RawVertex(i).x, List[0].RawVertex(i).y, List[0].RawVertex(i).z, Float(1.0)))
            }
        }
        return Landmarks3D
    }
    
    func initWithRGBDDlib(inputRGBD: RGBDController) -> Bool {
        let rectId = CGRect.init(x: 0.0, y: 0.0, width: 1.0, height: 1.0)
        if let landmarksResults = inputRGBD.landmarksDlib {
            
            //===================
            //Initialize buffers
            //===================
            attributes.VtxBuffer = metalDevice.makeBuffer(length: List.count*3*List[0].VertexCount()*MemoryLayout<Float>.size, options: [])!
            attributes.NmleBuffer = metalDevice.makeBuffer(length: List.count*3*List[0].VertexCount()*MemoryLayout<Float>.size, options: [])!
            attributes.FaceBuffer = metalDevice.makeBuffer(length: 3*List[0].FaceCount()*MemoryLayout<ushort>.size, options: [])!
            attributes.CoeffBuffer = metalDevice.makeBuffer(length: List.count*MemoryLayout<Float>.size, options: [])!
            
            var dataVtx: [Float] = Array<Float>.init(repeating: 0.0, count: List.count*3*List[0].VertexCount())
            var dataNmle: [Float] = Array<Float>.init(repeating: 0.0, count: List.count*3*List[0].VertexCount())
            
            for i in 1...List.count-1 {
                for v_idx in 0...List[0].verticesRaw().count-1 {
                    dataVtx[i*3*List[0].VertexCount() + 3*(v_idx)] = List[i].RawVertex(v_idx).x - List[0].RawVertex(v_idx).x
                    dataVtx[i*3*List[0].VertexCount() + 3*(v_idx)+1] = List[i].RawVertex(v_idx).y - List[0].RawVertex(v_idx).y
                    dataVtx[i*3*List[0].VertexCount() + 3*(v_idx)+2] = List[i].RawVertex(v_idx).z - List[0].RawVertex(v_idx).z
                    dataNmle[i*3*List[0].VertexCount() + 3*(v_idx)] = List[i].verticesRaw()[v_idx].nX
                    dataNmle[i*3*List[0].VertexCount() + 3*(v_idx)+1] = List[i].verticesRaw()[v_idx].nY
                    dataNmle[i*3*List[0].VertexCount() + 3*(v_idx)+2] = List[i].verticesRaw()[v_idx].nZ
                }
                
                for k in 0...50 {
                    blendVector[i-1][k] = float4(List[i].RawVertex(FACIAL_LANDMARKS[k]).x - List[0].RawVertex(FACIAL_LANDMARKS[k]).x,
                                                 List[i].RawVertex(FACIAL_LANDMARKS[k]).y - List[0].RawVertex(FACIAL_LANDMARKS[k]).y,
                                                 List[i].RawVertex(FACIAL_LANDMARKS[k]).z - List[0].RawVertex(FACIAL_LANDMARKS[k]).z,
                                                 0.0)
                }
            }
            
            SetLandmarks(vmapBuffer: inputRGBD.vmapBuffer!, mappingBuffer: inputRGBD.RGBToDepthBuffer!, landmarks: landmarksResults, rect: rectId)
            
            for v_idx in 0...List[0].verticesRaw().count-1 {
                dataVtx[3*(v_idx)] = List[0].RawVertex(v_idx).x
                dataVtx[3*(v_idx)+1] = List[0].RawVertex(v_idx).y
                dataVtx[3*(v_idx)+2] = List[0].RawVertex(v_idx).z
                dataNmle[3*(v_idx)] = List[0].verticesRaw()[v_idx].nX
                dataNmle[3*(v_idx)+1] = List[0].verticesRaw()[v_idx].nY
                dataNmle[3*(v_idx)+2] = List[0].verticesRaw()[v_idx].nZ
            }
            
            memcpy(attributes.VtxBuffer!.contents(), UnsafeMutableRawPointer(&dataVtx), MemoryLayout<Float>.size * List.count*3*List[0].VertexCount())
            memcpy(attributes.NmleBuffer!.contents(), UnsafeMutableRawPointer(&dataNmle), MemoryLayout<Float>.size * List.count*3*List[0].VertexCount())
            
            var dataFace: [ushort] = Array<ushort>.init(repeating: 0, count: 3*List[0].FaceCount())
            var idf = 0
            for face in List[0].facesRaw() {
                dataFace[3*idf] = ushort(face.V0)
                dataFace[3*idf+1] = ushort(face.V1)
                dataFace[3*idf+2] = ushort(face.V2)
                idf += 1
            }
            
            memcpy(attributes.FaceBuffer!.contents(), UnsafeMutableRawPointer(&dataFace), MemoryLayout<ushort>.size * 3*List[0].FaceCount())
            
            memcpy(attributes.CoeffBuffer!.contents(), UnsafeMutableRawPointer(&coefficients), List.count*MemoryLayout<Float>.size)
            
            bumpMapper.setParameters(intrinsic: inputRGBD.intrinsicDepth, ref: inputRGBD.sizeDepth)
            
            return true
        } else {
            print("Not enough landmarks")
            return false
        }
    }
    
    func initWithRGBD(inputRGBD: RGBDController) -> Bool {
        if let landmarksResults = inputRGBD.FaceObservation!.landmarks {
            /*let landmarksForScale: [CGPoint] =
                [(landmarksResults.leftEye?.normalizedPoints[0])!, // outer corner of the left eye
                    (landmarksResults.rightEye?.normalizedPoints[4])!, // outer corner of the right eye
                    (landmarksResults.leftEye?.normalizedPoints[4])!, // inner corner of the left eye
                    (landmarksResults.rightEye?.normalizedPoints[0])!, // inner corner of the right eye
                    (landmarksResults.outerLips?.normalizedPoints[5])!, // left of mouth
                    (landmarksResults.outerLips?.normalizedPoints[9])!, // right of mouth
                    (landmarksResults.noseCrest?.normalizedPoints[0])!, // up of nose
                    (landmarksResults.nose?.normalizedPoints[4])!] // bottom of nose*/
            
            //if !scale(vmapBuffer: inputRGBD.vmapBuffer!, mappingBuffer: inputRGBD.RGBToDepthBuffer!, landmarks: landmarksForScale, rect: /inputRGBD.faceBoundingBox) {
            //    return false
            //}
            
            //======================================
            // Organize all landmarks in the table
            //======================================
            let landmarksForAlign: [CGPoint] =
                [ (landmarksResults.leftEyebrow?.normalizedPoints[0])!,
                    CGPoint.init(x: -1.0, y: -1.0),
                    (landmarksResults.leftEyebrow?.normalizedPoints[1])!,
                    (landmarksResults.leftEyebrow?.normalizedPoints[2])!,
                    (landmarksResults.leftEyebrow?.normalizedPoints[3])!, // left eyebrow
                    (landmarksResults.rightEyebrow?.normalizedPoints[0])!,
                    (landmarksResults.rightEyebrow?.normalizedPoints[1])!,
                    CGPoint.init(x: -1.0, y: -1.0),
                    (landmarksResults.rightEyebrow?.normalizedPoints[2])!,
                    (landmarksResults.rightEyebrow?.normalizedPoints[3])!, // right eyebrow
                    (landmarksResults.noseCrest?.normalizedPoints[0])!,
                    (landmarksResults.noseCrest?.normalizedPoints[1])!,
                    CGPoint.init(x: -1.0, y: -1.0),
                    (landmarksResults.noseCrest?.normalizedPoints[2])!, // noseCrest
                    (landmarksResults.nose?.normalizedPoints[2])!,
                    (landmarksResults.nose?.normalizedPoints[3])!,
                    (landmarksResults.nose?.normalizedPoints[4])!,
                    (landmarksResults.nose?.normalizedPoints[5])!,
                    (landmarksResults.nose?.normalizedPoints[6])!, // nose
                    (landmarksResults.leftEye?.normalizedPoints[0])!,
                    (landmarksResults.leftEye?.normalizedPoints[1])!,
                    (landmarksResults.leftEye?.normalizedPoints[3])!,
                    (landmarksResults.leftEye?.normalizedPoints[4])!,
                    (landmarksResults.leftEye?.normalizedPoints[5])!,
                    (landmarksResults.leftEye?.normalizedPoints[7])!, // left eye
                    (landmarksResults.rightEye?.normalizedPoints[0])!, (landmarksResults.rightEye?.normalizedPoints[1])!, (landmarksResults.rightEye?.normalizedPoints[3])!, (landmarksResults.rightEye?.normalizedPoints[4])!, (landmarksResults.rightEye?.normalizedPoints[5])!, (landmarksResults.rightEye?.normalizedPoints[7])!, // right eye
                    (landmarksResults.outerLips?.normalizedPoints[9])!, (landmarksResults.outerLips?.normalizedPoints[0])!, (landmarksResults.outerLips?.normalizedPoints[1])!, (landmarksResults.outerLips?.normalizedPoints[2])!, (landmarksResults.outerLips?.normalizedPoints[3])!, (landmarksResults.outerLips?.normalizedPoints[4])!, (landmarksResults.outerLips?.normalizedPoints[5])!, (landmarksResults.outerLips?.normalizedPoints[6])!, CGPoint.init(x: -1.0, y: -1.0), (landmarksResults.outerLips?.normalizedPoints[7])!, CGPoint.init(x: -1.0, y: -1.0), (landmarksResults.outerLips?.normalizedPoints[8])!,
                     // outerLips
                    CGPoint.init(x: -1.0, y: -1.0),
                    (landmarksResults.innerLips?.normalizedPoints[0])!, (landmarksResults.innerLips?.normalizedPoints[1])!, (landmarksResults.innerLips?.normalizedPoints[2])!, CGPoint.init(x: -1.0, y: -1.0), (landmarksResults.innerLips?.normalizedPoints[3])!, (landmarksResults.innerLips?.normalizedPoints[4])!, (landmarksResults.innerLips?.normalizedPoints[5])! // innerlips
            ] // up of nose
            //if !AlignToFace(vmapBuffer: inputRGBD.vmapBuffer!, mappingBuffer: inputRGBD.RGBToDepthBuffer!, landmarks: landmarksForAlign, rect: inputRGBD.faceBoundingBox) {
           //     return false
            //}
            
            //===================
            //Initialize buffers
            //===================
            attributes.VtxBuffer = metalDevice.makeBuffer(length: List.count*3*List[0].VertexCount()*MemoryLayout<Float>.size, options: [])!
            attributes.NmleBuffer = metalDevice.makeBuffer(length: List.count*3*List[0].VertexCount()*MemoryLayout<Float>.size, options: [])!
            attributes.FaceBuffer = metalDevice.makeBuffer(length: 3*List[0].FaceCount()*MemoryLayout<ushort>.size, options: [])!
            attributes.CoeffBuffer = metalDevice.makeBuffer(length: List.count*MemoryLayout<Float>.size, options: [])!
            
            var dataVtx: [Float] = Array<Float>.init(repeating: 0.0, count: List.count*3*List[0].VertexCount())
            var dataNmle: [Float] = Array<Float>.init(repeating: 0.0, count: List.count*3*List[0].VertexCount())
            
            //SetLandmarks(vmapBuffer: inputRGBD.vmapBuffer!, mappingBuffer: inputRGBD.RGBToDepthBuffer!, landmarks: landmarksForAlign, rect: inputRGBD.faceBoundingBox)
            
            for i in 1...List.count-1 {
                for v_idx in 0...List[0].verticesRaw().count-1 {
                    dataVtx[i*3*List[0].VertexCount() + 3*(v_idx)] = List[i].RawVertex(v_idx).x - List[0].RawVertex(v_idx).x
                    dataVtx[i*3*List[0].VertexCount() + 3*(v_idx)+1] = List[i].RawVertex(v_idx).y - List[0].RawVertex(v_idx).y
                    dataVtx[i*3*List[0].VertexCount() + 3*(v_idx)+2] = List[i].RawVertex(v_idx).z - List[0].RawVertex(v_idx).z
                    dataNmle[i*3*List[0].VertexCount() + 3*(v_idx)] = List[i].verticesRaw()[v_idx].nX
                    dataNmle[i*3*List[0].VertexCount() + 3*(v_idx)+1] = List[i].verticesRaw()[v_idx].nY
                    dataNmle[i*3*List[0].VertexCount() + 3*(v_idx)+2] = List[i].verticesRaw()[v_idx].nZ
                }
                
                for k in 0...50 {
                    blendVector[i-1][k] = float4(List[i].RawVertex(FACIAL_LANDMARKS[k]).x - List[0].RawVertex(FACIAL_LANDMARKS[k]).x,
                                                List[i].RawVertex(FACIAL_LANDMARKS[k]).y - List[0].RawVertex(FACIAL_LANDMARKS[k]).y,
                                                List[i].RawVertex(FACIAL_LANDMARKS[k]).z - List[0].RawVertex(FACIAL_LANDMARKS[k]).z,
                                                0.0)
                }
            }
            
            //if !ElasticRegistration(vmapBuffer: inputRGBD.vmapBuffer!, mappingBuffer: inputRGBD.RGBToDepthBuffer!, landmarks: landmarksForAlign, rect: /inputRGBD.faceBoundingBox) {
            //    return false
            //}
            
            SetLandmarks(vmapBuffer: inputRGBD.vmapBuffer!, mappingBuffer: inputRGBD.RGBToDepthBuffer!, landmarks: landmarksForAlign, rect: inputRGBD.faceBoundingBox)
            
            /*for i in 1...List.count-1 {
                /*for v_idx in 0...List[0].verticesRaw().count-1 {
                    dataVtx[i*3*List[0].VertexCount() + 3*(v_idx)] = List[i].RawVertex(v_idx).x - List[0].RawVertex(v_idx).x
                    dataVtx[i*3*List[0].VertexCount() + 3*(v_idx)+1] = List[i].RawVertex(v_idx).y - List[0].RawVertex(v_idx).y
                    dataVtx[i*3*List[0].VertexCount() + 3*(v_idx)+2] = List[i].RawVertex(v_idx).z - List[0].RawVertex(v_idx).z
                    dataNmle[i*3*List[0].VertexCount() + 3*(v_idx)] = List[i].verticesRaw()[v_idx].nX
                    dataNmle[i*3*List[0].VertexCount() + 3*(v_idx)+1] = List[i].verticesRaw()[v_idx].nY
                    dataNmle[i*3*List[0].VertexCount() + 3*(v_idx)+2] = List[i].verticesRaw()[v_idx].nZ
                }*/
                
                for k in 0...50 {
                    blendVector[i-1][k] = float4(List[i].RawVertex(FACIAL_LANDMARKS[k]).x - List[0].RawVertex(FACIAL_LANDMARKS[k]).x,
                                                 List[i].RawVertex(FACIAL_LANDMARKS[k]).y - List[0].RawVertex(FACIAL_LANDMARKS[k]).y,
                                                 List[i].RawVertex(FACIAL_LANDMARKS[k]).z - List[0].RawVertex(FACIAL_LANDMARKS[k]).z,
                                                 0.0)
                }
            }*/
            
            for v_idx in 0...List[0].verticesRaw().count-1 {
                dataVtx[3*(v_idx)] = List[0].RawVertex(v_idx).x
                dataVtx[3*(v_idx)+1] = List[0].RawVertex(v_idx).y
                dataVtx[3*(v_idx)+2] = List[0].RawVertex(v_idx).z
                dataNmle[3*(v_idx)] = List[0].verticesRaw()[v_idx].nX
                dataNmle[3*(v_idx)+1] = List[0].verticesRaw()[v_idx].nY
                dataNmle[3*(v_idx)+2] = List[0].verticesRaw()[v_idx].nZ
            }
            
            memcpy(attributes.VtxBuffer!.contents(), UnsafeMutableRawPointer(&dataVtx), MemoryLayout<Float>.size * List.count*3*List[0].VertexCount())
            memcpy(attributes.NmleBuffer!.contents(), UnsafeMutableRawPointer(&dataNmle), MemoryLayout<Float>.size * List.count*3*List[0].VertexCount())
            
            var dataFace: [ushort] = Array<ushort>.init(repeating: 0, count: 3*List[0].FaceCount())
            var idf = 0
            for face in List[0].facesRaw() {
                dataFace[3*idf] = ushort(face.V0)
                dataFace[3*idf+1] = ushort(face.V1)
                dataFace[3*idf+2] = ushort(face.V2)
                idf += 1
            }
            
            memcpy(attributes.FaceBuffer!.contents(), UnsafeMutableRawPointer(&dataFace), MemoryLayout<ushort>.size * 3*List[0].FaceCount())
            
            memcpy(attributes.CoeffBuffer!.contents(), UnsafeMutableRawPointer(&coefficients), List.count*MemoryLayout<Float>.size)
            
            bumpMapper.setParameters(intrinsic: inputRGBD.intrinsicDepth, ref: inputRGBD.sizeDepth)
            
            return true
        } else {
            print("Not enough landmarks")
            return false
        }
    }
   
    func scale(vmapBuffer: CVPixelBuffer, mappingBuffer: CVPixelBuffer, landmarks: [CGPoint]?, rect: CGRect) -> Bool {
        // Compute scale factor from detected facial landmarks
        // landmarks should contain the position of the points
        
        var factor: float2 = float2(1.0, 1.0)
        if landmarks?.count != nil {
            CVPixelBufferLockBaseAddress(vmapBuffer, CVPixelBufferLockFlags(rawValue: 0))
            let bufferFloat = unsafeBitCast(CVPixelBufferGetBaseAddress(vmapBuffer), to: UnsafeMutablePointer<Float32>.self)
            
            CVPixelBufferLockBaseAddress(mappingBuffer, CVPixelBufferLockFlags(rawValue: 0));
            let mappingBufferFloat = unsafeBitCast(CVPixelBufferGetBaseAddress(mappingBuffer), to: UnsafeMutablePointer<uint16>.self)
            
            let width = CVPixelBufferGetWidth(vmapBuffer)
            let height = CVPixelBufferGetHeight(vmapBuffer)
            
            //==================================================================
            // Compute average factor in X length from outer corner of eyes '''
            //==================================================================
            var landmark_p = CGPoint(x: CGFloat(rect.origin.x + landmarks![0].x * rect.width), y: CGFloat(rect.origin.y + landmarks![0].y * rect.height))
            var pixelInfo = (Int(landmark_p.x) + width * (height-Int(landmark_p.y)))*4
            var idx = int2(Int32(mappingBufferFloat[pixelInfo]), Int32(mappingBufferFloat[pixelInfo+1]))
            if idx.x == 0 && idx.y == 0 {
                print ("No landmark for the left eye")
                CVPixelBufferUnlockBaseAddress(mappingBuffer, CVPixelBufferLockFlags(rawValue: 0))
                CVPixelBufferUnlockBaseAddress(vmapBuffer, CVPixelBufferLockFlags(rawValue: 0))
                return false
                
            }
            
            pixelInfo = (Int(idx.x) + width * Int(idx.y))*4
            var left_eye = float3(bufferFloat[pixelInfo], bufferFloat[pixelInfo+1], bufferFloat[pixelInfo+2])
            
            landmark_p = CGPoint(x: CGFloat(rect.origin.x + landmarks![1].x * rect.width), y: CGFloat(rect.origin.y + landmarks![1].y * rect.height))
            pixelInfo = (Int(landmark_p.x) + width * (height-Int(landmark_p.y)))*4
            idx = int2(Int32(mappingBufferFloat[pixelInfo]), Int32(mappingBufferFloat[pixelInfo+1]))
            if idx.x == 0 && idx.y == 0 {
                print ("No landmark for the right eye ")
                CVPixelBufferUnlockBaseAddress(mappingBuffer, CVPixelBufferLockFlags(rawValue: 0))
                CVPixelBufferUnlockBaseAddress(vmapBuffer, CVPixelBufferLockFlags(rawValue: 0))
                return false
                
            }
            
            pixelInfo = (Int(idx.x) + width * Int(idx.y))*4
            var right_eye = float3(bufferFloat[pixelInfo], bufferFloat[pixelInfo+1], bufferFloat[pixelInfo+2])
            
            var eye_v = left_eye - right_eye
            var eye_dist = eye_v.norm_two()
            eye_v = List[0].RawVertex(FACIAL_LANDMARKS[19]) - List[0].RawVertex(FACIAL_LANDMARKS[28])
            var eye_dist_mesh = eye_v.norm_two()
            
            if eye_dist_mesh == 0.0 {
                print(List[0].RawVertex(FACIAL_LANDMARKS[19]))
                print(List[0].RawVertex(FACIAL_LANDMARKS[28]))
                eye_dist_mesh = 1.0
            }
            factor.x = eye_dist/eye_dist_mesh
            
            //==================================================================
            // Compute average factor in X length from inner corner of eyes '''
            //==================================================================
            landmark_p = CGPoint(x: CGFloat(rect.origin.x + landmarks![2].x * rect.width), y: CGFloat(rect.origin.y + landmarks![2].y * rect.height))
            pixelInfo = (Int(landmark_p.x) + width * (height-Int(landmark_p.y)))*4
            idx = int2(Int32(mappingBufferFloat[pixelInfo]), Int32(mappingBufferFloat[pixelInfo+1]))
            if idx.x == 0 && idx.y == 0 {
                print ("No landmark for the inner left eye")
                CVPixelBufferUnlockBaseAddress(mappingBuffer, CVPixelBufferLockFlags(rawValue: 0))
                CVPixelBufferUnlockBaseAddress(vmapBuffer, CVPixelBufferLockFlags(rawValue: 0))
                return false
                
            }
            
            pixelInfo = (Int(idx.x) + width * Int(idx.y))*4
            left_eye = float3(bufferFloat[pixelInfo], bufferFloat[pixelInfo+1], bufferFloat[pixelInfo+2])
            
            landmark_p = CGPoint(x: CGFloat(rect.origin.x + landmarks![3].x * rect.width), y: CGFloat(rect.origin.y + landmarks![3].y * rect.height))
            pixelInfo = (Int(landmark_p.x) + width * (height-Int(landmark_p.y)))*4
            idx = int2(Int32(mappingBufferFloat[pixelInfo]), Int32(mappingBufferFloat[pixelInfo+1]))
            if idx.x == 0 && idx.y == 0 {
                print ("No landmark for the inner right eye ")
                CVPixelBufferUnlockBaseAddress(mappingBuffer, CVPixelBufferLockFlags(rawValue: 0))
                CVPixelBufferUnlockBaseAddress(vmapBuffer, CVPixelBufferLockFlags(rawValue: 0))
                return false
                
            }
            
            pixelInfo = (Int(idx.x) + width * Int(idx.y))*4
            right_eye = float3(bufferFloat[pixelInfo], bufferFloat[pixelInfo+1], bufferFloat[pixelInfo+2])
            
            eye_v = left_eye - right_eye
            eye_dist = eye_v.norm_two()
            eye_v = List[0].RawVertex(FACIAL_LANDMARKS[22]) - List[0].RawVertex(FACIAL_LANDMARKS[25])
            eye_dist_mesh = eye_v.norm_two()
            
            if eye_dist_mesh == 0.0 {
                print(List[0].RawVertex(FACIAL_LANDMARKS[22]))
                print(List[0].RawVertex(FACIAL_LANDMARKS[25]))
                eye_dist_mesh = 1.0
            }
            factor.x += eye_dist/eye_dist_mesh
            
            //==================================================================
            // Compute average factor in X length from mouth ''' left right switched????
            //==================================================================
            landmark_p = CGPoint(x: CGFloat(rect.origin.x + landmarks![4].x * rect.width), y: CGFloat(rect.origin.y + landmarks![4].y * rect.height))
            pixelInfo = (Int(landmark_p.x) + width * (height-Int(landmark_p.y)))*4
            idx = int2(Int32(mappingBufferFloat[pixelInfo]), Int32(mappingBufferFloat[pixelInfo+1]))
            if idx.x == 0 && idx.y == 0 {
                print ("No landmark for the left mouth")
                CVPixelBufferUnlockBaseAddress(mappingBuffer, CVPixelBufferLockFlags(rawValue: 0))
                CVPixelBufferUnlockBaseAddress(vmapBuffer, CVPixelBufferLockFlags(rawValue: 0))
                return false
                
            }
            
            pixelInfo = (Int(idx.x) + width * Int(idx.y))*4
            left_eye = float3(bufferFloat[pixelInfo], bufferFloat[pixelInfo+1], bufferFloat[pixelInfo+2])
            
            landmark_p = CGPoint(x: CGFloat(rect.origin.x + landmarks![5].x * rect.width), y: CGFloat(rect.origin.y + landmarks![5].y * rect.height))
            pixelInfo = (Int(landmark_p.x) + width * (height-Int(landmark_p.y)))*4
            idx = int2(Int32(mappingBufferFloat[pixelInfo]), Int32(mappingBufferFloat[pixelInfo+1]))
            if idx.x == 0 && idx.y == 0 {
                print ("No landmark for the right mouth ")
                CVPixelBufferUnlockBaseAddress(mappingBuffer, CVPixelBufferLockFlags(rawValue: 0))
                CVPixelBufferUnlockBaseAddress(vmapBuffer, CVPixelBufferLockFlags(rawValue: 0))
                return false
                
            }
            
            pixelInfo = (Int(idx.x) + width * Int(idx.y))*4
            right_eye = float3(bufferFloat[pixelInfo], bufferFloat[pixelInfo+1], bufferFloat[pixelInfo+2])
            
            eye_v = left_eye - right_eye
            eye_dist = eye_v.norm_two()
            eye_v = List[0].RawVertex(FACIAL_LANDMARKS[31]) - List[0].RawVertex(FACIAL_LANDMARKS[37])
            eye_dist_mesh = eye_v.norm_two()
            
            if eye_dist_mesh == 0.0 {
                print(List[0].RawVertex(FACIAL_LANDMARKS[31]))
                print(List[0].RawVertex(FACIAL_LANDMARKS[37]))
                eye_dist_mesh = 1.0
            }
            factor.x += eye_dist/eye_dist_mesh
            
            factor.x /= 3.0
            
            //==================================================================
            // Compute average factor in Y length from nose
            //==================================================================
            landmark_p = CGPoint(x: CGFloat(rect.origin.x + landmarks![6].x * rect.width), y: CGFloat(rect.origin.y + landmarks![6].y * rect.height))
            pixelInfo = (Int(landmark_p.x) + width * (height-Int(landmark_p.y)))*4
            idx = int2(Int32(mappingBufferFloat[pixelInfo]), Int32(mappingBufferFloat[pixelInfo+1]))
            if idx.x == 0 && idx.y == 0 {
                print ("No landmark for the up nose")
                CVPixelBufferUnlockBaseAddress(mappingBuffer, CVPixelBufferLockFlags(rawValue: 0))
                CVPixelBufferUnlockBaseAddress(vmapBuffer, CVPixelBufferLockFlags(rawValue: 0))
                return false
                
            }
            
            pixelInfo = (Int(idx.x) + width * Int(idx.y))*4
            left_eye = float3(bufferFloat[pixelInfo], bufferFloat[pixelInfo+1], bufferFloat[pixelInfo+2])
            
            landmark_p = CGPoint(x: CGFloat(rect.origin.x + landmarks![7].x * rect.width), y: CGFloat(rect.origin.y + landmarks![7].y * rect.height))
            pixelInfo = (Int(landmark_p.x) + width * (height-Int(landmark_p.y)))*4
            idx = int2(Int32(mappingBufferFloat[pixelInfo]), Int32(mappingBufferFloat[pixelInfo+1]))
            if idx.x == 0 && idx.y == 0 {
                print ("No landmark for the down nose ")
                CVPixelBufferUnlockBaseAddress(mappingBuffer, CVPixelBufferLockFlags(rawValue: 0))
                CVPixelBufferUnlockBaseAddress(vmapBuffer, CVPixelBufferLockFlags(rawValue: 0))
                return false
                
            }
            
            pixelInfo = (Int(idx.x) + width * Int(idx.y))*4
            right_eye = float3(bufferFloat[pixelInfo], bufferFloat[pixelInfo+1], bufferFloat[pixelInfo+2])
            
            eye_v = left_eye - right_eye
            eye_dist = eye_v.norm_two()
            eye_v = List[0].RawVertex(FACIAL_LANDMARKS[10]) - List[0].RawVertex(FACIAL_LANDMARKS[16])
            eye_dist_mesh = eye_v.norm_two()
            
            if eye_dist_mesh == 0.0 {
                print(List[0].RawVertex(FACIAL_LANDMARKS[10]))
                print(List[0].RawVertex(FACIAL_LANDMARKS[16]))
                eye_dist_mesh = 1.0
            }
            factor.y = eye_dist/eye_dist_mesh
            
            CVPixelBufferUnlockBaseAddress(mappingBuffer, CVPixelBufferLockFlags(rawValue: 0))
            CVPixelBufferUnlockBaseAddress(vmapBuffer, CVPixelBufferLockFlags(rawValue: 0))
        }
        
        print("Factor: ", factor)
        
        for mesh in List {
            mesh.scale(factor: factor)
        }
        return true
    }
    
    func AlignToFace (vmapBuffer: CVPixelBuffer, mappingBuffer: CVPixelBuffer, landmarks: [CGPoint]?, rect: CGRect) -> Bool {
        if landmarks?.count != 51 {
            print("Not enough landmarks: ", landmarks!.count)
            return false
        }
        
        CVPixelBufferLockBaseAddress(vmapBuffer, CVPixelBufferLockFlags(rawValue: 0))
        let bufferFloat = unsafeBitCast(CVPixelBufferGetBaseAddress(vmapBuffer), to: UnsafeMutablePointer<Float32>.self)
        
        CVPixelBufferLockBaseAddress(mappingBuffer, CVPixelBufferLockFlags(rawValue: 0));
        let mappingBufferFloat = unsafeBitCast(CVPixelBufferGetBaseAddress(mappingBuffer), to: UnsafeMutablePointer<uint16>.self)
        
        let width = CVPixelBufferGetWidth(vmapBuffer)
        let height = CVPixelBufferGetHeight(vmapBuffer)
        
        //==================================================================
        // Initialise alignment by translation with Nose
        //==================================================================
        let landmarkNose_p = CGPoint(x: CGFloat(rect.origin.x + landmarks![13].x * rect.width), y: CGFloat(rect.origin.y + landmarks![13].y * rect.height))
        var pixelInfoNose = (Int(landmarkNose_p.x) + width * (height-Int(landmarkNose_p.y)))*4
        let idxNose = int2(Int32(mappingBufferFloat[pixelInfoNose]), Int32(mappingBufferFloat[pixelInfoNose+1]))
        if idxNose.x == 0 && idxNose.y == 0 {
            print ("No landmark for the nose")
            CVPixelBufferUnlockBaseAddress(mappingBuffer, CVPixelBufferLockFlags(rawValue: 0))
            CVPixelBufferUnlockBaseAddress(vmapBuffer, CVPixelBufferLockFlags(rawValue: 0))
            return false
            
        }
        
        pixelInfoNose = (Int(idxNose.x) + width * Int(idxNose.y))*4
        let nose = float3(bufferFloat[pixelInfoNose], bufferFloat[pixelInfoNose+1], bufferFloat[pixelInfoNose+2])
        let nose_mesh = List[0].RawVertex(FACIAL_LANDMARKS[13])
        
        let translation = nose-nose_mesh
        
        for mesh in List {
            mesh.Translate(translation)
        }
        
        //==================================
        // DO linear least square
        //==================================
        
        var res = float4x4.init(diagonal: float4(1.0))
        var delta_transfo = float4x4.init(diagonal: float4(1.0))
        var Jac = Array<Float>.init(repeating: 0.0, count: 3*51*6)
        var Jac_B = Array<Float>.init(repeating: 0.0, count: 3*51)
        let descriptorJ = MPSMatrixDescriptor.init(rows: 3*51, columns: 6, rowBytes: 6*MemoryLayout<Float>.size, dataType: MPSDataType.float32)
        let descriptorJb = MPSMatrixDescriptor.init(rows: 3*51, columns: 1, rowBytes: MemoryLayout<Float>.size, dataType: MPSDataType.float32)
        let BuffJ = metalDevice.makeBuffer(length: 3*51*6*MemoryLayout<Float>.size, options: [])!
        let Buffb = metalDevice.makeBuffer(length: 3*51*MemoryLayout<Float>.size, options: [])!
        let MatJ = MPSMatrix(buffer: BuffJ, descriptor: descriptorJ)
        let Matb = MPSMatrix(buffer: Buffb, descriptor: descriptorJb)
        
        let multiplicatorJ = MPSMatrixMultiplication.init(device: metalDevice, transposeLeft: true, transposeRight: false, resultRows: 6, resultColumns: 6, interiorColumns: 3*51, alpha: 1.0, beta: 0.0)
        let multiplicatorb = MPSMatrixMultiplication.init(device: metalDevice, transposeLeft: true, transposeRight: false, resultRows: 6, resultColumns: 1, interiorColumns: 3*51, alpha: 1.0, beta: 0.0)
        let solver = MPSMatrixSolveCholesky.init(device: metalDevice, upper: true, order : 6, numberOfRightHandSides: 1)
        
        let descriptorA = MPSMatrixDescriptor.init(rows: 6, columns: 6, rowBytes: 6*MemoryLayout<Float>.size, dataType: MPSDataType.float32)
        let descriptorb = MPSMatrixDescriptor.init(rows: 6, columns: 1, rowBytes: MemoryLayout<Float>.size, dataType: MPSDataType.float32)
        let A = MPSMatrix(buffer: metalDevice.makeBuffer(length: 6*6*MemoryLayout<Float>.size, options: [])!, descriptor: descriptorA)
        let b = MPSMatrix(buffer: metalDevice.makeBuffer(length: 6*MemoryLayout<Float>.size, options: [])!, descriptor: descriptorb)
        let x = MPSMatrix(buffer: metalDevice.makeBuffer(length: 6*MemoryLayout<Float>.size, options: [])!, descriptor: descriptorb)
        
        let MAX_ITER = 20
        for _ in 0...MAX_ITER {
            
            // Build the Jacobian Matrix
            for k in 0...50 {
                if landmarks![k].x == -1.0 && landmarks![k].y == -1.0 {
                    continue
                }
                let landmark_p = CGPoint(x: CGFloat(rect.origin.x + landmarks![k].x * rect.width), y: CGFloat(rect.origin.y + landmarks![k].y * rect.height))
                var pixelInfo = (Int(landmark_p.x) + width * (height-Int(landmark_p.y)))*4
                var idx = int2(Int32(mappingBufferFloat[pixelInfo]), Int32(mappingBufferFloat[pixelInfo+1]))
                if idx.x == 0 && idx.y == 0 {
                    //print ("No landmark: landmark ", k)
                    continue
                }
                pixelInfo = (Int(idx.x) + width * Int(idx.y))*4
                let landmark = float3(bufferFloat[pixelInfo], bufferFloat[pixelInfo+1], bufferFloat[pixelInfo+2])
                
                let landmark_mesh = res * float4(List[0].RawVertex(FACIAL_LANDMARKS[k]).x, List[0].RawVertex(FACIAL_LANDMARKS[k]).y, List[0].RawVertex(FACIAL_LANDMARKS[k]).z, 1.0)
                
                Jac[6*(3*k)] = 1.0
                Jac[6*(3*k)+1] = 0.0
                Jac[6*(3*k)+2] = 0.0
                Jac[6*(3*k)+3] = 0.0
                Jac[6*(3*k)+4] = 2.0*landmark_mesh.z
                Jac[6*(3*k)+5] = -2.0*landmark_mesh.y
                
                Jac[6*(3*k+1)] = 0.0
                Jac[6*(3*k+1)+1] = 1.0
                Jac[6*(3*k+1)+2] = 0.0
                Jac[6*(3*k+1)+3] = -2.0*landmark_mesh.z
                Jac[6*(3*k+1)+4] = 0.0
                Jac[6*(3*k+1)+5] = 2.0*landmark_mesh.x
                
                Jac[6*(3*k+2)] = 0.0
                Jac[6*(3*k+2)+1] = 0.0
                Jac[6*(3*k+2)+2] = 1.0
                Jac[6*(3*k+2)+3] = 2.0*landmark_mesh.y
                Jac[6*(3*k+2)+4] = -2.0*landmark_mesh.x
                Jac[6*(3*k+2)+5] = 0.0
                
                Jac_B[3*k] = landmark.x - landmark_mesh.x
                Jac_B[3*k+1] = landmark.y - landmark_mesh.y
                Jac_B[3*k+2] = landmark.z - landmark_mesh.z
            }
            BuffJ.contents().copyMemory(from: Jac, byteCount: 3*51*6*MemoryLayout<Float>.size)
            Buffb.contents().copyMemory(from: Jac_B, byteCount: 3*51*MemoryLayout<Float>.size)
            
            guard let commandQueue = commandQueue,
                let commandBuffer = commandQueue.makeCommandBuffer() else {
                    print("Failed to create Metal command queue")
                    CVPixelBufferUnlockBaseAddress(mappingBuffer, CVPixelBufferLockFlags(rawValue: 0))
                    CVPixelBufferUnlockBaseAddress(vmapBuffer, CVPixelBufferLockFlags(rawValue: 0))
                    return false
            }
            
            multiplicatorJ.encode(commandBuffer: commandBuffer, leftMatrix: MatJ, rightMatrix: MatJ, resultMatrix: A)
            multiplicatorb.encode(commandBuffer: commandBuffer, leftMatrix: MatJ, rightMatrix: Matb, resultMatrix: b)
            solver.encode(commandBuffer: commandBuffer, sourceMatrix: A, rightHandSideMatrix: b, solutionMatrix: x)
            commandBuffer.commit()
            commandBuffer.waitUntilCompleted()
            
            let x_pointer = x.data.contents().assumingMemoryBound(to: Float.self)
            let norm = x_pointer[3]*x_pointer[3] + x_pointer[4]*x_pointer[4] + x_pointer[5]*x_pointer[5]
            if norm < 1.0 {
                let quat: [Float] = [sqrt(1.0-norm), x_pointer[3], x_pointer[4], x_pointer[5]]
                //let quat = simd_quaternion(x.data[3], x.data[4, x.data[5]], sqrt(1.0-norm))
                delta_transfo = quaternion2matrix(quat)
                delta_transfo[3].x = x_pointer[0]
                delta_transfo[3].y = x_pointer[1]
                delta_transfo[3].z = x_pointer[2]
            } else {
                delta_transfo = float4x4.init(diagonal: float4(1.0))
            }
            
            res = delta_transfo * res
        }
        
        CVPixelBufferUnlockBaseAddress(mappingBuffer, CVPixelBufferLockFlags(rawValue: 0))
        CVPixelBufferUnlockBaseAddress(vmapBuffer, CVPixelBufferLockFlags(rawValue: 0))
        
        print(res)
        for mesh in List {
            mesh.Transform(res)
        }
        
        return true
    }
    
    func SetLandmarks(vmapBuffer: CVPixelBuffer, mappingBuffer: CVPixelBuffer, landmarks: [CGPoint]?, rect: CGRect) {
        CVPixelBufferLockBaseAddress(vmapBuffer, CVPixelBufferLockFlags(rawValue: 0))
        let bufferFloat = unsafeBitCast(CVPixelBufferGetBaseAddress(vmapBuffer), to: UnsafeMutablePointer<Float32>.self)
        
        CVPixelBufferLockBaseAddress(mappingBuffer, CVPixelBufferLockFlags(rawValue: 0));
        let mappingBufferFloat = unsafeBitCast(CVPixelBufferGetBaseAddress(mappingBuffer), to: UnsafeMutablePointer<uint16>.self)
        
        let width = CVPixelBufferGetWidth(vmapBuffer)
        let height = CVPixelBufferGetHeight(vmapBuffer)
        
        for k in 0...50 {
            if landmarks![k].x == -1.0 && landmarks![k].y == -1.0 {
                continue
            }
            let landmark_p = CGPoint(x: CGFloat(rect.origin.x + landmarks![k].x * rect.width), y: CGFloat(rect.origin.y + landmarks![k].y * rect.height))
            var pixelInfo = (Int(landmark_p.x) + width * (height-Int(landmark_p.y)))*4
            var idx = int2(Int32(mappingBufferFloat[pixelInfo]), Int32(mappingBufferFloat[pixelInfo+1]))
            if idx.x == 0 && idx.y == 0 {
                continue
            }
            
            pixelInfo = (Int(idx.x) + width * Int(idx.y))*4
            let landmark = float3(bufferFloat[pixelInfo], bufferFloat[pixelInfo+1], bufferFloat[pixelInfo+2])
            
            Landmarks[k].x = landmark.x
            Landmarks[k].y = landmark.y
            Landmarks[k].z = landmark.z
            Landmarks[k].w = 1.0
            /*continue
            
            var min_dist = Float(100000.0)
            var indx = 0
            var best_indx = 0
            for vtx in List[0].verticesRaw() {
                let dist = sqrt((vtx.x-landmark.x)*(vtx.x-landmark.x) + (vtx.y-landmark.y)*(vtx.y-landmark.y) + (vtx.z-landmark.z)*(vtx.z-landmark.z))
                if dist < min_dist {
                    min_dist = dist
                    best_indx = indx
                }
                indx = indx+1
            }
            
            FACIAL_LANDMARKS[k] = best_indx*/
            
        }
        
        CVPixelBufferUnlockBaseAddress(mappingBuffer, CVPixelBufferLockFlags(rawValue: 0))
        CVPixelBufferUnlockBaseAddress(vmapBuffer, CVPixelBufferLockFlags(rawValue: 0))
    }
    
    // Assumes valid landmarks
    func ElasticRegistration(vmapBuffer: CVPixelBuffer, mappingBuffer: CVPixelBuffer, landmarks: [CGPoint]?, rect: CGRect) -> Bool {
        List[0].computeTgtPlane()
        
        CVPixelBufferLockBaseAddress(vmapBuffer, CVPixelBufferLockFlags(rawValue: 0))
        let bufferFloat = unsafeBitCast(CVPixelBufferGetBaseAddress(vmapBuffer), to: UnsafeMutablePointer<Float32>.self)
        
        CVPixelBufferLockBaseAddress(mappingBuffer, CVPixelBufferLockFlags(rawValue: 0));
        let mappingBufferFloat = unsafeBitCast(CVPixelBufferGetBaseAddress(mappingBuffer), to: UnsafeMutablePointer<uint16>.self)
        
        let width = CVPixelBufferGetWidth(vmapBuffer)
        let height = CVPixelBufferGetHeight(vmapBuffer)
        
        let nb_col = 3*List[0].VertexCount()
        let nb_lines = 3*36 + 3*6*List[0].FaceCount()
        
        for _ in 0...2 {
            /*========Point correspondences==========
             
             ===========Solve linear system=============
             Build Matrix A
             Nx -Ny -Nz 0 ......... 0]
             [0 0 0 -Nx -Ny -Nz 0 ... 0]
             ...
             [0............ -Nx -Ny -Nz]
             [0..0...1....-1 .......]
             [0..0...0 1...0 -1 ....]
             [0..0...0 0 1.0 0 -1...] */
            
            //==========================================
            // Add landmarks
            //==========================================
            let weight: Float = 10.0
            
            var xValues = Array<Float>.init(repeating: 0.0, count: nb_col)
            var bValues = Array<Float>.init(repeating: 0.0, count: nb_lines)
            var ATbValues = Array<Float>.init(repeating: 0.0, count: nb_col)
            
            for k in 0...35 {
                if landmarks![k].x == -1.0 && landmarks![k].y == -1.0 {
                    bValues[3*k] = weight*List[0].RawVertex(FACIAL_LANDMARKS[k]).x
                    bValues[3*k+1] = weight*List[0].RawVertex(FACIAL_LANDMARKS[k]).y
                    bValues[3*k+2] = weight*List[0].RawVertex(FACIAL_LANDMARKS[k]).z
                    continue
                }
                let landmark_p = CGPoint(x: CGFloat(rect.origin.x + landmarks![k].x * rect.width), y: CGFloat(rect.origin.y + landmarks![k].y * rect.height))
                var pixelInfo = (Int(landmark_p.x) + width * (height-Int(landmark_p.y)))*4
                var idx = int2(Int32(mappingBufferFloat[pixelInfo]), Int32(mappingBufferFloat[pixelInfo+1]))
                if idx.x == 0 && idx.y == 0 {
                    bValues[3*k] = weight*List[0].RawVertex(FACIAL_LANDMARKS[k]).x
                    bValues[3*k+1] = weight*List[0].RawVertex(FACIAL_LANDMARKS[k]).y
                    bValues[3*k+2] = weight*List[0].RawVertex(FACIAL_LANDMARKS[k]).z
                    continue
                }
                pixelInfo = (Int(idx.x) + width * Int(idx.y))*4
                let landmark = float3(bufferFloat[pixelInfo], bufferFloat[pixelInfo+1], bufferFloat[pixelInfo+2])
                
                bValues[3*k] = weight*landmark.x
                bValues[3*k+1] = weight*landmark.y
                bValues[3*k+2] = weight*landmark.z
            }
            
            var indb = 36
            for face in List[0].facesRaw() {
                for k in 0...2 {
                    var v_idx = 0
                    var v_idx_n = 0
                    var v_idx_nn = 0
                    switch k {
                    case 0:
                        v_idx = face.V0
                        v_idx_n = face.V1
                        v_idx_nn = face.V2
                        break
                    case 1:
                        v_idx = face.V1
                        v_idx_n = face.V2
                        v_idx_nn = face.V0
                        break
                    default:
                        v_idx = face.V2
                        v_idx_n = face.V0
                        v_idx_nn = face.V1
                        break
                    }
                    
                    var pt = List[0].RawVertex(v_idx_n) - List[0].RawVertex(v_idx)
                    // Rotate with the quaternion
                    var Rpt = List[0].Rotation(v_idx) * pt
                    bValues[3*indb] = Rpt.x
                    bValues[3*indb+1] = Rpt.y
                    bValues[3*indb+2] = Rpt.z
                    indb += 1
                    
                    pt = List[0].RawVertex(v_idx_nn) - List[0].RawVertex(v_idx)
                    // Rotate with the quaternion
                    Rpt = List[0].Rotation(v_idx) * pt
                    bValues[3*indb] = Rpt.x
                    bValues[3*indb+1] = Rpt.y
                    bValues[3*indb+2] = Rpt.z
                    indb += 1
                }
            }
            
            let b = DenseVector_Float(count: Int32(nb_lines), data: &bValues)
            let x = DenseVector_Float(count: Int32(nb_col), data: &xValues)
            let ATb = DenseVector_Float(count: Int32(nb_col), data: &ATbValues)
            
            SparseMultiply(MatAT!, b, ATb)
            let LLT = SparseFactor(SparseFactorizationCholesky, MatATA!)
            SparseSolve(LLT, ATb, x)
            
            var idx = 0
            for v in List[0].verticesRaw() {
                v.x = x.data[Int(3*idx)]
                v.y = x.data[Int(3*idx+1)]
                v.z = x.data[Int(3*idx+2)]
                
                //v.nX = 0.0
                //v.nY = 0.0
                //v.nZ = 0.0
                idx += 1
            }
        }
            
        //=============================================
        // Compute normals
        //=============================================
        /*for face in List[0].facesRaw() {
            let v1 = List[0].RawVertex(face.V1) - List[0].RawVertex(face.V0)
            let v2 = List[0].RawVertex(face.V2) - List[0].RawVertex(face.V0)
            var nmle = v1.cross(v2)
            nmle = nmle/nmle.norm_two()
            
            List[0].verticesRaw()[face.V0].nX = List[0].verticesRaw()[face.V0].nX + nmle.x
            List[0].verticesRaw()[face.V0].nY = List[0].verticesRaw()[face.V0].nY + nmle.y
            List[0].verticesRaw()[face.V0].nZ = List[0].verticesRaw()[face.V0].nZ + nmle.z
            
            List[0].verticesRaw()[face.V1].nX = List[0].verticesRaw()[face.V1].nX + nmle.x
            List[0].verticesRaw()[face.V1].nY = List[0].verticesRaw()[face.V1].nY + nmle.y
            List[0].verticesRaw()[face.V1].nZ = List[0].verticesRaw()[face.V1].nZ + nmle.z
            
            List[0].verticesRaw()[face.V2].nX = List[0].verticesRaw()[face.V2].nX + nmle.x
            List[0].verticesRaw()[face.V2].nY = List[0].verticesRaw()[face.V2].nY + nmle.y
            List[0].verticesRaw()[face.V2].nZ = List[0].verticesRaw()[face.V2].nZ + nmle.z
        }
        
        for v in List[0].verticesRaw() {
            var nmle = float3(v.nX, v.nY, v.nZ)
            if nmle.norm_two() > 0.0 {
                nmle = nmle/nmle.norm_two()
            }
            v.nX = nmle.x
            v.nY = nmle.y
            v.nZ = nmle.z
        }*/
        
        CVPixelBufferUnlockBaseAddress(mappingBuffer, CVPixelBufferLockFlags(rawValue: 0))
        CVPixelBufferUnlockBaseAddress(vmapBuffer, CVPixelBufferLockFlags(rawValue: 0))
        return true
        
    }
    
    func initSparseSystem() {
        let nb_col = 3*List[0].VertexCount()
        let nb_lines = 3*36 + 3*6*List[0].FaceCount()
        
        //==========================================
        // Add landmarks
        //==========================================
        let weight: Float = 10.0
        
        for k in 0...35 {
            for offset in 0...2 {
                SparseParamAT.rowIndices.append(Int32(3*FACIAL_LANDMARKS[k]+offset))
                SparseParamAT.values.append(weight)
                SparseParamAT.columnStarts.append(SparseParamAT.rowIndices.count)
            }
        }
        
        for face in List[0].facesRaw() {
            for k in 0...2 {
                var v_idx = 0
                var v_idx_n = 0
                var v_idx_nn = 0
                switch k {
                case 0:
                    v_idx = face.V0
                    v_idx_n = face.V1
                    v_idx_nn = face.V2
                    break
                case 1:
                    v_idx = face.V1
                    v_idx_n = face.V2
                    v_idx_nn = face.V0
                    break
                default:
                    v_idx = face.V2
                    v_idx_n = face.V0
                    v_idx_nn = face.V1
                    break
                }
                
                for offset in 0...2 {
                    SparseParamAT.rowIndices.append(Int32(3*v_idx+offset))
                    SparseParamAT.values.append(-1.0)
                    SparseParamAT.rowIndices.append(Int32(3*v_idx_n+offset))
                    SparseParamAT.values.append(1.0)
                    SparseParamAT.columnStarts.append(SparseParamAT.rowIndices.count)
                }
                
                for offset in 0...2 {
                    SparseParamAT.rowIndices.append(Int32(3*v_idx+offset))
                    SparseParamAT.values.append(-1.0)
                    SparseParamAT.rowIndices.append(Int32(3*v_idx_nn+offset))
                    SparseParamAT.values.append(1.0)
                    SparseParamAT.columnStarts.append(SparseParamAT.rowIndices.count)
                }
            }
        }
        
        var attributes = SparseAttributes_t()
        attributes.triangle = SparseLowerTriangle
        attributes.kind = SparseSymmetric
        
        let structureAT = SparseMatrixStructure(rowCount: Int32(nb_col),
                                                columnCount: Int32(nb_lines),
                                                columnStarts: &SparseParamAT.columnStarts,
                                                rowIndices: &SparseParamAT.rowIndices,
                                                attributes: SparseAttributes_t(),
                                                blockSize: 1)
        
        MatAT = SparseMatrix_Float(structure: structureAT, data: &SparseParamAT.values)
        
        // Compute ATA and ATbvar
        var SparseParamA = SparseParam()
        Transpose_Sparse(MatAT!, &SparseParamA)
        let structureA = SparseMatrixStructure(rowCount: Int32(nb_lines),
                                               columnCount: Int32(nb_col),
                                               columnStarts: &SparseParamA.columnStarts,
                                               rowIndices: &SparseParamA.rowIndices,
                                               attributes: SparseAttributes_t(),
                                               blockSize: 1)
        let A = SparseMatrix_Float(structure: structureA, data: &SparseParamA.values)
        
        print("Transpose_Sparse AT done")
        
        Multiply_Sparse(MatAT!, A, &SparseParamATA)
        let structureATA = SparseMatrixStructure(rowCount: Int32(nb_col),
                                                 columnCount: Int32(nb_col),
                                                 columnStarts: &SparseParamATA.columnStarts,
                                                 rowIndices: &SparseParamATA.rowIndices,
                                                 attributes: attributes,
                                                 blockSize: 1)
        MatATA = SparseMatrix_Float(structure: structureATA, data: &SparseParamATA.values)
        
        print("Ready for Init")
    }
    
    func UpdateBump(inputRGBD: RGBDController, pose: float4x4) {
        if !bumpMapper.isPrepared {
            var formatDescription: CMFormatDescription?
            CMVideoFormatDescriptionCreateForImageBuffer(kCFAllocatorDefault, attributes.bumpImage!, &formatDescription)
            bumpMapper.prepare(with: formatDescription!, outputRetainedBufferCountHint: 2)
        }
        attributes.bumpImage = bumpMapper.UpdateBump(input: attributes, VMapSensor: inputRGBD.vmapBuffer!, NMapSensor: inputRGBD.nmapBuffer!, Pose: pose)
    }
    
    func UpdateBumpMedian(inputRGBD: RGBDController, pose: float4x4) {
        if !bumpMapper.isPrepared {
            var formatDescription: CMFormatDescription?
            CMVideoFormatDescriptionCreateForImageBuffer(kCFAllocatorDefault, attributes.bumpImage!, &formatDescription)
            bumpMapper.prepare(with: formatDescription!, outputRetainedBufferCountHint: 2)
        }
        attributes.bumpImage = bumpMapper.UpdateBumpMedian(input: attributes, VMapSensor: inputRGBD.vmapBuffer!, NMapSensor: inputRGBD.nmapBuffer!, Pose: pose)
    }
    
    func UpdateBumpVMP(inputRGBD: RGBDController, pose: float4x4) {
        if !bumpMapper.isPrepared {
            var formatDescription: CMFormatDescription?
            CMVideoFormatDescriptionCreateForImageBuffer(kCFAllocatorDefault, attributes.bumpImage!, &formatDescription)
            bumpMapper.prepare(with: formatDescription!, outputRetainedBufferCountHint: 2)
        }
        attributes.bumpImage = bumpMapper.VMP(input: attributes, RGBSensor: inputRGBD.rgbBuffer!, VMapSensor: inputRGBD.vmapBuffer!, NMapSensor: inputRGBD.nmapBuffer!, Pose: pose)
    }
    
    func OcclusionLabelling(depthTexture: MTLTexture,  modelViewMatrix: Matrix4, projectionMatrix: Matrix4) {
        if !bumpMapper.isPrepared {
            var formatDescription: CMFormatDescription?
            CMVideoFormatDescriptionCreateForImageBuffer(kCFAllocatorDefault, attributes.bumpImage!, &formatDescription)
            bumpMapper.prepare(with: formatDescription!, outputRetainedBufferCountHint: 2)
        }
        attributes.Labels = bumpMapper.OcclusionLabeling(input: attributes, depthTexture: depthTexture, modelViewMatrix: modelViewMatrix, projectionMatrix: projectionMatrix)
        
        //SaveToPly(VMapBuffer: attributes.VMap!, NMapBuffer: attributes.NMap!, Labels: attributes.Labels!)
    }

    func ComputeVMap(VMPFlag: Bool = true) {
        if !bumpMapper.isPrepared {
            var formatDescription: CMFormatDescription?
            CMVideoFormatDescriptionCreateForImageBuffer(kCFAllocatorDefault, attributes.bumpImage!, &formatDescription)
            bumpMapper.prepare(with: formatDescription!, outputRetainedBufferCountHint: 2)
        }
        attributes.VMap = bumpMapper.VMap(input: attributes, VMPFlag: VMPFlag)
        
    }
    
    func ComputeVMapTemplate() {
        if !bumpMapper.isPrepared {
            var formatDescription: CMFormatDescription?
            CMVideoFormatDescriptionCreateForImageBuffer(kCFAllocatorDefault, attributes.bumpImage!, &formatDescription)
            bumpMapper.prepare(with: formatDescription!, outputRetainedBufferCountHint: 2)
        }
        attributes.VMap = bumpMapper.VMapTemplate(input: attributes)
        
    }
    
    func ComputeNMap() {
        if !filterVMapToNMap.isPrepared {
            var mapFormatDescription: CMFormatDescription?
            CMVideoFormatDescriptionCreateForImageBuffer(kCFAllocatorDefault, attributes.VMap!, &mapFormatDescription)
            filterVMapToNMap.prepare(with: mapFormatDescription!, outputRetainedBufferCountHint: 2, width: WIDTH_BUMP, height: HEIGHT_BUMP)
        }
        attributes.NMap = filterVMapToNMap.render(pixelBuffer: attributes.VMap!)
        
        //SaveToPly(VMapBuffer: attributes.VMap!, NMapBuffer: attributes.NMap!)
        //SaveToPly(VMapBuffer: attributes.VMap!, NMapBuffer: attributes.NMap!, Bump: attributes.bumpImage!)
    }
    
    func setCoeff(_ ID: Int, _ coeff: Float) {
        coefficients[ID] = coeff
        memcpy(attributes.CoeffBuffer!.contents(), UnsafeMutableRawPointer(&coefficients), List.count*MemoryLayout<Float>.size)
    }
    
    func getFaceBBox(_ pose: float4x4, _ intrinsicRGB: Array<Double>, _ depthToRGB: Array<Double>) -> CGRect {
        
        let poseToRGB: float4x4 = float4x4.init([float4(Float(depthToRGB[0]), Float(depthToRGB[4]), Float(depthToRGB[8]), Float(depthToRGB[12])),
                                                 float4(Float(depthToRGB[1]), Float(depthToRGB[5]), Float(depthToRGB[9]), Float(depthToRGB[13])),
                                                 float4(Float(depthToRGB[2]), Float(depthToRGB[6]), Float(depthToRGB[10]), Float(depthToRGB[14])),
                                                 float4(Float(depthToRGB[3]), Float(depthToRGB[7]), Float(depthToRGB[11]), Float(depthToRGB[15]))])
        
        var min_x = DEPTH_WIDTH
        var max_x = 0.0
        var min_y = DEPTH_HEIGHT
        var max_y = 0.0
        
        let count = FACIAL_LANDMARKS.count
        for k in 0...count-1 {
            var Vtx = float4(List[0].RawVertex(FACIAL_LANDMARKS[k]).x, List[0].RawVertex(FACIAL_LANDMARKS[k]).y, List[0].RawVertex(FACIAL_LANDMARKS[k]).z, 1.0)
            
            Vtx = poseToRGB*pose*Vtx
            
            var pixel = double2(0,0)
            pixel.x = Double((Vtx.x/(-Vtx.z))*Float(intrinsicRGB[0]) + Float(intrinsicRGB[2]))
            pixel.y = Double(((Vtx.y/(-Vtx.z))*Float(intrinsicRGB[4]) + Float(intrinsicRGB[5])))
            
            if min_x > pixel.x {
                min_x = pixel.x
            }
            
            if max_x < pixel.x {
                max_x = pixel.x
            }
            
            if min_y > pixel.y {
                min_y = pixel.y
            }
            
            if max_y < pixel.y {
                max_y = pixel.y
            }
        }
        
        return CGRect.init(x: max(0,(min_x-20.0)/DEPTH_WIDTH), y: max(0,(min_y-20.0)/DEPTH_HEIGHT), width: min(1.0,(max_x - min_x+40.0)/DEPTH_WIDTH), height: min(1.0, (max_y - min_y+40.0)/DEPTH_HEIGHT))
    }
    
    func getCoeff() -> Array<Float> {
        return coefficients
    }
    
    func getLandmark(_ k: Int, _ i: Int) -> float4 {
        if k == 0 {
            return Landmarks[i]
        }
        return float4(List[k].RawVertex(FACIAL_LANDMARKS[i]).x, List[k].RawVertex(FACIAL_LANDMARKS[i]).y, List[k].RawVertex(FACIAL_LANDMARKS[i]).z, 1.0)
    }
    
    func getNmleLandmark(_ k: Int, _ i: Int) -> float4 {
        return float4(List[k].RawNmle(FACIAL_LANDMARKS[i]).x, List[k].RawVertex(FACIAL_LANDMARKS[i]).y, List[k].RawVertex(FACIAL_LANDMARKS[i]).z, 0.0)
    }
    
    func getBlendVector(_ k: Int, _ i: Int) -> float4 {
        return blendVector[k][i]
    }
    
    /**
     Function to reads current state of the variational message passing into the 3D deviation map
     
     ### NAIVE IMPLEMENTATION ###
     */
    func UpdateBumpWithVMP(_ VMapPixelBuffer: CVPixelBuffer, _ NMapPixelBuffer: CVPixelBuffer, _ instrinsicDepth: [Double], _ pose: float4x4) {
        
        //for _ in 0...9 {
            VMPManager.VMP(attributes.VMap!, attributes.NMap!, coefficients, VMapPixelBuffer, NMapPixelBuffer, instrinsicDepth, pose)
        //}
        
        CVPixelBufferLockBaseAddress(attributes.bumpImage!, CVPixelBufferLockFlags(rawValue: 0));
        let floatBuffer = unsafeBitCast(CVPixelBufferGetBaseAddress(attributes.bumpImage!), to: UnsafeMutablePointer<Float>.self)
        
        for i in 0...HEIGHT_BUMP-1 {
            for j in 0...WIDTH_BUMP-1 {
                floatBuffer[4*(WIDTH_BUMP * i + j)] = VMPManager.getBumpVal(i,j)
                /*if floatBuffer[4*(width * i + j)] == Float(0.0) {
                    floatBuffer[4*(width * i + j) + 1] = Float(1.0)
                } else {
                    floatBuffer[4*(width * i + j) + 1] = Float(1.0)
                }*/
            }
        }
        
        CVPixelBufferUnlockBaseAddress(attributes.bumpImage!, CVPixelBufferLockFlags(rawValue: 0))
    }
    
    func ResetBump() {
        CVPixelBufferLockBaseAddress(attributes.bumpImage!, CVPixelBufferLockFlags(rawValue: 0));
        let floatBuffer = unsafeBitCast(CVPixelBufferGetBaseAddress(attributes.bumpImage!), to: UnsafeMutablePointer<Float>.self)
        
        for i in 0...HEIGHT_BUMP-1 {
            for j in 0...WIDTH_BUMP-1 {
                floatBuffer[4*(WIDTH_BUMP * i + j)] = 0.0
                floatBuffer[4*(WIDTH_BUMP * i + j) + 1] = 0.0
            }
        }
        
        CVPixelBufferUnlockBaseAddress(attributes.bumpImage!, CVPixelBufferLockFlags(rawValue: 0))
    }
    
    func ComputeRGBMap(RGBSensor: CVPixelBuffer, projectionMatrix: Matrix4, calibMatrix: Matrix4, Pose: float4x4) {
        if !colorMapper.isPrepared {
            var formatDescription: CMFormatDescription?
            CMVideoFormatDescriptionCreateForImageBuffer(kCFAllocatorDefault, attributes.RGBImage!, &formatDescription)
            colorMapper.prepare(with: formatDescription!, outputRetainedBufferCountHint: 2)
        }
        attributes.RGBImage = colorMapper.RGBMap(input: attributes, RGBSensor: RGBSensor, projectionMatrix: projectionMatrix, calibMatrix: calibMatrix, Pose: Pose)
    }
    
    func BilateralFilerBump(size: Float, s_r: Float, s_d: Float, s_c: Float, VMPFlag: Bool = true) {
        if !PostProcessor.isPrepared {
            var formatDescription: CMFormatDescription?
            CMVideoFormatDescriptionCreateForImageBuffer(kCFAllocatorDefault, attributes.bumpImage!, &formatDescription)
            PostProcessor.prepare(with: formatDescription!, outputRetainedBufferCountHint: 2)
        }
        attributes.bumpImage = PostProcessor.BilateralFilter(input: attributes, size: size, s_r: s_r, s_d: s_d, s_c: s_c, VMPFlag: VMPFlag)
    }
    
    func UpdateIndices(indices: MTLBuffer) {
        if !PostProcessor.isPrepared {
            var formatDescription: CMFormatDescription?
            CMVideoFormatDescriptionCreateForImageBuffer(kCFAllocatorDefault, attributes.bumpImage!, &formatDescription)
            PostProcessor.prepare(with: formatDescription!, outputRetainedBufferCountHint: 2)
        }
        PostProcessor.UpdateIndices(input: attributes, indices: indices)
    }
    
    func ResetVariance() {
        if !PostProcessor.isPrepared {
            var formatDescription: CMFormatDescription?
            CMVideoFormatDescriptionCreateForImageBuffer(kCFAllocatorDefault, attributes.bumpImage!, &formatDescription)
            PostProcessor.prepare(with: formatDescription!, outputRetainedBufferCountHint: 2)
        }
        PostProcessor.ResetVariance(input: attributes, PriorBuffer: bumpMapper.GetPrior())
    }
    
    func SetBump(_ VMPFlag: Bool) {
        let path = Bundle.main.path(forResource: "Labelsb-\(WIDTH_BUMP) copy", ofType: "png")
        let imageNGLabel = NSImage(contentsOfFile: path!)
        if imageNGLabel == nil {
            print ("Can not load: ", "Labelsb-¥(width).png")
            return
        }
        let bmpNG = imageNGLabel!.representations[0] as! NSBitmapImageRep
        let dataNG: UnsafeMutablePointer<UInt8> = bmpNG.bitmapData!
        let uint8pointerNG = UnsafeRawPointer(dataNG).bindMemory(to: UInt8.self, capacity: 1)
        
        var dataZeros: [Float] = Array<Float>.init(repeating: 0.0, count: Int(4*WIDTH_BUMP*HEIGHT_BUMP))
        
        CVPixelBufferLockBaseAddress(attributes.RGBImage!, CVPixelBufferLockFlags(rawValue: 0));
        let rgbBuffer = unsafeBitCast(CVPixelBufferGetBaseAddress(attributes.RGBImage!), to: UnsafeMutablePointer<Float>.self)
        
        rgbBuffer.initialize(from: &dataZeros, count: Int(4*WIDTH_BUMP*HEIGHT_BUMP))
        
        CVPixelBufferUnlockBaseAddress(attributes.RGBImage!, CVPixelBufferLockFlags(rawValue: 0))
        
        
        for i in 0...HEIGHT_BUMP-1 {
            for j in 0...WIDTH_BUMP-1 {
                if VMPFlag {
                    dataZeros[4*(i*WIDTH_BUMP+j)+1] = -200.0
                } else {
                    dataZeros[4*(i*WIDTH_BUMP+j)+1] = 0.0
                }
                if uint8pointerNG[4*(i*WIDTH_BUMP+j)] > 200 {
                    dataZeros[4*(i*WIDTH_BUMP+j)+2] = -1.0
                } else {
                    dataZeros[4*(i*WIDTH_BUMP+j)+2] = 0.0
                }
            }
        }
        CVPixelBufferLockBaseAddress(attributes.bumpImage!, CVPixelBufferLockFlags(rawValue: 0));
        let bumpBuffer = unsafeBitCast(CVPixelBufferGetBaseAddress(attributes.bumpImage!), to: UnsafeMutablePointer<Float>.self)
        
        bumpBuffer.initialize(from: &dataZeros, count: Int(4*WIDTH_BUMP*HEIGHT_BUMP))
        
        CVPixelBufferUnlockBaseAddress(attributes.bumpImage!, CVPixelBufferLockFlags(rawValue: 0))
    }
    
    func SetTemplate(rootname: String) {
        self.List.removeAll()
        
        List.append(Template(filename: rootname+"_0"))
        print("neutral mesh loaded")
        
        BSQueue.async {
            for i in 1...27 {
                var pathName: String = ""
                pathName = rootname+"_\(i)"
                self.List.append(Template(filename: pathName))
                print("mesh \(i) loaded")
            }
        }
    }
    
    func getAttributes() -> Param3D {
        return attributes
    }
    
    func getBumpImage() -> CVPixelBuffer? {
        return attributes.bumpImage
    }
}

