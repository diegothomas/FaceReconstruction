//
//  Template.swift
//  WrinkleMe-mac
//
//  Created by Diego Thomas on 2018/02/19.
//  Copyright © 2018 3DLab. All rights reserved.
//

import Foundation
import MetalPerformanceShaders

class Template {
    
    private var VerticesRaw: [Vertex] = []
    private var UVs: [UV] = []
    private var Rotations: [float3x3] = []
    private var FacesRaw: [Triangle] = []
    
    // OBJ file
    init(filename: String) {
        //if let fileURLProject = Bundle.main.path(forResource: filename, ofType: "obj") {
            // prepare buffer for vertices, normals.
        //    print(fileURLProject)
        //    let fileDir = "/Users/diegothomas/Documents/Projects/Data/KinectV2/KinectV2-2/Template/Mesh_0.obj"
            print(filename)
            
            // Read from the file
            var readStringProject = ""
            do {
                readStringProject = try String(contentsOfFile: filename, encoding: String.Encoding.utf8)
            } catch let error as NSError {
                print("Failed reading from URL: \(filename), Error: " + error.localizedDescription)
            }
            
            let buffer = readStringProject.components(separatedBy: [" ", "/", "\n"])
            let nblines = buffer.count
            var word: String!
            for i in 0...nblines-1 {
                word = buffer[i]
                switch word {
                case "Vertices:":
                    let nbVertices = (buffer[i+1] as NSString).intValue
                    VerticesRaw.reserveCapacity(Int(nbVertices))
                    Rotations.reserveCapacity(Int(nbVertices))
                    //print("There are \(nbVertices) Vertices in the template mesh")
                    break
                case "Faces:":
                    let nbFaces = (buffer[i+1] as NSString).intValue
                    FacesRaw.reserveCapacity(Int(nbFaces))
                    //print("There are \(nbFaces) Faces in the template mesh")
                    break
                case "Uvs:":
                    let nbUV = (buffer[i+1] as NSString).intValue
                    UVs.reserveCapacity(Int(nbUV))
                    //print("There are \(nbUV) UV in the template mesh")
                    break
                case "v":
                    VerticesRaw.append(Vertex(_x: (buffer[i+1] as NSString).floatValue, _y: -(buffer[i+2] as NSString).floatValue, _z: -(buffer[i+3] as NSString).floatValue, _r: 1.0, _g: 0.0, _b: 0.0, _a: 1.0, _s: 0.0, _t: 0.0))
                    Rotations.append(float3x3.init(diagonal: float3(0.0)))
                    break
                case "vn": // assumes vn comes right after a new v
                    let normalVector = [(buffer[i+1] as NSString).floatValue,
                                        -(buffer[i+2] as NSString).floatValue,
                                        -(buffer[i+3] as NSString).floatValue]
                    let normNormale = sqrtf(normalVector[0]*normalVector[0] + normalVector[1]*normalVector[1] + normalVector[2]*normalVector[2])
                    
                    VerticesRaw.last?.nX = normalVector[0]/normNormale
                    VerticesRaw.last?.nY = normalVector[1]/normNormale
                    VerticesRaw.last?.nZ = normalVector[2]/normNormale
                    break
                case "vt":
                    UVs.append(UV(u: (buffer[i+1] as NSString).floatValue, v: (buffer[i+2] as NSString).floatValue))
                    break
                case "f":
                    FacesRaw.append(Triangle(v0: Int((buffer[i+1] as NSString).intValue)-1,
                                             uv0: Int((buffer[i+2] as NSString).intValue)-1,
                                             v1: Int((buffer[i+3] as NSString).intValue)-1,
                                             uv1: Int((buffer[i+4] as NSString).intValue)-1,
                                             v2: Int((buffer[i+5] as NSString).intValue)-1,
                                             uv2: Int((buffer[i+6] as NSString).intValue)-1))
                    break
                default:
                    break
                }
            }
            
        //}
        //print(VerticesRaw.count)
    }
    
    
    
    
    func verticesRaw() -> Array<Vertex> {
        return VerticesRaw
    }
    
    func facesRaw() -> Array<Triangle> {
        return FacesRaw
    }
    
    func scale(factor: float2) {
        for vertex in VerticesRaw {
            vertex.x = vertex.x*factor.x
            vertex.y = vertex.y*factor.y
            vertex.z = vertex.z*factor.x
        }
    }
    
    func RawVertex(_ idx: Int) -> float3 {
        return float3(VerticesRaw[idx].x, VerticesRaw[idx].y, VerticesRaw[idx].z)
    }
    
    func SetVertex(_ idx: Int, _ pt: float3) {
        VerticesRaw[idx].x = pt.x
        VerticesRaw[idx].y = pt.y
        VerticesRaw[idx].z = pt.z
    }
    
    func RawNmle(_ idx: Int) -> float3 {
        return float3(VerticesRaw[idx].nX, VerticesRaw[idx].nY, VerticesRaw[idx].nZ)
    }
    
    func Rotation(_ idx: Int) -> float3x3 {
        return Rotations[idx]
    }
    
    func VertexCount() -> Int {
        return VerticesRaw.count
    }
    
    func FaceCount() -> Int {
        return FacesRaw.count
    }
    
    func GetWeightedNormal(face: Triangle) -> float3 {
        let v1 = float3(VerticesRaw[face.V1].x - VerticesRaw[face.V0].x,
                        VerticesRaw[face.V1].y - VerticesRaw[face.V0].y,
                        VerticesRaw[face.V1].z - VerticesRaw[face.V0].z)
        let v2 = float3(VerticesRaw[face.V2].x - VerticesRaw[face.V0].x,
                        VerticesRaw[face.V2].y - VerticesRaw[face.V0].y,
                        VerticesRaw[face.V2].z - VerticesRaw[face.V0].z)
        
        let b = v1 / v1.norm_two()
        
        let proj = b.dot(v2)
        
        let h = v2 - proj*b
        let height = sqrt(h.norm_two())
        let area = v1.norm_two()*height/2.0
        
        let res = v1.cross(v2)
        return (res/res.norm_two())*area
        
    }
    
    func isBack(_ id: Int) -> Bool {
        return VerticesRaw[id].isBack
    }
    
    func Rotate(_ rot: float3x3) {
        for vtx in VerticesRaw {
            let v = rot*float3(vtx.x, vtx.y, vtx.z)
            vtx.x = v.x
            vtx.y = v.y
            vtx.z = v.z
            
            let n = rot*float3(vtx.nX, vtx.nY, vtx.nZ)
            vtx.nX = n.x
            vtx.nY = n.y
            vtx.nZ = n.z
        }
    }
    
    func Translate(_ tr: float3) {
        for vtx in VerticesRaw {
            vtx.x = vtx.x + tr.x
            vtx.y = vtx.y + tr.y
            vtx.z = vtx.z + tr.z
        }
    }
    
    func Transform(_ pose: float4x4) {
        for vtx in VerticesRaw {
            let v = pose*float4(vtx.x, vtx.y, vtx.z, 1.0)
            vtx.x = v.x
            vtx.y = v.y
            vtx.z = v.z
            
            let n = pose*float4(vtx.nX, vtx.nY, vtx.nZ, 0.0)
            vtx.nX = n.x
            vtx.nY = n.y
            vtx.nZ = n.z
        }
    }
    
    func computeTgtPlane() {
        
        for face in FacesRaw {
            for k in 0...2 {
                var v_idx = 0
                var v_idx_n = 0
                switch k {
                case 0:
                    v_idx = face.V0
                    v_idx_n = face.V1
                    break
                case 1:
                    v_idx = face.V1
                    v_idx_n = face.V2
                    break
                default:
                    v_idx = face.V2
                    v_idx_n = face.V0
                    break
                }
                
                if Rotations[v_idx].normF() != Float(0.0) {
                    continue
                }
                
                // Compute original and transformed tangent basis
                let pt1 = float3(VerticesRaw[v_idx].x, VerticesRaw[v_idx].y, VerticesRaw[v_idx].z)
                let e3 = float3(VerticesRaw[v_idx].nX, VerticesRaw[v_idx].nY, VerticesRaw[v_idx].nZ)
                
                // Compute original basis, centered on pt1, with z nmle and oriented in p1->p2
                let pt2 = float3(VerticesRaw[v_idx_n].x, VerticesRaw[v_idx_n].y, VerticesRaw[v_idx_n].z)
                var e1 = pt2 - pt1
                var proj = e3.dot(e1)
                e1 = e1-proj*e3
                let norm_e1 = e1.norm_two()
                if norm_e1 != 0.0 {
                    e1 = e1/norm_e1
                }
                
                var e2 = e3.cross(e1)
                let norm_e2 = e2.norm_two()
                if norm_e2 != 0.0 {
                    e2 = e2/norm_e2
                }
                
                // Compute transformed basis, centered on pt1', with z nmle and oriented in p1'->p2'
                // replace VerticesRaw by TVerticesRaw????
                let Tpt1 = float3(VerticesRaw[v_idx].x, VerticesRaw[v_idx].y, VerticesRaw[v_idx].z)
                let Tpt2 = float3(VerticesRaw[v_idx_n].x, VerticesRaw[v_idx_n].y, VerticesRaw[v_idx_n].z)
                let Te3 = float3(VerticesRaw[v_idx].nX, VerticesRaw[v_idx].nY, VerticesRaw[v_idx].nZ)
                var Te1 = Tpt2 - Tpt1
                proj = Te1.dot(Te3)
                let norm_Te1 = Te1.norm_two()
                if norm_Te1 != 0.0 {
                    Te1 = Te1/norm_Te1
                }
                
                var Te2 = Te3.cross(Te1)
                let norm_Te2 = Te2.norm_two()
                if norm_Te2 != 0.0 {
                    Te2 = Te2/norm_Te2
                }
                
                // Compute Rotation matrix
                let B1 = float3x3.init(e1, e2, e3)
                let TB1 = float3x3.init(Te1, Te2, Te3)
                
                Rotations[v_idx] = TB1*B1.inverse
            }
        }
        
    }
}



