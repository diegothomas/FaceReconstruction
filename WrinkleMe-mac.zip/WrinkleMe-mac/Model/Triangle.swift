//
//  Triangle.swift
//  WrinkleMe-mac
//
//  Created by Diego Thomas on 2018/02/19.
//  Copyright © 2018 3DLab. All rights reserved.
//

import Foundation

class Triangle {
    
    var V0, V1, V2: Int
    var Uv0, Uv1, Uv2: Int
    
    init(v0: Int, uv0: Int, v1: Int, uv1: Int, v2: Int, uv2: Int){
        V0 = v0
        V1 = v1
        V2 = v2
        
        Uv0 = uv0
        Uv1 = uv1
        Uv2 = uv2
    }
}

