//
//  Node.swift
//  WrinkleMe-mac
//
//  Created by Diego Thomas on 2018/02/19.
//  Copyright © 2018 3DLab. All rights reserved.
//

import Foundation
import Metal
import QuartzCore

class Node {
    
    let device: MTLDevice
    let name: String
    var vertexCount: Int
    var vertexBuffer: MTLBuffer
    var nmleBuffer: MTLBuffer
    var colorBuffer: MTLBuffer
    var indexBuffer: MTLBuffer
    var bufferProvider: BufferProvider
    var texture: MTLTexture
    lazy var samplerState: MTLSamplerState? = Node.defaultSampler(device: self.device)
    var depthStencilState: MTLDepthStencilState
    var mainPassDepthTexture: MTLTexture
    
    var Recorder: MetalVideoRecorder?
    
    var positionX: Float = 0.0
    var positionY: Float = 0.0
    var positionZ: Float = 0.0
    
    var rotationX: Float = 0.0
    var rotationY: Float = 0.0
    var rotationZ: Float = 0.0
    var scale: Float     = 1.0
    var record = false
    var idx = 0
    var width = WIDTH_BUMP
    var height = HEIGHT_BUMP
    
    //let light = Light(color: (1.0,1.0,1.0), ambientIntensity: 0.1, direction: (0.0, 0.0, 1.0), diffuseIntensity: 0.8, shininess: 5, specularIntensity: 2)
    let light = Light(color: (1.0,1.0,1.0), ambientIntensity: 0.2, direction: (0.0, 0.0, 1.0), diffuseIntensity: 0.5, shininess: 1, specularIntensity: 1)
    
    init(name: String, dataSize: Int, indices: MTLBuffer, device: MTLDevice, texture: MTLTexture){
        
        let vertexData: [Float] = Array<Float>.init(repeating: 0.0, count: dataSize*MemoryLayout<Float>.size)
        vertexBuffer = device.makeBuffer(bytes: vertexData, length: dataSize*MemoryLayout<Float>.size, options: [])!
        nmleBuffer = device.makeBuffer(bytes: vertexData, length: dataSize*MemoryLayout<Float>.size, options: [])!
        let colorData: [Float] = Array<Float>.init(repeating: 0, count: dataSize*MemoryLayout<Float>.size)
        colorBuffer = device.makeBuffer(bytes: colorData, length: dataSize*MemoryLayout<Float>.size, options: [])!
        print("number of vertices: ", vertexData.count/6)
        
        indexBuffer = indices
        
        self.name = name
        self.device = device
        vertexCount = dataSize/6 //vertices.count
        self.texture = texture
        
        let sizeOfUniformsBuffer = MemoryLayout<Float>.size * Matrix4.numberOfElements() * 2 + Light.size()
        self.bufferProvider = BufferProvider(device: device, inflightBuffersCount: 3, sizeOfUniformsBuffer: sizeOfUniformsBuffer)
        
        let depthStencilDescriptor: MTLDepthStencilDescriptor = MTLDepthStencilDescriptor.init()
        depthStencilDescriptor.depthCompareFunction = MTLCompareFunction.less
        depthStencilDescriptor.isDepthWriteEnabled = true
        
        depthStencilState = device.makeDepthStencilState(descriptor: depthStencilDescriptor)!
        
        let texDesc = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: MTLPixelFormat.depth32Float,
                                                               width: Int(1280),
                                                               height: Int(960),
                                                               mipmapped: false)
        texDesc.usage = [MTLTextureUsage.renderTarget, MTLTextureUsage.shaderRead]
        texDesc.storageMode = .private
        mainPassDepthTexture = device.makeTexture(descriptor: texDesc)!
        
        let file = "Projects/OS-Mac/WrinkleMe-Mac/Video/movie.mov"
        
        if let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
            let fileURL = dir.appendingPathComponent(file)
            Recorder = MetalVideoRecorder(outputURL: fileURL, size: CGSize(width: 1280, height: 960))
        } else {
            print ("No good Directory")
        }
        
    }
    
    func render(commandQueue: MTLCommandQueue, pipelineState: MTLRenderPipelineState, drawable: CAMetalDrawable, parentModelViewMatrix: Matrix4, projectionMatrix: Matrix4, flag: Bool){
        
        _ = bufferProvider.availableResourcesSemaphore.wait(timeout: DispatchTime.distantFuture)
        
        let renderPassDescriptor = MTLRenderPassDescriptor()
        renderPassDescriptor.colorAttachments[0].texture = drawable.texture
        renderPassDescriptor.colorAttachments[0].loadAction = .clear
        renderPassDescriptor.colorAttachments[0].clearColor = MTLClearColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        renderPassDescriptor.colorAttachments[0].storeAction = .store
        
        renderPassDescriptor.depthAttachment.texture = mainPassDepthTexture
        renderPassDescriptor.depthAttachment.clearDepth = 1.0
        renderPassDescriptor.depthAttachment.loadAction = .clear
        renderPassDescriptor.depthAttachment.storeAction = .dontCare
        
        let commandBuffer = commandQueue.makeCommandBuffer()
        commandBuffer?.addCompletedHandler { (_) in
            self.bufferProvider.availableResourcesSemaphore.signal()
        }
        
        let renderEncoder = commandBuffer?.makeRenderCommandEncoder(descriptor: renderPassDescriptor)
        renderEncoder?.setRenderPipelineState(pipelineState)
        renderEncoder?.setVertexBuffer(vertexBuffer, offset: 0, index: 0)
        renderEncoder?.setVertexBuffer(nmleBuffer, offset: 0, index: 1)
        renderEncoder?.setVertexBuffer(colorBuffer, offset: 0, index: 2)
        renderEncoder?.setCullMode(MTLCullMode.back)
        renderEncoder?.setDepthStencilState(depthStencilState)
        
        renderEncoder?.setFragmentTexture(texture, index: 0)
        renderEncoder?.setFragmentTexture(mainPassDepthTexture, index: 1)
        if let samplerState = samplerState{
            renderEncoder?.setFragmentSamplerState(samplerState, index: 0)
        }
        
        let nodeModelMatrix = self.modelMatrix()
        nodeModelMatrix.multiplyLeft(parentModelViewMatrix)
        
        let uniformBuffer = bufferProvider.nextUniformsBuffer(projectionMatrix: projectionMatrix, modelViewMatrix: nodeModelMatrix, light: light)
        
        renderEncoder?.setVertexBuffer(uniformBuffer, offset: 0, index: 3)
        renderEncoder?.setFragmentBuffer(uniformBuffer, offset: 0, index: 1)
        //renderEncoder?.drawPrimitives(type: .point, vertexStart: 0, vertexCount: 240*240, instanceCount: 1)
        renderEncoder?.drawIndexedPrimitives(type: .triangle, indexCount: 6*(width-1)*(height-1), indexType: MTLIndexType.uint32, indexBuffer: indexBuffer, indexBufferOffset: 0)
        renderEncoder?.endEncoding()
        
        if (flag) {
            if record {
                let texture = drawable.texture
                commandBuffer?.addCompletedHandler { commandBuffer in self.Recorder?.writeFrame(forTexture: texture, idx: self.idx) }
                self.idx = self.idx+1
                record = false
            }
            
            commandBuffer?.present(drawable)
        }
        commandBuffer?.commit()
        
        commandBuffer?.waitUntilCompleted()
    }
    
    func modelMatrix() -> Matrix4 {
        let matrix = Matrix4()
        matrix.translate(positionX, y: positionY, z: positionZ)
        matrix.rotateAroundX(rotationX, y: rotationY, z: rotationZ)
        matrix.scale(scale, y: scale, z: scale)
        return matrix
    }
    
    class func defaultSampler(device: MTLDevice) -> MTLSamplerState {
        let sampler = MTLSamplerDescriptor()
        sampler.minFilter             = MTLSamplerMinMagFilter.nearest
        sampler.magFilter             = MTLSamplerMinMagFilter.nearest
        sampler.mipFilter             = MTLSamplerMipFilter.nearest
        sampler.maxAnisotropy         = 1
        sampler.sAddressMode          = MTLSamplerAddressMode.clampToEdge
        sampler.tAddressMode          = MTLSamplerAddressMode.clampToEdge
        sampler.rAddressMode          = MTLSamplerAddressMode.clampToEdge
        sampler.normalizedCoordinates = true
        sampler.lodMinClamp           = 0
        sampler.lodMaxClamp           = Float.greatestFiniteMagnitude
        return device.makeSamplerState(descriptor: sampler)!
    }
}


