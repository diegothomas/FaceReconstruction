//
//  Mesh.swift
//  WrinkleMe-mac
//
//  Created by Diego Thomas on 2018/02/19.
//  Copyright © 2018 3DLab. All rights reserved.
//

import Foundation
import Metal

class Mesh: Node {
    
    var w = WIDTH_BUMP
    var h = HEIGHT_BUMP
    
    init(device: MTLDevice, commandQ: MTLCommandQueue, dataSize: Int, indices: MTLBuffer) {
        let texture = MetalTexture(resourceName: "Weights-\(w)", ext: "png", mipmaped: true)
        texture.loadTexture(device: device, commandQ: commandQ, flip: true)
        
        super.init(name: "Mesh", dataSize: dataSize, indices: indices, device: device, texture: texture.texture)
    }
    
    func updateVertexBuffer(VMapBuffer: CVPixelBuffer, NMapBuffer: CVPixelBuffer, RGBBuffer: CVPixelBuffer) {
        /*var vertexData = Array<Float>()
        for vertex in vertices{
            vertexData += vertex.floatBuffer()
        }
        
        let dataSize = vertexData.count * MemoryLayout.size(ofValue: vertexData[0])
        vertexBuffer.contents().copyBytes(from: vertexData, count: dataSize)*/
        
        
        CVPixelBufferLockBaseAddress(VMapBuffer, CVPixelBufferLockFlags(rawValue: 0));
        let floatBuffer = unsafeBitCast(CVPixelBufferGetBaseAddress(VMapBuffer), to: UnsafeMutablePointer<Float>.self)
        CVPixelBufferLockBaseAddress(NMapBuffer, CVPixelBufferLockFlags(rawValue: 0));
        let floatBuffer2 = unsafeBitCast(CVPixelBufferGetBaseAddress(NMapBuffer), to: UnsafeMutablePointer<Float>.self)
        CVPixelBufferLockBaseAddress(RGBBuffer, CVPixelBufferLockFlags(rawValue: 0));
        let floatBuffer3 = unsafeBitCast(CVPixelBufferGetBaseAddress(RGBBuffer), to: UnsafeMutablePointer<Float>.self)

        let dataSize = w * h * 4
        vertexBuffer.contents().copyMemory(from: floatBuffer, byteCount: dataSize * MemoryLayout<Float>.size)
        
        nmleBuffer.contents().copyMemory(from: floatBuffer2, byteCount: dataSize * MemoryLayout<Float>.size)
        
        colorBuffer.contents().copyMemory(from: floatBuffer3, byteCount: dataSize * MemoryLayout<Float>.size)

        CVPixelBufferUnlockBaseAddress(RGBBuffer, CVPixelBufferLockFlags(rawValue: 0))
        CVPixelBufferUnlockBaseAddress(NMapBuffer, CVPixelBufferLockFlags(rawValue: 0))
        CVPixelBufferUnlockBaseAddress(VMapBuffer, CVPixelBufferLockFlags(rawValue: 0))
         
 
    }
}

