//
//  BumpMapping.swift
//  WrinkleMe-mac
//
//  Created by Diego Thomas on 2018/03/02.
//  Copyright © 2018 3DLab. All rights reserved.
//

import Foundation
import CoreMedia
import CoreVideo
import Metal

class BumpMapping {
    var description: String = "Bump Mapping"
    
    var isPrepared = false
    
    var width = WIDTH_BUMP
    var height = HEIGHT_BUMP

    
    private(set) var inputFormatDescription: CMFormatDescription?
    
    private(set) var outputFormatDescription: CMFormatDescription?
    
    private var inputTextureFormat: MTLPixelFormat = .invalid
    
    private var outputPixelBufferPool: CVPixelBufferPool!
    
    private let metalDevice = MTLCreateSystemDefaultDevice()!
    
    private var computePipelineState: MTLComputePipelineState?
    
    private var computePipelineState2: MTLComputePipelineState?
    
    private var computePipelineStateInit: MTLComputePipelineState?
    
    private var computePipelineStateNetwork: MTLComputePipelineState?
    
    private var computePipelineStateVMP: MTLComputePipelineState?
    
    private var computePipelineStateOcclusions: MTLComputePipelineState?
    
    private var computePipelineStateTemplate: MTLComputePipelineState?
    
    private var computePipelineStateMedian: MTLComputePipelineState?
    
    private lazy var commandQueue: MTLCommandQueue? = {
        return self.metalDevice.makeCommandQueue()
    }()
    
    private var textureCache: CVMetalTextureCache!
    
    private var calibBuffer: MTLBuffer
    
    let sizeOfCalib = MemoryLayout<Float>.size * 4
    
    private var poseBuffer: MTLBuffer
    
    private var NaturalParamBuffer: MTLBuffer
    
    private var PriorBuffer: MTLBuffer
    
    private var childsBuffer: MTLBuffer
    
    private var parentsBuffer: MTLBuffer
    
    private var projectionBuffer: MTLBuffer
    
    private var modelViewBuffer: MTLBuffer
    
    private var MedianBuffer: MTLBuffer
    
    private var Counter: MTLBuffer
    
    required init() {
        let defaultLibrary = metalDevice.makeDefaultLibrary()!
        let kernelFunction = defaultLibrary.makeFunction(name: "bumpMap")
        do {
            computePipelineState = try metalDevice.makeComputePipelineState(function: kernelFunction!)
        } catch {
            fatalError("Unable to create bumpMap pipeline state. (\(error))")
        }
        
        let kernelFunction2 = defaultLibrary.makeFunction(name: "updatebump")
        do {
            computePipelineState2 = try metalDevice.makeComputePipelineState(function: kernelFunction2!)
        } catch {
            fatalError("Unable to create updatebump pipeline state. (\(error))")
        }
        
        let kernelFunction3 = defaultLibrary.makeFunction(name: "InitParents")
        do {
            computePipelineStateInit = try metalDevice.makeComputePipelineState(function: kernelFunction3!)
        } catch {
            fatalError("Unable to create InitParents pipeline state. (\(error))")
        }
        
        let kernelFunction4 = defaultLibrary.makeFunction(name: "Graph")
        do {
            computePipelineStateNetwork = try metalDevice.makeComputePipelineState(function: kernelFunction4!)
        } catch {
            fatalError("Unable to create Graph pipeline state. (\(error))")
        }
        
        let kernelFunction5 = defaultLibrary.makeFunction(name: "VMP")
        do {
            computePipelineStateVMP = try metalDevice.makeComputePipelineState(function: kernelFunction5!)
        } catch {
            fatalError("Unable to create VMP pipeline state. (\(error))")
        }
        
        let kernelFunction6 = defaultLibrary.makeFunction(name: "Occlusions")
        do {
            computePipelineStateOcclusions = try metalDevice.makeComputePipelineState(function: kernelFunction6!)
        } catch {
            fatalError("Unable to create Occlusions pipeline state. (\(error))")
        }
        
        let kernelFunction7 = defaultLibrary.makeFunction(name: "Template")
        do {
            computePipelineStateTemplate = try metalDevice.makeComputePipelineState(function: kernelFunction7!)
        } catch {
            fatalError("Unable to create Template pipeline state. (\(error))")
        }
        
        let kernelFunction8 = defaultLibrary.makeFunction(name: "medianbump")
        do {
            computePipelineStateMedian = try metalDevice.makeComputePipelineState(function: kernelFunction8!)
        } catch {
            fatalError("Unable to create medianbump pipeline state. (\(error))")
        }
        
        calibBuffer = metalDevice.makeBuffer(length: sizeOfCalib, options: [])!
        poseBuffer = metalDevice.makeBuffer(length: MemoryLayout<Float>.size * 16, options: [])!
        
        NaturalParamBuffer = metalDevice.makeBuffer(length: MemoryLayout<Float>.size * 2*width*height, options: [])!
        PriorBuffer = metalDevice.makeBuffer(length: MemoryLayout<Float>.size * 2*width*height, options: [])!
        childsBuffer = metalDevice.makeBuffer(length: MemoryLayout<Int32>.size * 100*width*height, options: [])!
        parentsBuffer = metalDevice.makeBuffer(length: MemoryLayout<Int32>.size * 100*Int(DEPTH_HEIGHT*DEPTH_WIDTH), options: [])!
        
        MedianBuffer = metalDevice.makeBuffer(length: MemoryLayout<Float>.size * 101*width*height, options: [])!
        Counter = metalDevice.makeBuffer(length: MemoryLayout<Int32>.size * width*height, options: [])!
        
        projectionBuffer = metalDevice.makeBuffer(length: MemoryLayout<Float>.size * Matrix4.numberOfElements(), options: [])!
        modelViewBuffer = metalDevice.makeBuffer(length: MemoryLayout<Float>.size * Matrix4.numberOfElements(), options: [])!
        
        // init prior
        
        let pointer = PriorBuffer.contents().assumingMemoryBound(to: Float.self)
        let pointerN = NaturalParamBuffer.contents().assumingMemoryBound(to: Float.self)
        let pointerCounter = Counter.contents().assumingMemoryBound(to: Int32.self)
        for i in 0...width-1 {
            for j in 0...height-1 {
                pointer[2*(i*width+j)] = 0.0;
                pointer[2*(i*width+j)+1] = -200.0;
                pointerN[2*(i*width+j)] = 0.0;
                pointerN[2*(i*width+j)+1] = 0.0;
                
                pointerCounter[i*width+j] = 0;
            }
        }
    }
    
    static private func allocateOutputBufferPool(with formatDescription: CMFormatDescription, outputRetainedBufferCountHint: Int) -> CVPixelBufferPool? {
        let inputDimensions = CMVideoFormatDescriptionGetDimensions(formatDescription)
        let outputPixelBufferAttributes: [String: Any] = [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_128RGBAFloat,
            kCVPixelBufferWidthKey as String: Int(inputDimensions.width),
            kCVPixelBufferHeightKey as String: Int(inputDimensions.height),
            kCVPixelBufferIOSurfacePropertiesKey as String: [:]
        ]
        
        let poolAttributes = [kCVPixelBufferPoolMinimumBufferCountKey as String: outputRetainedBufferCountHint]
        var cvPixelBufferPool: CVPixelBufferPool?
        // Create a pixel buffer pool with the same pixel attributes as the input format description
        CVPixelBufferPoolCreate(kCFAllocatorDefault, poolAttributes as NSDictionary?, outputPixelBufferAttributes as NSDictionary?, &cvPixelBufferPool)
        guard let pixelBufferPool = cvPixelBufferPool else {
            assertionFailure("Allocation failure: Could not create pixel buffer pool")
            return nil
        }
        return pixelBufferPool
    }
    
    func prepare(with formatDescription: CMFormatDescription, outputRetainedBufferCountHint: Int) {
        reset()
        
        outputPixelBufferPool = BumpMapping.allocateOutputBufferPool(with: formatDescription,
                                                                     outputRetainedBufferCountHint: outputRetainedBufferCountHint)
        if outputPixelBufferPool == nil {
            return
        }
        
        var pixelBuffer: CVPixelBuffer?
        var pixelBufferFormatDescription: CMFormatDescription?
        _ = CVPixelBufferPoolCreatePixelBuffer(kCFAllocatorDefault, outputPixelBufferPool!, &pixelBuffer)
        if let pixelBuffer = pixelBuffer {
            CMVideoFormatDescriptionCreateForImageBuffer(kCFAllocatorDefault, pixelBuffer, &pixelBufferFormatDescription)
        }
        pixelBuffer = nil
        
        inputFormatDescription = formatDescription
        outputFormatDescription = pixelBufferFormatDescription
        
        let inputMediaSubType = CMFormatDescriptionGetMediaSubType(formatDescription)
        if inputMediaSubType == kCVPixelFormatType_128RGBAFloat {
            inputTextureFormat = .rgba32Float
        } else {
            assertionFailure("Input format not supported")
        }
        
        var metalTextureCache: CVMetalTextureCache?
        if CVMetalTextureCacheCreate(kCFAllocatorDefault, nil, metalDevice, nil, &metalTextureCache) != kCVReturnSuccess {
            assertionFailure("Unable to allocate depth to vmap texture cache")
        } else {
            textureCache = metalTextureCache
        }
        
        
        isPrepared = true
    }
    
    func reset() {
        isPrepared = false
    }
    
    func VMap(input: Param3D, VMPFlag: Bool = true) -> CVPixelBuffer? {
        if !isPrepared {
            assertionFailure("Invalid state: Not prepared")
            return nil
        }
        
        var newPixelBuffer: CVPixelBuffer?
        CVPixelBufferPoolCreatePixelBuffer(kCFAllocatorDefault, outputPixelBufferPool!, &newPixelBuffer)
        guard let outputPixelBuffer = newPixelBuffer else {
            print("Allocation failure: Could not get pixel buffer from pool (\(self.description))")
            return nil
        }
        
        guard let outputTexture = makeTextureFromCVPixelBuffer(pixelBuffer: outputPixelBuffer, textureFormat: .rgba32Float),
            let inputTexture0 = makeTextureFromCVPixelBuffer(pixelBuffer: input.bumpImage! , textureFormat: inputTextureFormat),
            let inputTexture1 = makeTextureFromCVPixelBuffer(pixelBuffer: input.WLImage!, textureFormat: inputTextureFormat)  else {
                return nil
        }
        
        var Flag = VMPFlag
        
        // Set up command queue, buffer, and encoder
        guard let commandQueue = commandQueue,
            let commandBuffer = commandQueue.makeCommandBuffer(),
            let commandEncoder = commandBuffer.makeComputeCommandEncoder() else {
                print("Failed to create Metal command queue")
                CVMetalTextureCacheFlush(textureCache!, 0)
                return nil
        }
        
        commandEncoder.label = "Bump Mapping"
        commandEncoder.setComputePipelineState(computePipelineState!)
        commandEncoder.setTexture(inputTexture0, index: 0)
        commandEncoder.setTexture(inputTexture1, index: 1)
        commandEncoder.setTexture(outputTexture, index: 2)
        commandEncoder.setBuffer(input.VtxBuffer!, offset: 0, index: 0)
        commandEncoder.setBuffer(input.NmleBuffer!, offset: 0, index: 1)
        commandEncoder.setBuffer(input.FaceBuffer!, offset: 0, index: 2)
        commandEncoder.setBuffer(input.CoeffBuffer!, offset: 0, index: 3)
        commandEncoder.setBytes( UnsafeMutableRawPointer(&Flag), length: MemoryLayout<Bool>.size, index: 4)
        
        // Set up thread groups as described in https://developer.apple.com/reference/metal/mtlcomputecommandencoder
        let w = computePipelineState!.threadExecutionWidth
        let h = computePipelineState!.maxTotalThreadsPerThreadgroup / w
        let threadsPerThreadgroup = MTLSizeMake(w, h, 1)
        let threadgroupsPerGrid = MTLSize(width: (input.width + w - 1) / w,
                                          height: (input.height + h - 1) / h,
                                          depth: 1)
        commandEncoder.dispatchThreadgroups(threadgroupsPerGrid, threadsPerThreadgroup: threadsPerThreadgroup)
        
        commandEncoder.endEncoding()
        
        commandBuffer.commit()
        commandBuffer.waitUntilCompleted()
        
        return outputPixelBuffer
    }
    
    func VMapTemplate(input: Param3D) -> CVPixelBuffer? {
        if !isPrepared {
            assertionFailure("Invalid state: Not prepared")
            return nil
        }
        
        var newPixelBuffer: CVPixelBuffer?
        CVPixelBufferPoolCreatePixelBuffer(kCFAllocatorDefault, outputPixelBufferPool!, &newPixelBuffer)
        guard let outputPixelBuffer = newPixelBuffer else {
            print("Allocation failure: Could not get pixel buffer from pool (\(self.description))")
            return nil
        }
        
        guard let outputTexture = makeTextureFromCVPixelBuffer(pixelBuffer: outputPixelBuffer, textureFormat: .rgba32Float),
            let inputTexture0 = makeTextureFromCVPixelBuffer(pixelBuffer: input.WLImage!, textureFormat: inputTextureFormat)  else {
                return nil
        }
        
        // Set up command queue, buffer, and encoder
        guard let commandQueue = commandQueue,
            let commandBuffer = commandQueue.makeCommandBuffer(),
            let commandEncoder = commandBuffer.makeComputeCommandEncoder() else {
                print("Failed to create Metal command queue")
                CVMetalTextureCacheFlush(textureCache!, 0)
                return nil
        }
        
        commandEncoder.label = "VMap Template"
        commandEncoder.setComputePipelineState(computePipelineStateTemplate!)
        commandEncoder.setTexture(inputTexture0, index: 0)
        commandEncoder.setTexture(outputTexture, index: 1)
        commandEncoder.setBuffer(input.VtxBuffer!, offset: 0, index: 0)
        commandEncoder.setBuffer(input.NmleBuffer!, offset: 0, index: 1)
        commandEncoder.setBuffer(input.FaceBuffer!, offset: 0, index: 2)
        commandEncoder.setBuffer(input.CoeffBuffer!, offset: 0, index: 3)
        
        // Set up thread groups as described in https://developer.apple.com/reference/metal/mtlcomputecommandencoder
        let w = computePipelineStateTemplate!.threadExecutionWidth
        let h = computePipelineStateTemplate!.maxTotalThreadsPerThreadgroup / w
        let threadsPerThreadgroup = MTLSizeMake(w, h, 1)
        let threadgroupsPerGrid = MTLSize(width: (input.width + w - 1) / w,
                                          height: (input.height + h - 1) / h,
                                          depth: 1)
        commandEncoder.dispatchThreadgroups(threadgroupsPerGrid, threadsPerThreadgroup: threadsPerThreadgroup)
        
        commandEncoder.endEncoding()
        
        commandBuffer.commit()
        commandBuffer.waitUntilCompleted()
        
        return outputPixelBuffer
    }
    
    func setParameters(intrinsic: Array<Double>, ref: NSSize) {
        var param: [Float] = []
        
        param.append(Float(DEPTH_WIDTH*intrinsic[0]/Double(ref.width)))
        param.append(Float(DEPTH_HEIGHT*intrinsic[4]/Double(ref.height)))
        param.append(Float(DEPTH_WIDTH*intrinsic[2]/Double(ref.width)))
        param.append(Float(DEPTH_HEIGHT*intrinsic[5]/Double(ref.height)))
        
        memcpy(calibBuffer.contents(), UnsafeMutableRawPointer(&param), MemoryLayout<Float>.size * 4)
    }
    
    func UpdateBump(input: Param3D, VMapSensor: CVPixelBuffer, NMapSensor: CVPixelBuffer, Pose: float4x4) -> CVPixelBuffer? {
        if !isPrepared {
            assertionFailure("Invalid state: Not prepared")
            return nil
        }
        
        var tmp: [Float] = [Pose.columns.0.x, Pose.columns.0.y, Pose.columns.0.z, Pose.columns.0.w,
                            Pose.columns.1.x, Pose.columns.1.y, Pose.columns.1.z, Pose.columns.1.w,
                            Pose.columns.2.x, Pose.columns.2.y, Pose.columns.2.z, Pose.columns.2.w,
                            Pose.columns.3.x, Pose.columns.3.y, Pose.columns.3.z, Pose.columns.3.w]
        memcpy(poseBuffer.contents(), UnsafeMutableRawPointer(&tmp), MemoryLayout<Float>.size * 16)
        
        var newPixelBuffer: CVPixelBuffer?
        CVPixelBufferPoolCreatePixelBuffer(kCFAllocatorDefault, outputPixelBufferPool!, &newPixelBuffer)
        guard let outputPixelBuffer = newPixelBuffer else {
            print("Allocation failure: Could not get pixel buffer from pool (\(self.description))")
            return nil
        }
        
        guard let outputTexture = makeTextureFromCVPixelBuffer(pixelBuffer: newPixelBuffer!, textureFormat: .rgba32Float),
            let inputTexture0 = makeTextureFromCVPixelBuffer(pixelBuffer: input.bumpImage! , textureFormat: inputTextureFormat),
            let inputTexture1 = makeTextureFromCVPixelBuffer(pixelBuffer: input.WLImage!, textureFormat: inputTextureFormat),
            let inputTexture2 = makeTextureFromCVPixelBuffer(pixelBuffer: VMapSensor, textureFormat: .rgba32Float),
            let inputTexture3 = makeTextureFromCVPixelBuffer(pixelBuffer: NMapSensor, textureFormat: .rgba32Float)  else {
                return nil
        }
        
        // Set up command queue, buffer, and encoder
        guard let commandQueue = commandQueue,
            let commandBuffer = commandQueue.makeCommandBuffer(),
            let commandEncoder = commandBuffer.makeComputeCommandEncoder() else {
                print("Failed to create Metal command queue")
                CVMetalTextureCacheFlush(textureCache!, 0)
                return nil
        }
        
        commandEncoder.label = "Bump Mapping"
        commandEncoder.setComputePipelineState(computePipelineState2!)
        commandEncoder.setTexture(inputTexture0, index: 0)
        commandEncoder.setTexture(inputTexture1, index: 1)
        commandEncoder.setTexture(inputTexture2, index: 2)
        commandEncoder.setTexture(inputTexture3, index: 3)
        commandEncoder.setTexture(outputTexture, index: 4)
        commandEncoder.setBuffer(input.VtxBuffer!, offset: 0, index: 0)
        commandEncoder.setBuffer(input.NmleBuffer!, offset: 0, index: 1)
        commandEncoder.setBuffer(input.FaceBuffer!, offset: 0, index: 2)
        commandEncoder.setBuffer(input.CoeffBuffer!, offset: 0, index: 3)
        commandEncoder.setBuffer(poseBuffer, offset: 0, index: 4)
        commandEncoder.setBuffer(calibBuffer, offset: 0, index: 5)
        
        // Set up thread groups as described in https://developer.apple.com/reference/metal/mtlcomputecommandencoder
        let w = computePipelineState2!.threadExecutionWidth
        let h = computePipelineState2!.maxTotalThreadsPerThreadgroup / w
        let threadsPerThreadgroup = MTLSizeMake(w, h, 1)
        let threadgroupsPerGrid = MTLSize(width: (input.width + w - 1) / w,
                                          height: (input.height + h - 1) / h,
                                          depth: 1)
        commandEncoder.dispatchThreadgroups(threadgroupsPerGrid, threadsPerThreadgroup: threadsPerThreadgroup)
        
        commandEncoder.endEncoding()
        
        commandBuffer.commit()
        commandBuffer.waitUntilCompleted()
        
        return outputPixelBuffer
    }
    
    func VMP(input: Param3D, RGBSensor: CVPixelBuffer, VMapSensor: CVPixelBuffer, NMapSensor: CVPixelBuffer, Pose: float4x4) -> CVPixelBuffer? {
        if !isPrepared {
            assertionFailure("Invalid state: Not prepared")
            return nil
        }
        
        var tmp: [Float] = [Pose.columns.0.x, Pose.columns.0.y, Pose.columns.0.z, Pose.columns.0.w,
                            Pose.columns.1.x, Pose.columns.1.y, Pose.columns.1.z, Pose.columns.1.w,
                            Pose.columns.2.x, Pose.columns.2.y, Pose.columns.2.z, Pose.columns.2.w,
                            Pose.columns.3.x, Pose.columns.3.y, Pose.columns.3.z, Pose.columns.3.w]
        memcpy(poseBuffer.contents(), UnsafeMutableRawPointer(&tmp), MemoryLayout<Float>.size * 16)
        
        var newPixelBuffer: CVPixelBuffer?
        CVPixelBufferPoolCreatePixelBuffer(kCFAllocatorDefault, outputPixelBufferPool!, &newPixelBuffer)
        guard let outputPixelBuffer = newPixelBuffer else {
            print("Allocation failure: Could not get pixel buffer from pool (\(self.description))")
            return nil
        }
        
        guard let outputTexture = makeTextureFromCVPixelBuffer(pixelBuffer: newPixelBuffer!, textureFormat: .rgba32Float),
            let inputTexture0 = makeTextureFromCVPixelBuffer(pixelBuffer: input.bumpImage! , textureFormat: inputTextureFormat),
            let inputTexture1 = makeTextureFromCVPixelBuffer(pixelBuffer: input.WLImage!, textureFormat: inputTextureFormat),
            let inputTexture2 = makeTextureFromCVPixelBuffer(pixelBuffer: input.RGBImage!, textureFormat: inputTextureFormat),
            let inputTexture3 = makeTextureFromCVPixelBuffer(pixelBuffer: VMapSensor, textureFormat: .rgba32Float),
            let inputTexture4 = makeTextureFromCVPixelBuffer(pixelBuffer: NMapSensor, textureFormat: .rgba32Float),
            let inputTexture5 = makeTextureFromCVPixelBuffer(pixelBuffer: RGBSensor, textureFormat: .bgra8Unorm)    else {
                return nil
        }
        
        // Reset parents connections
        // Set up command queue, buffer, and encoder
        guard let commandQueue = commandQueue,
            let commandBuffer = commandQueue.makeCommandBuffer(),
            let commandEncoder = commandBuffer.makeComputeCommandEncoder() else {
                print("Failed to create Metal command queue")
                CVMetalTextureCacheFlush(textureCache!, 0)
                return nil
        }
        
        commandEncoder.label = "Init Parents"
        commandEncoder.setComputePipelineState(computePipelineStateInit!)
        commandEncoder.setBuffer(parentsBuffer, offset: 0, index: 0)
        
        // Set up thread groups as described in https://developer.apple.com/reference/metal/mtlcomputecommandencoder
        var w = computePipelineStateInit!.threadExecutionWidth
        var h = computePipelineStateInit!.maxTotalThreadsPerThreadgroup / w
        var threadsPerThreadgroup = MTLSizeMake(w, h, 1)
        var threadgroupsPerGrid = MTLSize(width: (Int(DEPTH_WIDTH) + w - 1) / w,
                                          height: (Int(DEPTH_HEIGHT) + h - 1) / h,
                                          depth: 1)
        commandEncoder.dispatchThreadgroups(threadgroupsPerGrid, threadsPerThreadgroup: threadsPerThreadgroup)
        
        commandEncoder.endEncoding()
        
        commandBuffer.commit()
        commandBuffer.waitUntilCompleted()
        
        // Create network
        guard let commandBufferNetwork = commandQueue.makeCommandBuffer(),
            let commandEncoderNetwork = commandBufferNetwork.makeComputeCommandEncoder() else {
                print("Failed to create Metal command queue")
                CVMetalTextureCacheFlush(textureCache!, 0)
                return nil
        }
        
        commandEncoderNetwork.label = "Network"
        commandEncoderNetwork.setComputePipelineState(computePipelineStateNetwork!)
        commandEncoderNetwork.setTexture(inputTexture0, index: 0)
        commandEncoderNetwork.setTexture(inputTexture1, index: 1)
        commandEncoderNetwork.setTexture(inputTexture2, index: 2)
        commandEncoderNetwork.setTexture(inputTexture3, index: 3)
        commandEncoderNetwork.setTexture(inputTexture4, index: 4)
        commandEncoderNetwork.setTexture(inputTexture5, index: 5)
        commandEncoderNetwork.setBuffer(childsBuffer, offset: 0, index: 0)
        commandEncoderNetwork.setBuffer(parentsBuffer, offset: 0, index: 1)
        commandEncoderNetwork.setBuffer(input.VtxBuffer!, offset: 0, index: 2)
        commandEncoderNetwork.setBuffer(input.NmleBuffer!, offset: 0, index: 3)
        commandEncoderNetwork.setBuffer(input.FaceBuffer!, offset: 0, index: 4)
        commandEncoderNetwork.setBuffer(input.CoeffBuffer!, offset: 0, index: 5)
        commandEncoderNetwork.setBuffer(poseBuffer, offset: 0, index: 6)
        commandEncoderNetwork.setBuffer(calibBuffer, offset: 0, index: 7)
        
        // Set up thread groups as described in https://developer.apple.com/reference/metal/mtlcomputecommandencoder
        w = computePipelineStateNetwork!.threadExecutionWidth
        h = computePipelineStateNetwork!.maxTotalThreadsPerThreadgroup / w
        threadsPerThreadgroup = MTLSizeMake(w, h, 1)
        threadgroupsPerGrid = MTLSize(width: (input.width + w - 1) / w,
                                      height: (input.height + h - 1) / h,
                                      depth: 1)
        commandEncoderNetwork.dispatchThreadgroups(threadgroupsPerGrid, threadsPerThreadgroup: threadsPerThreadgroup)
        
        commandEncoderNetwork.endEncoding()
        
        commandBufferNetwork.commit()
        commandBufferNetwork.waitUntilCompleted()
        
        // Propagate messages with VMP
        guard let commandBufferVMP = commandQueue.makeCommandBuffer(),
            let commandEncoderVMP = commandBufferVMP.makeComputeCommandEncoder() else {
                print("Failed to create Metal command queue")
                CVMetalTextureCacheFlush(textureCache!, 0)
                return nil
        }
        
        commandEncoderVMP.label = "VMP"
        commandEncoderVMP.setComputePipelineState(computePipelineStateVMP!)
        commandEncoderVMP.setTexture(inputTexture0, index: 0)
        commandEncoderVMP.setTexture(inputTexture1, index: 1)
        commandEncoderVMP.setTexture(inputTexture2, index: 2)
        commandEncoderVMP.setTexture(inputTexture3, index: 3)
        commandEncoderVMP.setTexture(inputTexture4, index: 4)
        commandEncoderVMP.setTexture(inputTexture5, index: 5)
        commandEncoderVMP.setTexture(outputTexture, index: 6)
        commandEncoderVMP.setBuffer(NaturalParamBuffer, offset: 0, index: 0)
        commandEncoderVMP.setBuffer(PriorBuffer, offset: 0, index: 1)
        commandEncoderVMP.setBuffer(childsBuffer, offset: 0, index: 2)
        commandEncoderVMP.setBuffer(parentsBuffer, offset: 0, index: 3)
        commandEncoderVMP.setBuffer(input.VtxBuffer!, offset: 0, index: 4)
        commandEncoderVMP.setBuffer(input.NmleBuffer!, offset: 0, index: 5)
        commandEncoderVMP.setBuffer(input.FaceBuffer!, offset: 0, index: 6)
        commandEncoderVMP.setBuffer(input.CoeffBuffer!, offset: 0, index: 7)
        commandEncoderVMP.setBuffer(poseBuffer, offset: 0, index: 8)
        commandEncoderVMP.setBuffer(calibBuffer, offset: 0, index: 9)
        
        // Set up thread groups as described in https://developer.apple.com/reference/metal/mtlcomputecommandencoder
        w = computePipelineStateVMP!.threadExecutionWidth
        h = computePipelineStateVMP!.maxTotalThreadsPerThreadgroup / w
        threadsPerThreadgroup = MTLSizeMake(w, h, 1)
        threadgroupsPerGrid = MTLSize(width: (input.width + w - 1) / w,
                                      height: (input.height + h - 1) / h,
                                      depth: 1)
        commandEncoderVMP.dispatchThreadgroups(threadgroupsPerGrid, threadsPerThreadgroup: threadsPerThreadgroup)
        
        commandEncoderVMP.endEncoding()
        
        commandBufferVMP.commit()
        
        commandBufferVMP.waitUntilCompleted()
        
        /*CVPixelBufferLockBaseAddress(outputPixelBuffer, CVPixelBufferLockFlags(rawValue: 0));
        let floatBuffer = unsafeBitCast(CVPixelBufferGetBaseAddress(outputPixelBuffer), to: UnsafeMutablePointer<Float>.self)
        let floatPerRow = Int32(CVPixelBufferGetBytesPerRow(outputPixelBuffer)/16)
        print(floatPerRow)
        
        
        for i in 0...239 {
            for j in 0...239 {
                print(floatBuffer[4*(i*240+j)], ", ", floatBuffer[4*(i*240+j)+1], ", ", floatBuffer[4*(i*240+j)+2], ", ", floatBuffer[4*(i*240+j)+3])
            }
        }
        
        CVPixelBufferUnlockBaseAddress(outputPixelBuffer, CVPixelBufferLockFlags(rawValue: 0))*/
        
        
        return outputPixelBuffer
    }
    
    func OcclusionLabeling(input: Param3D, depthTexture: MTLTexture, modelViewMatrix: Matrix4, projectionMatrix: Matrix4) -> CVPixelBuffer? {
        var newPixelBuffer: CVPixelBuffer?
        CVPixelBufferPoolCreatePixelBuffer(kCFAllocatorDefault, outputPixelBufferPool!, &newPixelBuffer)
        guard let outputPixelBuffer = newPixelBuffer else {
            print("Allocation failure: Could not get pixel buffer from pool (\(self.description))")
            return nil
        }
        
        guard let bumpTexture = makeTextureFromCVPixelBuffer(pixelBuffer: outputPixelBuffer , textureFormat: inputTextureFormat),
        let VMapTexture = makeTextureFromCVPixelBuffer(pixelBuffer: input.VMap! , textureFormat: inputTextureFormat) else {
            print("error texture mapping Bump image")
            return nil
        }
        
        let modelViewPointer = modelViewBuffer.contents()
        memcpy(modelViewPointer, modelViewMatrix.raw(), MemoryLayout<Float>.size * Matrix4.numberOfElements())
        let projectionPointer = projectionBuffer.contents()
        memcpy(projectionPointer, projectionMatrix.raw(), MemoryLayout<Float>.size * Matrix4.numberOfElements())
        
        
        // Set up command queue, buffer, and encoder
        guard let commandQueue = commandQueue,
            let commandBuffer = commandQueue.makeCommandBuffer(),
            let commandEncoder = commandBuffer.makeComputeCommandEncoder() else {
                print("Failed to create Metal command queue")
                CVMetalTextureCacheFlush(textureCache!, 0)
                return nil
        }
        
        commandEncoder.label = "Occlusions"
        commandEncoder.setComputePipelineState(computePipelineStateOcclusions!)
        commandEncoder.setTexture(bumpTexture, index: 0)
        commandEncoder.setTexture(depthTexture, index: 1)
        commandEncoder.setTexture(VMapTexture, index: 2)
        commandEncoder.setBuffer(modelViewBuffer, offset: 0, index: 0)
        commandEncoder.setBuffer(projectionBuffer, offset: 0, index: 1)
        
        // Set up thread groups as described in https://developer.apple.com/reference/metal/mtlcomputecommandencoder
        let w = computePipelineStateOcclusions!.threadExecutionWidth
        let h = computePipelineStateOcclusions!.maxTotalThreadsPerThreadgroup / w
        let threadsPerThreadgroup = MTLSizeMake(w, h, 1)
        let threadgroupsPerGrid = MTLSize(width: (input.width + w - 1) / w,
                                          height: (input.height + h - 1) / h,
                                          depth: 1)
        commandEncoder.dispatchThreadgroups(threadgroupsPerGrid, threadsPerThreadgroup: threadsPerThreadgroup)
        
        commandEncoder.endEncoding()
        
        commandBuffer.commit()
        commandBuffer.waitUntilCompleted()
        
        /*CVPixelBufferLockBaseAddress(outputPixelBuffer, CVPixelBufferLockFlags(rawValue: 0));
        let floatBuffer = unsafeBitCast(CVPixelBufferGetBaseAddress(outputPixelBuffer), to: UnsafeMutablePointer<Float>.self)
        let floatPerRow = Int32(CVPixelBufferGetBytesPerRow(outputPixelBuffer)/16)
        print(floatPerRow)
        
        
        for i in 0...239 {
            for j in 0...239 {
                if floatBuffer[4*(i*240+j)] > 0.0 && floatBuffer[4*(i*240+j)+2] == 0.0 {
                    print(floatBuffer[4*(i*240+j)], ", ", floatBuffer[4*(i*240+j)+1], ", ", floatBuffer[4*(i*240+j)+2], ", ", floatBuffer[4*(i*240+j)+3])
                }
            }
        }
        
        CVPixelBufferUnlockBaseAddress(outputPixelBuffer, CVPixelBufferLockFlags(rawValue: 0))*/
        return outputPixelBuffer
    }
    
    func UpdateBumpMedian(input: Param3D, VMapSensor: CVPixelBuffer, NMapSensor: CVPixelBuffer, Pose: float4x4) -> CVPixelBuffer? {
        if !isPrepared {
            assertionFailure("Invalid state: Not prepared")
            return nil
        }
        
        var tmp: [Float] = [Pose.columns.0.x, Pose.columns.0.y, Pose.columns.0.z, Pose.columns.0.w,
                            Pose.columns.1.x, Pose.columns.1.y, Pose.columns.1.z, Pose.columns.1.w,
                            Pose.columns.2.x, Pose.columns.2.y, Pose.columns.2.z, Pose.columns.2.w,
                            Pose.columns.3.x, Pose.columns.3.y, Pose.columns.3.z, Pose.columns.3.w]
        memcpy(poseBuffer.contents(), UnsafeMutableRawPointer(&tmp), MemoryLayout<Float>.size * 16)
        
        var newPixelBuffer: CVPixelBuffer?
        CVPixelBufferPoolCreatePixelBuffer(kCFAllocatorDefault, outputPixelBufferPool!, &newPixelBuffer)
        guard let outputPixelBuffer = newPixelBuffer else {
            print("Allocation failure: Could not get pixel buffer from pool (\(self.description))")
            return nil
        }
        
        guard let outputTexture = makeTextureFromCVPixelBuffer(pixelBuffer: newPixelBuffer!, textureFormat: .rgba32Float),
            let inputTexture0 = makeTextureFromCVPixelBuffer(pixelBuffer: input.bumpImage! , textureFormat: inputTextureFormat),
            let inputTexture1 = makeTextureFromCVPixelBuffer(pixelBuffer: input.WLImage!, textureFormat: inputTextureFormat),
            let inputTexture2 = makeTextureFromCVPixelBuffer(pixelBuffer: VMapSensor, textureFormat: .rgba32Float),
            let inputTexture3 = makeTextureFromCVPixelBuffer(pixelBuffer: NMapSensor, textureFormat: .rgba32Float)  else {
                return nil
        }
        
        // Set up command queue, buffer, and encoder
        guard let commandQueue = commandQueue,
            let commandBuffer = commandQueue.makeCommandBuffer(),
            let commandEncoder = commandBuffer.makeComputeCommandEncoder() else {
                print("Failed to create Metal command queue")
                CVMetalTextureCacheFlush(textureCache!, 0)
                return nil
        }
        
        commandEncoder.label = "Median Bump Mapping"
        commandEncoder.setComputePipelineState(computePipelineStateMedian!)
        commandEncoder.setTexture(inputTexture0, index: 0)
        commandEncoder.setTexture(inputTexture1, index: 1)
        commandEncoder.setTexture(inputTexture2, index: 2)
        commandEncoder.setTexture(inputTexture3, index: 3)
        commandEncoder.setTexture(outputTexture, index: 4)
        commandEncoder.setBuffer(input.VtxBuffer!, offset: 0, index: 0)
        commandEncoder.setBuffer(input.NmleBuffer!, offset: 0, index: 1)
        commandEncoder.setBuffer(input.FaceBuffer!, offset: 0, index: 2)
        commandEncoder.setBuffer(input.CoeffBuffer!, offset: 0, index: 3)
        commandEncoder.setBuffer(MedianBuffer, offset: 0, index: 4)
        commandEncoder.setBuffer(Counter, offset: 0, index: 5)
        commandEncoder.setBuffer(poseBuffer, offset: 0, index: 6)
        commandEncoder.setBuffer(calibBuffer, offset: 0, index: 7)
        
        // Set up thread groups as described in https://developer.apple.com/reference/metal/mtlcomputecommandencoder
        let w = computePipelineStateMedian!.threadExecutionWidth
        let h = computePipelineStateMedian!.maxTotalThreadsPerThreadgroup / w
        let threadsPerThreadgroup = MTLSizeMake(w, h, 1)
        let threadgroupsPerGrid = MTLSize(width: (input.width + w - 1) / w,
                                          height: (input.height + h - 1) / h,
                                          depth: 1)
        commandEncoder.dispatchThreadgroups(threadgroupsPerGrid, threadsPerThreadgroup: threadsPerThreadgroup)
        
        commandEncoder.endEncoding()
        
        commandBuffer.commit()
        commandBuffer.waitUntilCompleted()
        
        return outputPixelBuffer
        
    }
    
    func makeTextureFromCVPixelBuffer(pixelBuffer: CVPixelBuffer, textureFormat: MTLPixelFormat) -> MTLTexture? {
        let width = CVPixelBufferGetWidth(pixelBuffer)
        let height = CVPixelBufferGetHeight(pixelBuffer)
        
        var cvTextureOut: CVMetalTexture?
        CVMetalTextureCacheCreateTextureFromImage(kCFAllocatorDefault, textureCache, pixelBuffer, nil, textureFormat, width, height, 0, &cvTextureOut)
        
        guard let cvTexture = cvTextureOut, let texture = CVMetalTextureGetTexture(cvTexture) else {
            print("Depth converter failed to create preview texture")
            
            CVMetalTextureCacheFlush(textureCache, 0)
            
            return nil
        }
        
        return texture
    }
    
    func GetPrior() -> MTLBuffer {
        return PriorBuffer
    }
}
