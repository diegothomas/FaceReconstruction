//
//  Vertex.swift
//  WrinkleMe-mac
//
//  Created by Diego Thomas on 2018/02/19.
//  Copyright © 2018 3DLab. All rights reserved.
//

import Foundation


class Vertex{
    
    var x,y,z: Float     // position data
    var r,g,b,a: Float   // color data
    var s,t: Float       // texture coordinates
    var nX,nY,nZ: Float  // normal
    var isBack: Bool = true
    
    init(_x: Float, _y: Float, _z: Float, _r: Float, _g: Float, _b: Float, _a: Float, _s: Float, _t: Float) {
        x = _x
        y = _y
        z = _z
        r = _r
        g = _g
        b = _b
        a = _a
        s = _s
        t = _t
        nX = 0.0
        nY = 0.0
        nZ = 0.0
    }
    
    init(V_in: Vertex) {
        x = V_in.x
        y = V_in.y
        z = V_in.z
        r = V_in.r
        g = V_in.g
        b = V_in.b
        a = V_in.a
        s = V_in.s
        t = V_in.t
        nX = V_in.nX
        nY = V_in.nY
        nZ = V_in.nZ
    }
    
    func floatBuffer() -> [Float] {
        return [x,y,z,r,g,b,a,s,t,nX,nY,nZ]
    }
    
}


