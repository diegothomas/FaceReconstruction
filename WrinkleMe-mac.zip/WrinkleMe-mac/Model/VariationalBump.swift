//
//  VariationalBump.swift
//  WrinkleMe-mac
//
//  Created by Diego Thomas on 2018/03/22.
//  Copyright © 2018 3DLab. All rights reserved.
//

import Foundation

var width = WIDTH_BUMP
var height = HEIGHT_BUMP


class VariationalBump {
    
    /**
        Each pixel in the Bump image has two nodes: 1 for the average, one for the variance.
     */
    
    // expectation of the natural statisttic vector (Gauss)
    private var nodesBump: [float2] = Array<float2>.init(repeating: float2(0.0, 0.0), count: width*height)
    
    //expectation of the natural statistic vector (Gamma)
    private var nodesVar: [float2] = Array<float2>.init(repeating: float2(400.0, log(400)), count:  width*height)
    
    // Gaussian statistic parameter
    private var priorBump: [float2] = Array<float2>.init(repeating: float2(0.0, -200.0), count:  width*height)
    
    // Gamma statistic parameter
    private var priorVar: [float2] = Array<float2>.init(repeating: float2(-0.5, 0.0), count:  width*height)
    
    
    private var paramBump: [float2] = Array<float2>.init(repeating: float2(0.0, 0.0), count:  width*height)
    private var paramVar: [float2] = Array<float2>.init(repeating: float2(0.0, 0.0), count:  width*height)
    
    private var childs: [[int2]] = Array<[int2]>.init(repeating: [], count:  width*height)
    private var childsF: [[Float]] = Array<[Float]>.init(repeating: [], count:  width*height)
    private var parents: [[int2]] = Array<[int2]>.init(repeating: [], count: Int(DEPTH_WIDTH*DEPTH_WIDTH))
    
    /**
        The current index in the nodes buffer of the current bump map
     */
    private var indexCurr = 0
    
    /**
        Maximum number of iterations for the VMP algorithm
     */
    private let maxIter = 10
    
    required init() {
        
    }
    
    /**
        The message passing from a node on the bump image to a node on the depth image
     
        - Parameter nu: the average of the bump node
     
        - Returns: the natural statistic vector [nu nu^2]
     */
    func messageBumpToDepth(_ nu: Float) -> float2 {
        return float2(nu,nu*nu)
    }
    
    /**
        One bump has to nodes: one for its value, and one for its variance,
        so messages pass 4 values
     
        - Parameter nu: the average of the bump node
     
        - Returns: the natural statistic vector
    */
    func messageDepthToBump(_ nu: Float, _ beta: Float, _ depthNode: float2, _ coparents: [float2]) -> float4 {
        // depthNode.x is the depthvalue
        // nu is the expectation of the bump value
        // beta is the expectation of the variance of the bump node.
        var res = float4(depthNode.x*beta, -beta/2.0, -0.5*(depthNode.x*depthNode.x - 2.0*depthNode.x*nu + nu*nu), 0.5)
        
        for node in coparents {
            res = res + float4(node.x*beta, -beta/2.0, -0.5*(depthNode.x*depthNode.x - 2.0*depthNode.x*node.x + node.x*node.x), 0.5)
        }
        
        return res
    }
    
    func messageDepthToBumpVariance(_ depth: Float, _ nu: Float) -> float2 {
        return float2(-0.5*(depth*depth - 2.0*depth*nu + nu*nu), 0.5)
    }
    
    func messageBumpToBump(_ m: Float, _ a: Float) -> float4 {
        return float4(m, m*m, a, log(a))
    }
    
    /**
     Function that reads the current estimate of a bump value
     
     - Parameter i: line index
     
     - Parameter j: column index
     */
    func getBumpVal(_ i: Int, _ j: Int) -> Float {
        return nodesBump[i*width+j].x
    }
    
    /**
        Main function that manage the message passing algorithm for a new input depth image
    
        - Parameters coeff: blendshape coefficients
     
        - Parameters depthPixelBuffer: The input depth image.
     
        - Parameters instrinsicDepth: The intrinsic parameters of the depth camera

        - Pose: the current head pose
     */
    func VMP(_ VMap: CVPixelBuffer, _ NMap: CVPixelBuffer, _ coeff: [Float], _ VMapPixelBuffer: CVPixelBuffer, _ NMapPixelBuffer: CVPixelBuffer, _ instrinsicDepth: [Double], _ pose: float4x4) {
        
        /**
            Algorithm:
                For each node in turn,
                    . Retrieve messages from all parents and child nodes as define in the header. This will require child nodes to retrieve messages from the co-parents of Xp
                    . Compute updated natural parameter vecor Psi
                    . Compute updated moment vector given the new setting of parameter vector
         
                Calculate the new value of the lower bound (if required)
         
                If the increase in the bound is negligeable or a specified number of iterations has been reached, stop. Otherwise repeat from step 1.
         */
        
        CVPixelBufferLockBaseAddress(VMapPixelBuffer, CVPixelBufferLockFlags(rawValue: 0));
        let floatBuffer = unsafeBitCast(CVPixelBufferGetBaseAddress(VMapPixelBuffer), to: UnsafeMutablePointer<Float>.self)
        let floatPerRow = Int32(CVPixelBufferGetBytesPerRow(VMapPixelBuffer)/16)
        print(floatPerRow)
        
        CVPixelBufferLockBaseAddress(NMapPixelBuffer, CVPixelBufferLockFlags(rawValue: 0));
        let floatNBuffer = unsafeBitCast(CVPixelBufferGetBaseAddress(NMapPixelBuffer), to: UnsafeMutablePointer<Float>.self)
        
        CVPixelBufferLockBaseAddress(VMap, CVPixelBufferLockFlags(rawValue: 0));
        let VMapBuffer = unsafeBitCast(CVPixelBufferGetBaseAddress(VMap), to: UnsafeMutablePointer<Float>.self)
        
        
        CVPixelBufferLockBaseAddress(NMap, CVPixelBufferLockFlags(rawValue: 0));
        let NMapBuffer = unsafeBitCast(CVPixelBufferGetBaseAddress(NMap), to: UnsafeMutablePointer<Float>.self)
        
        //////////////////////////
        //////Create graph////////
        //////////////////////////
        for i in 0...width-1 {
            for j in 0...height-1 {
                /////////////////////////////
                // Compute set of children //
                /////////////////////////////
                
                // get current point and normal on the template with coefficients
                var pt: float4 = float4(VMapBuffer[4*(i*width+j)], VMapBuffer[4*(i*width+j)+1], VMapBuffer[4*(i*width+j)+2], 1.0)
                var nmle: float4 = float4(NMapBuffer[4*(i*width+j)], NMapBuffer[4*(i*width+j)+1], NMapBuffer[4*(i*width+j)+2], 0.0)
                if (nmle.x == 0.0 && nmle.y == 0.0 && nmle.z == 0.0) {
                    continue
                }
                /*for k in 1...27 {
                    pt = pt + coeff[k]*VMap[k][i*240+j]
                    nmle = nmle + coeff[k]*NMap[k][i*240+j]
                }
                nmle = nmle/nmle.norm_two()*/
                pt = pose*pt
                nmle = pose*nmle
                
                if nmle.z < 0.2 {
                    continue
                }
                
                let range = 0.2/sqrt(-2.0*priorBump[i*width+j].y)
                //print("range: ", range)
                let p1 = pt + (nodesBump[i*width+j].x-range)*nmle
                let p2 = pt + (nodesBump[i*width+j].x+range)*nmle
                
                // project the extreme points onto the depth image
                
                let s1 = float2((p1.x/fabs(p1.z))*Float(instrinsicDepth[0]) + Float(instrinsicDepth[2]),
                                Float(DEPTH_HEIGHT)-((p1.y/fabs(p1.z))*Float(instrinsicDepth[4]) + Float(instrinsicDepth[5])))
                let s2 = float2((p2.x/fabs(p2.z))*Float(instrinsicDepth[0]) + Float(instrinsicDepth[2]),
                                Float(DEPTH_HEIGHT)-((p2.y/fabs(p2.z))*Float(instrinsicDepth[4]) + Float(instrinsicDepth[5])))
                
                var length = sqrt((s1.x-s2.x)*(s1.x-s2.x) + (s1.y-s2.y)*(s1.y-s2.y))
                
                let dir = float2((s2.x-s1.x)/length, (s2.y-s1.y)/length)
                
                if length < 1.0 {
                    length = 1.0
                }
                
                // add all pixels along the line as childs
                var kPrev = -1
                var lPrev = -1
                for lambda in 0...Int(length)-1 {
                    let k = Int(round(s1.y + Float(lambda)*dir.y))
                    let l = Int(round(s1.x + Float(lambda)*dir.x))
                    
                    if k == kPrev && l == lPrev {
                        continue
                    }
                    kPrev = k
                    lPrev = l
                    
                    let v: float4 = float4(floatBuffer[Int(k*Int(floatPerRow) + l)*4],
                                           floatBuffer[Int(k*Int(floatPerRow) + l)*4+1],
                                           floatBuffer[Int(k*Int(floatPerRow) + l)*4+2],
                                           1.0)
                    
                    
                    let nCurr: float4 = float4(floatNBuffer[Int(k*Int(floatPerRow) + l)*4],
                                           floatNBuffer[Int(k*Int(floatPerRow) + l)*4+1],
                                           floatNBuffer[Int(k*Int(floatPerRow) + l)*4+2],
                                           0.0)
                    
                    let dist_proj = dot(v-pt, nmle)
                    let dist = sqrt(dot(v - pt - dist_proj*nmle, v - pt - dist_proj*nmle))
                    let angle = dot(nmle, nCurr)
                    
                    if dist > 0.01 || angle < 0.3 {
                        continue
                    }
                    
                    childs[i*width+j].append(int2(Int32(k),Int32(l)))
                    parents[k*Int(DEPTH_WIDTH)+l].append(int2(Int32(i),Int32(j)))
                }
                
                /*let p = pt + (nodesBump[i*240+j].x)*nmle
                
                let s = float2((p.x/fabs(p.z))*Float(instrinsicDepth[0]) + Float(instrinsicDepth[2]),
                                DEPTH_HEIGHT-((p.y/fabs(p.z))*Float(instrinsicDepth[4]) + Float(instrinsicDepth[5])))
                
                let lowl = max(Int(s.x)-3, 0)
                let upl = min(Int(s.x)+3, 479)
                let lowr = max(Int(s.y)-3, 0)
                let upr = min(Int(s.y)+3, 639)
                
                for l in lowl...upl {
                    for k in lowr...upr {
                        let v: float4 = float4(floatBuffer[Int(k*Int(floatPerRow) + l)*4],
                                               floatBuffer[Int(k*Int(floatPerRow) + l)*4+1],
                                               floatBuffer[Int(k*Int(floatPerRow) + l)*4+2],
                                               1.0)
                        
                        
                        let nCurr: float4 = float4(floatNBuffer[Int(k*Int(floatPerRow) + l)*4],
                                                   floatNBuffer[Int(k*Int(floatPerRow) + l)*4+1],
                                                   floatNBuffer[Int(k*Int(floatPerRow) + l)*4+2],
                                                   0.0)
                        
                        let dist_proj = dot(v-pt, nmle)
                        let dist = sqrt(dot(v - pt - dist_proj*nmle, v - pt - dist_proj*nmle))
                        let angle = dot(nmle, nCurr)
                        
                        if dist > 0.01 || angle < 0.3 {
                            continue
                        }
                        
                        childs[i*240+j].append(int2(Int32(k),Int32(l)))
                    }
                }*/
            }
        }
        
        let i = 143
        let j = 132
        print("######### i: ", i, ", j: ", j)
        for children in childs[i*width + j] {
            
            print("child: ", children.y, ", ", children.x)
            for pa in parents[Int(children.x*floatPerRow + children.y)] {
                print("parent: ", pa.y*Int32(width)+pa.x)
            }
        }
        
        ///////////////////////////////////
        ///////Propagate the messages//////
        ///////////////////////////////////
        
        for _ in 0...10 {
            for i in 0...width-1 {
                for j in 0...height-1 {
                    
                    // get current point and normal on the template with coefficients
                    var pt: float4 = float4(VMapBuffer[4*(i*width+j)], VMapBuffer[4*(i*width+j)+1], VMapBuffer[4*(i*width+j)+2], 1.0)
                    var nmle: float4 = float4(NMapBuffer[4*(i*width+j)], NMapBuffer[4*(i*width+j)+1], NMapBuffer[4*(i*width+j)+2], 0.0)
                    /*for k in 1...27 {
                        pt = pt + coeff[k]*VMap[k][i*240+j]
                        nmle = nmle + coeff[k]*NMap[k][i*240+j]
                    }
                    nmle = nmle/nmle.norm_two()*/
                    pt = pose*pt
                    nmle = pose*nmle
                    
                    //////////////////////////
                    // update distribution for bump nodes
                    //////////////////////////
                    
                    // 1. send message from varNodes to each child (same message for all child)
                    
                    // 2. update natural parameter vector
                    var param: float2 = float2(priorBump[i*width+j].x, priorBump[i*width+j].y)
                    
                    for children in childs[i*width+j] {
                        // Get messages from coparents
                        var messages: [float2] = []
                        for pa in parents[Int(children.x*floatPerRow + children.y)] {
                            if pa.x != i || pa.y != j {
                                messages.append(nodesBump[Int(pa.x*Int32(width)+pa.y)])
                            }
                        }
                        
                        let v: float4 = float4(floatBuffer[Int(children.x*floatPerRow + children.y)*4],
                                               floatBuffer[Int(children.x*floatPerRow + children.y)*4+1],
                                               floatBuffer[Int(children.x*floatPerRow + children.y)*4+2],
                                               1.0)
                        if v.z == 0.0 {
                            continue
                        }
                        
                        var prod = Float(1.0)
                        for m in messages {
                            prod = prod * dot((pt + m.x*nmle - v), (pt + m.x*nmle - v))
                        }
                        
                        //param = param + float2(messVar.x*(nmle.x*(v.x-pt.x) + nmle.y*(v.y-pt.y) + nmle.z*(v.z-pt.z)),
                        //                       -(messVar.x/2.0)*(nmle.x*nmle.x + nmle.y*nmle.y+nmle.z*nmle.z))
                        let sigma = Float(2000.0)
                        param = param + float2(sigma*((nmle.x*(v.x-pt.x) + nmle.y*(v.y-pt.y) + nmle.z*(v.z-pt.z)))*prod,
                                                -(sigma/2.0)*prod)
                    }
                    
                    // 3. Compute new expectation
                    nodesBump[i*width+j] = float2(-param.x/(2.0*param.y), (param.x*param.x)/(4.0*param.y*param.y) - 1.0/(2.0*param.y))
                    paramBump[i*width+j] = param
                    
                    /*
                    //////////////////////////
                    // update distribution for var nodes
                    //////////////////////////
                    
                    // 1. send message from bumpNodes to each child
                    let messBump: float2 = float2(nodesBump[i*240+j].x, nodesBump[i*240+j].y)
                    
                    // 2. update natural parameter vector
                    param = float2(priorVar[i*240+j].x, priorVar[i*240+j].y)
                    
                    for children in childs[i*240+j] {
                        let v: float4 = float4(floatBuffer[Int(children.x*floatPerRow + children.y)*4],
                                               floatBuffer[Int(children.x*floatPerRow + children.y)*4+1],
                                               floatBuffer[Int(children.x*floatPerRow + children.y)*4+2],
                                               1.0)
                        if v.z == 0.0 {
                            continue
                        }
                        param = param + float2(-0.5*((v.x-pt.x)*(v.x-pt.x) + (v.y-pt.y)*(v.y-pt.y) + (v.z-pt.z)*(v.z-pt.z) -
                                                    2.0*messBump.x*(nmle.x*(v.x-pt.x) + nmle.y*(v.y-pt.y) + nmle.z*(v.z-pt.z)) +
                                                    messBump.y*(nmle.x*nmle.x + nmle.y*nmle.y+nmle.z*nmle.z)), 0.5)
                    }
                    
                    // 3. Compute the new expectation
                    let EulerConstant = Float(0.577215664901532860606512090082)
                    var dGamma = -EulerConstant - 1.0/(param.y + 1.0)
                    for n in 1...1000 {
                        dGamma += 1.0/Float(n) - 1.0/(param.y + 1.0 + Float(n))
                    }
                    
                    nodesVar[i*240+j] = float2(-(param.y+1.0)/param.x, -log(-param.x) + dGamma)
                    paramVar[i*240+j] = param
                    */
                }
            }
        }
        
        //////////////////////
        // Update Prior
        //////////////////////
        
        for i in 0...width-1 {
            for j in 0...height-1 {
                if childs[i*width+j].count > 0 {
                    priorBump[i*width+j] = float2(paramBump[i*width+j].x, paramBump[i*width+j].y)
                }
                childs[i*width+j].removeAll()
            }
        }
        
        for i in 0...Int(DEPTH_WIDTH)-1 {
            for j in 0...Int(DEPTH_HEIGHT)-1 {
                parents[j*Int(DEPTH_WIDTH) + i].removeAll()
            }
        }
        
        
        CVPixelBufferUnlockBaseAddress(VMapPixelBuffer, CVPixelBufferLockFlags(rawValue: 0))
        CVPixelBufferUnlockBaseAddress(NMapPixelBuffer, CVPixelBufferLockFlags(rawValue: 0))
        CVPixelBufferUnlockBaseAddress(VMap, CVPixelBufferLockFlags(rawValue: 0))
        CVPixelBufferUnlockBaseAddress(NMap, CVPixelBufferLockFlags(rawValue: 0))
    }
    
    func VMPTest(_ VMap: CVPixelBuffer, _ NMap: CVPixelBuffer, _ coeff: [Float], _ VMapPixelBuffer: CVPixelBuffer, _ instrinsicDepth: [Double], _ pose: float4x4) {
        
        /**
         Algorithm:
         For each node in turn,
         . Retrieve messages from all parents and child nodes as define in the header. This will require child nodes to retrieve messages from the co-parents of Xp
         . Compute updated natural parameter vecor Psi
         . Compute updated moment vector given the new setting of parameter vector
         
         Calculate the new value of the lower bound (if required)
         
         If the increase in the bound is negligeable or a specified number of iterations has been reached, stop. Otherwise repeat from step 1.
         */
        
        CVPixelBufferLockBaseAddress(VMapPixelBuffer, CVPixelBufferLockFlags(rawValue: 0));
        //let floatBuffer = unsafeBitCast(CVPixelBufferGetBaseAddress(VMapPixelBuffer), to: UnsafeMutablePointer<Float>.self)
        let floatPerRow = Int32(CVPixelBufferGetBytesPerRow(VMapPixelBuffer)/16)
        print(floatPerRow)
        
        CVPixelBufferLockBaseAddress(VMap, CVPixelBufferLockFlags(rawValue: 0));
        let VMapBuffer = unsafeBitCast(CVPixelBufferGetBaseAddress(VMap), to: UnsafeMutablePointer<Float>.self)
        
        
        CVPixelBufferLockBaseAddress(NMap, CVPixelBufferLockFlags(rawValue: 0));
        let NMapBuffer = unsafeBitCast(CVPixelBufferGetBaseAddress(NMap), to: UnsafeMutablePointer<Float>.self)
        
        //////////////////////////
        //////Create graph////////
        //////////////////////////
        for i in 0...width-1 {
            for j in 0...height-1 {
                /////////////////////////////
                // Compute set of children //
                /////////////////////////////
                
                // get current point and normal on the template with coefficients
                var pt: float4 = float4(VMapBuffer[4*(i*width+j)], VMapBuffer[4*(i*width+j)+1], VMapBuffer[4*(i*width+j)+2], 1.0)
                var nmle: float4 = float4(NMapBuffer[4*(i*width+j)], NMapBuffer[4*(i*width+j)+1], NMapBuffer[4*(i*width+j)+2], 0.0)
                if (nmle.x == 0.0 && nmle.y == 0.0 && nmle.z == 0.0) {
                    continue
                }
                
                pt = pose*pt
                nmle = pose*nmle
                
                if nmle.z < 0.0 {
                    continue
                }
                
                
                // add all pixels along the line as childs
                for _ in 0...9 {
                    childsF[i*width+j].append(Float(drand48()-0.5)/100.0)
                }
            }
        }
        
        ///////////////////////////////////
        ///////Propagate the messages//////
        ///////////////////////////////////
        
        for _ in 0...10 {
            for i in 0...width-1 {
                for j in 0...height-1 {
                    
                    // get current point and normal on the template with coefficients
                    var pt: float4 = float4(VMapBuffer[4*(i*width+j)], VMapBuffer[4*(i*width+j)+1], VMapBuffer[4*(i*width+j)+2], 1.0)
                    var nmle: float4 = float4(NMapBuffer[4*(i*width+j)], NMapBuffer[4*(i*width+j)+1], NMapBuffer[4*(i*width+j)+2], 0.0)
                    pt = pose*pt
                    nmle = pose*nmle
                    
                    //////////////////////////
                    // update distribution for bump nodes
                    //////////////////////////
                    
                    // 1. send message from varNodes to each child (same message for all child)
                    let messVar: float2 = float2(nodesVar[i*width+j].x, nodesVar[i*width+j].y)
                    
                    // 2. update natural parameter vector
                    var param: float2 = float2(priorBump[i*width+j].x, priorBump[i*width+j].y)
                    
                    // 10 childs for each node
                    for lambda in childsF[i*width+j] {
                        let v = pt + (Float(0.05)+lambda)*nmle
                        param = param + float2(messVar.x*(nmle.x*(v.x-pt.x) + nmle.y*(v.y-pt.y) + nmle.z*(v.z-pt.z)),
                                               -(messVar.x/2.0)*(nmle.x*nmle.x + nmle.y*nmle.y + nmle.z*nmle.z))
                    }
                    
                    // 3. Compute new expectation
                    nodesBump[i*width+j] = float2(-param.x/(2.0*param.y), (param.x*param.x)/(4.0*param.y*param.y) - 1.0/(2.0*param.y))
                    paramBump[i*width+j] = param
                    
                    //////////////////////////
                    // update distribution for var nodes
                    //////////////////////////
                    
                    // 1. send message from bumpNodes to each child
                    let messBump: float2 = float2(nodesBump[i*width+j].x, nodesBump[i*width+j].y)
                    
                    // 2. update natural parameter vector
                    param = float2(priorVar[i*width+j].x, priorVar[i*width+j].y)
                    
                    for lambda in childsF[i*width+j] {
                        let v = pt + (Float(0.05)+lambda)*nmle
                        param = param + float2(-0.5*((v.x-pt.x)*(v.x-pt.x) + (v.y-pt.y)*(v.y-pt.y) + (v.z-pt.z)*(v.z-pt.z) -
                            2.0*messBump.x*(nmle.x*(v.x-pt.x) + nmle.y*(v.y-pt.y) + nmle.z*(v.z-pt.z)) +
                            messBump.y*(nmle.x*nmle.x + nmle.y*nmle.y+nmle.z*nmle.z)), 0.5)
                    }
                    
                    // 3. Compute the new expectation
                    let EulerConstant = Float(0.577215664901532860606512090082)
                    var dGamma = -EulerConstant - 1.0/(param.y + 1.0)
                    for n in 1...1000 {
                        dGamma += 1.0/Float(n) - 1.0/(param.y + 1.0 + Float(n))
                    }
                    
                    nodesVar[i*width+j] = float2(-(param.y+1.0)/param.x, -log(-param.x) + dGamma)
                    paramVar[i*width+j] = param
                    
                }
            }
        }
        
        //////////////////////
        // Update Prior
        //////////////////////
        
        var sum = Float(0.0)
        var count = Float(0.0)
        for i in 0...width-1 {
            for j in 0...height-1 {
                if childsF[i*width+j].count > 0 {
                    priorBump[i*width+j] = float2(paramBump[i*width+j].x, paramBump[i*width+j].y)
                    priorVar[i*width+j] = float2(paramVar[i*width+j].x, paramVar[i*width+j].y)
                    let residual = sqrt((nodesBump[i*width+j].x - Float(0.05))*(nodesBump[i*width+j].x - Float(0.05)))
                    sum = sum + residual
                    count += 1.0
                    /*print("Bump: ", nodesBump[i*240+j])
                    print("Var: ", nodesVar[i*240+j])
                    print("priorBump: ", priorBump[i*240+j])
                    print("priorVar: ", priorVar[i*240+j])*/
                }
                
                childsF[i*width+j].removeAll()
            }
        }
        
        print("error: ", sum/count)
        
        CVPixelBufferUnlockBaseAddress(VMapPixelBuffer, CVPixelBufferLockFlags(rawValue: 0))
        CVPixelBufferUnlockBaseAddress(VMap, CVPixelBufferLockFlags(rawValue: 0))
        CVPixelBufferUnlockBaseAddress(NMap, CVPixelBufferLockFlags(rawValue: 0))
    }
}
