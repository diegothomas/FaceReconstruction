//
//  UV.swift
//  WrinkleMe-mac
//
//  Created by Diego Thomas on 2018/02/19.
//  Copyright © 2018 3DLab. All rights reserved.
//

import Foundation

struct UV{
    
    var u,v: Float     // position data
    
    func floatBuffer() -> [Float] {
        return [u,v]
    }
    
}

